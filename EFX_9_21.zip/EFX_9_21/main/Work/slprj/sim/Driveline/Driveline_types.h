#include "__cf_Driveline.h"
#ifndef RTW_HEADER_Driveline_types_h_
#define RTW_HEADER_Driveline_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef DEFINED_TYPEDEF_FOR_struct_ibWqD7XqCOzIQz6ZgjTzcD_
#define DEFINED_TYPEDEF_FOR_struct_ibWqD7XqCOzIQz6ZgjTzcD_
typedef struct { real_T TrackWidth ; } struct_ibWqD7XqCOzIQz6ZgjTzcD ;
#endif
typedef struct gimbih1di0h_ gimbih1di0h ; typedef struct coyvih0rk1
dwsgrvz41y ;
#endif
