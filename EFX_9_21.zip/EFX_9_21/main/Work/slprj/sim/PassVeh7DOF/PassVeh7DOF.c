#include "__cf_PassVeh7DOF.h"
#include "PassVeh7DOF_capi.h"
#include "PassVeh7DOF.h"
#include "PassVeh7DOF_private.h"
#include "interp2_5YaFqjgU.h"
#include "look1_binlcpw.h"
#include "look1_binlxpw.h"
static RegMdlInfo rtMdlInfo_PassVeh7DOF [ 110 ] = { { "or0r4q4rh4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"j4fedpjpo0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "cspwehehgp" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "buwnn4ewmg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bq3nsn4tha" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "hgz0u45ian" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ijfgkn4l3e" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"iw0hhox1z3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ji1gw0gkru" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "jaxagnd4mw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"jztpqiauj1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "pavwyjocdf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "o4v4znezsc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"nmazjxgur0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "edq1p0dbfr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "lgeqn330mk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"dcjvu5ul0y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "mpfuiik1kr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "o4mqo5elfu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"hznwrkfhta" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "eqxdu1smfw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "i1lzbfmeqz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"llo4onv10p" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "jxfiol5u3d" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "jnbczsppvg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"dsiazaavdd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "i4cctbfaje" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "b0ccxuamsx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"axxgnaq4jx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "b5qcncsz1r" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "agsgnulyfo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bhu3vpc40r" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ikqrgkdcac" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "pqca3kvywqf" , MDL_INFO_NAME_MDLREF_DWORK ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , { "kg2zcpxtlx" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"e3r11zdizr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "dn0l2t323g" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ha25zehowz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"hcqlainyez" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "n52l1mzp31" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "pcbmq2m11v" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"a12pcgpb01" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "lijr033rr2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "bpefjqedzq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"id4lpjcjia" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "dgk2ovyv5o" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "b51av3ulwn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mfpcrarm3m" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "g3iefm0j4w" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "lis1ormwxp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"pgy4d5vijx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "iu231drtpw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ii3iorkudk" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ps1ayp5pv5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "hzczw4rimi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "lahi4jyhaj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"aoae4c423r" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "ateq2n1kdh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "ly0nz4wmp4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"jdgh21gpy3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "nm4ubjqz2k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "gnhczwf3q0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ir2brmrgv2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "imqcetoreh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "dkdbmnofxa" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"bjyevuqahi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "fw4l3ijud5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 ,
( void * ) "Locked" } , { "bcot51nxfi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "PassVeh7DOF" } , { "fqfjhhkyss" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ccz2kuezyf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "armwt132yr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "e3uy3z0e1m" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"lswvubjtnh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "mwwtt4vzn3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "n1hujmknlh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"ptwb5m53nr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * )
"Simple Magic Tire" } , { "PassVeh7DOF" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , 0 , ( NULL ) } , { "iqrkfebraoy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "PassVeh7DOF" } , { "a4qtx0azetw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"i2rjcmb3r3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "oinmjmcxpr0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "jy03oxyarzs" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"awewo52yo44" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "pwude5af1ju" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "iqrkfebrao" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"a4qtx0azet" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "oinmjmcxpr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1
, ( void * ) "PassVeh7DOF" } , { "mkmp3c5j3y" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"pa50wxsaaa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "struct_5NGg6nxNHRWKsr0nLboB4F" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_wjXS3rIiQNI90M790LMxVG" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_NtCe3ohFvXuRZXQoDidoXH" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_A6Yb21eKNPgaupJlKafAPB" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_NYc8q8ZDpqCMqvwIx2DzE" , MDL_INFO_ID_DATA_TYPE , 0 , - 1
, ( NULL ) } , { "struct_MulvPjTG5PLC9kEliA7G3E" , MDL_INFO_ID_DATA_TYPE , 0
, - 1 , ( NULL ) } , { "struct_k3EETTmsXgkf0BoTgEtKtG" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"mr_PassVeh7DOF_GetSimStateDisallowedBlocks" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheDataToMxArrayWithOffset" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_extractBitFieldFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , -
1 , ( void * ) "PassVeh7DOF" } , { "mr_PassVeh7DOF_restoreDataFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 ,
( void * ) "PassVeh7DOF" } , { "mr_PassVeh7DOF_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } , {
"mr_PassVeh7DOF_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * )
"PassVeh7DOF" } , { "mr_PassVeh7DOF_GetDWork" , MDL_INFO_ID_MODEL_FCN_NAME ,
0 , - 1 , ( void * ) "PassVeh7DOF" } , { "PassVeh7DOF.h" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , { "PassVeh7DOF.c" ,
MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * ) "PassVeh7DOF" } } ;
becrktx0d0o becrktx0d0 = { 1.37 , 0.3 , 0.1 , 0.1 , { 0.0 , 0.03 , 0.06 ,
0.09 , 0.12 , 0.15 , 0.18 , 0.21 , 0.24 , 0.27 , 0.3 , 0.32999999999999996 ,
0.36 , 0.39 , 0.42 , 0.45 , 0.48000000000000004 , 0.51 , 0.54 ,
0.57000000000000006 , 0.60000000000000009 , 0.63 , 0.66 , 0.69000000000000006
, 0.72 , 0.75 , 0.78 , 0.81 , 0.84000000000000008 , 0.87 , 0.9 } , 11459.0 ,
11459.0 , { 0.0 , 0.01 , 0.02 , 0.03 , 0.04 , 0.05 , 0.06 , 0.07 , 0.08 ,
0.09 , 0.1 , 0.11 , 0.12 , 0.13 , 0.14 , 0.15 , 0.15999999999999998 ,
0.16999999999999998 , 0.18 , 0.19 , 0.19999999999999998 , 0.21 ,
0.21999999999999997 , 0.22999999999999998 , 0.24 , 0.25 , 0.26 , 0.27 ,
0.27999999999999997 , 0.29 , 0.3 } , 5000.0 , 5000.0 , 5000.0 , 5000.0 ,
3136.0 , 3136.0 , 3136.0 , 3136.0 , 2548.0 , 2548.0 , 2548.0 , 2548.0 ,
5000.0 , 0.22 , 0.22 , 0.22 , 0.22 , 206.613792 , 16.0 , 16.0 , 16.0 , 16.0 ,
0.106 , 0.106 , 0.106 , 0.106 , 2.0 , 68947.57 , 68947.57 , 68947.57 ,
68947.57 , 2.0 , 1.3526 , 1.3526 , 1.3526 , 1.3526 , 2.9439 , 2.9439 , 2.9439
, 2.9439 , - 0.5312 , - 0.5312 , - 0.5312 , - 0.5312 , 33.8114 , 33.8114 ,
33.8114 , 33.8114 , 0.2473 , 0.2473 , 0.2473 , 0.2473 , 0.1182 , 0.1182 ,
0.1182 , 0.1182 , - 0.3262 , - 0.3262 , - 0.3262 , - 0.3262 , 0.8 , 0.8 , 0.8
, 0.8 , 0.0014 , 0.0014 , 0.0014 , 0.0014 , 0.0013 , 0.0013 , 0.0013 , 0.0013
, 52.6965 , 52.6965 , 52.6965 , 52.6965 , 0.0077 , 0.0077 , 0.0077 , 0.0077 ,
- 0.3354 , - 0.3354 , - 0.3354 , - 0.3354 , - 0.3489 , - 0.3489 , - 0.3489 ,
- 0.3489 , 0.382 , 0.382 , 0.382 , 0.382 , - 0.09634 , - 0.09634 , - 0.09634
, - 0.09634 , 0.06447 , 0.06447 , 0.06447 , 0.06447 , - 0.0493 , - 0.0493 , -
0.0493 , - 0.0493 , - 0.0436 , - 0.0436 , - 0.0436 , - 0.0436 , 101325.0 ,
0.01 , 0.01 , 0.01 , 0.01 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0015 , 0.0015 , 0.0015
, 0.0015 , 8.5E-5 , 8.5E-5 , 8.5E-5 , 8.5E-5 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.9 , 0.9 , 0.9 , 0.9 , - 0.4 , - 0.4 , - 0.4 , - 0.4 ,
287.058 , 0.215 , 0.215 , 0.215 , 0.215 , 0.09 , 0.09 , 0.09 , 0.09 , 273.0 ,
0.229 , 0.229 , 0.229 , 0.229 , 0.5 , 0.5 , 0.5 , 0.5 , 0.0 , 0.0 , 0.847 ,
0.693 , { 0.0 , 0.01 , 0.02 , 0.03 , 0.04 , 0.05 , 0.06 , 0.07 , 0.08 , 0.09
, 0.1 , 0.11 , 0.12 , 0.13 , 0.14 , 0.15 , 0.15999999999999998 ,
0.16999999999999998 , 0.18 , 0.19 , 0.19999999999999998 , 0.21 ,
0.21999999999999997 , 0.22999999999999998 , 0.24 , 0.25 , 0.26 , 0.27 ,
0.27999999999999997 , 0.29 , 0.3 } , 0.01 , 0.01 , 0.001 , 0.01 , 0.0 , 0.0 ,
0.0475 , 0.0475 , 0.0475 , 0.0475 , 9.81 , 0.0 , 0.0 , 0.0 , 0.0 , 0.283 ,
0.15 , 0.15 , 0.15 , 0.15 , 1.0 , 1.0 , 1.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 ,
1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 1.0 , 0.0 , 0.0 ,
330.0 , 0.4 , 0.4 , 0.4 , 0.4 , 0.5 , 0.5 , 0.5 , 0.5 , 1.0 , 1.0 , 1.0 , 1.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , { 1.2 , 1.2 } ,
125.66370614359172 , 0.0 , 1.0 , 0.0 , 0.0 , - 4.0 , 0.0 , - 4.0 , 0.0 , -
4.0 , 0.0 , - 4.0 , 7.0E+6 , 2.0E+6 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , -
1.0 , 0.7 , 0.78539816339744828 , 0.0 , 2.2204460492503131E-16 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , - 0.5 , 0.0 , 0.0 , 0.5 , - 0.5 , 0.5 , {
3.1415926535897931 , 3.1415926535897931 , 3.1415926535897931 ,
3.1415926535897931 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 ,
{ 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 } , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 ,
0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , 1.0 ,
0.0 , 0.0 , 0.0 , 0.0 , - 1.0 , 0.7 , 0.78539816339744828 , 0.0 ,
2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 10000.0 , 1.0E+6 , { 0.0 , 0.0
, 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0
, 2.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , - 1.0 , 0.30000000000000004 ,
0.78539816339744828 , 0.0 , 2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0
, 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } ,
10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 ,
0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 2.0 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , -
1.0 , 0.30000000000000004 , 0.78539816339744828 , 0.0 ,
2.2204460492503131E-16 , 0.0 , 1.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 10000.0 , 1.0E+6 , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 } , 10000.0 , 1.0E+6 , { 0.0 , 0.0
, 0.0 } , { 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
0.0 , 0.0 } , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0
, 2.0 , 0.0 , - 5.0 , 5.0 , 0.0 , { 1.0 , 1.0 , 1.0 } , 0.0 , { 0.0 , 0.0 } ,
{ - 1.0 , 1.0 } , 20000.0 , 1000.0 , 0.0 , 0.0 , 0.0 , { 0.283 , 0.283 ,
0.283 , 0.283 } , 0 , { 0 , 1 , 0 , 0 , 1 , 1 , 1 , 0 } , 0 , { 0 , 1 , 0 , 0
, 1 , 1 , 1 , 0 } , 0 , { 0 , 1 , 0 , 0 , 1 , 1 , 1 , 0 } , 0 , { 0 , 1 , 0 ,
0 , 1 , 1 , 1 , 0 } , { 0.0 , 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 } ,
{ 0.0 , 0.0 , 0.0 , 0.0 } , { 0.0 , 0.0 , 0.0 , 0.0 } } ; static void
kacppyq1hi ( real_T rhoz , real_T omega , real_T * Re , real_T * Fz ) ;
static void idsfnt51tf ( const real_T a_data [ ] , const int32_T a_size [ 2 ]
, real_T y_data [ ] , int32_T y_size [ 2 ] ) ; static real_T mw400ki20b (
real_T Re , real_T omega , real_T Vx , real_T b_VXLOW , real_T b_kappamax ) ;
static real_T m0bj1boftk ( real_T kappa , real_T Vx , real_T Fz , real_T
b_gamma , real_T LONGVL , real_T FNOMIN , real_T b_FZMIN , real_T b_FZMAX ,
real_T press , real_T NOMPRES , real_T PRESMIN , real_T PRESMAX , real_T PCX1
, real_T PDX1 , real_T PDX2 , real_T PDX3 , real_T PEX1 , real_T PEX2 ,
real_T PEX3 , real_T PEX4 , real_T PKX1 , real_T PKX2 , real_T PKX3 , real_T
PHX1 , real_T PHX2 , real_T PVX1 , real_T PVX2 , real_T PPX1 , real_T PPX2 ,
real_T PPX3 , real_T PPX4 , real_T lam_Fzo , real_T lam_muV , real_T lam_mux
, real_T lam_Kxkappa , real_T lam_Cx , real_T lam_Ex , real_T lam_Hx , real_T
lam_Vx ) ; static real_T ifxdy0al4w ( real_T Fz , real_T omega , real_T Vx ,
real_T press , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY7 , real_T
QSY8 , real_T UNLOADED_RADIUS , real_T b_FZMIN , real_T b_FZMAX , real_T
PRESMIN , real_T PRESMAX ) ; static real_T isaiucurex ( real_T Fx , real_T Fz
, real_T omega , real_T Vx , real_T press , real_T FNOMIN , real_T NOMPRES ,
real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY4 , real_T QSY5 , real_T
QSY6 , real_T QSY7 , real_T QSY8 , real_T b_gamma , real_T lam_My , real_T
UNLOADED_RADIUS , real_T b_FZMAX , real_T PRESMIN , real_T PRESMAX ) ; static
real_T c42svqng1d ( real_T Fz , real_T omega , real_T Tamb , real_T Fpl ,
real_T Cr , real_T Kt , real_T Tmeas , real_T Re , real_T b_FZMIN , real_T
b_FZMAX , real_T TMIN , real_T TMAX ) ; static void hewkpcvg5g ( real_T
Ftire_x , real_T Ftire_y , real_T b_Fxtire_sat , real_T b_Fytire_sat , real_T
* Ftire_xs , real_T * Ftire_ys ) ; static void kacppyq1hi ( real_T rhoz ,
real_T omega , real_T * Re , real_T * Fz ) { * Re = 0.0 * muDoubleScalarAbs (
omega ) + rhoz ; if ( * Re < 0.001 ) { * Re = 0.001 ; } * Fz = ( rtNaN ) ; }
static void idsfnt51tf ( const real_T a_data [ ] , const int32_T a_size [ 2 ]
, real_T y_data [ ] , int32_T y_size [ 2 ] ) { real_T z1_data ; int32_T
loop_ub ; y_size [ 1 ] = ( int8_T ) a_size [ 1 ] ; loop_ub = y_size [ 1 ] - 1
; if ( 0 <= loop_ub ) { memcpy ( & z1_data , & y_data [ 0 ] , ( loop_ub + 1 )
* sizeof ( real_T ) ) ; } if ( 0 <= y_size [ 1 ] - 1 ) { z1_data = a_data [ 0
] * a_data [ 0 ] ; } y_size [ 0 ] = 1 ; loop_ub = y_size [ 1 ] - 1 ; if ( 0
<= loop_ub ) { memcpy ( & y_data [ 0 ] , & z1_data , ( loop_ub + 1 ) * sizeof
( real_T ) ) ; } } static real_T mw400ki20b ( real_T Re , real_T omega ,
real_T Vx , real_T b_VXLOW , real_T b_kappamax ) { real_T kappa ; real_T
Vxpabs ; int32_T b_trueCount ; real_T f_data ; real_T Vxpabs_data ; real_T
tmp_data ; int32_T Vxpabs_size [ 2 ] ; int32_T tmp_size [ 2 ] ; Vxpabs =
muDoubleScalarAbs ( Vx ) ; b_trueCount = 0 ; if ( Vxpabs < b_VXLOW ) {
b_trueCount = 1 ; } Vxpabs_size [ 0 ] = 1 ; Vxpabs_size [ 1 ] = b_trueCount ;
if ( 0 <= b_trueCount - 1 ) { Vxpabs_data = Vxpabs / b_VXLOW ; } idsfnt51tf (
& Vxpabs_data , Vxpabs_size , & tmp_data , tmp_size ) ; if ( 0 <= b_trueCount
- 1 ) { f_data = 2.0 * b_VXLOW / ( 3.0 - tmp_data ) ; } if ( Vxpabs < b_VXLOW
) { Vxpabs = f_data ; } kappa = ( Re * omega - Vx ) / Vxpabs ; b_trueCount =
0 ; if ( kappa < - b_kappamax ) { b_trueCount = 1 ; } if ( 0 <= b_trueCount -
1 ) { kappa = - b_kappamax ; } if ( kappa > b_kappamax ) { kappa = b_kappamax
; } return kappa ; } static real_T m0bj1boftk ( real_T kappa , real_T Vx ,
real_T Fz , real_T b_gamma , real_T LONGVL , real_T FNOMIN , real_T b_FZMIN ,
real_T b_FZMAX , real_T press , real_T NOMPRES , real_T PRESMIN , real_T
PRESMAX , real_T PCX1 , real_T PDX1 , real_T PDX2 , real_T PDX3 , real_T PEX1
, real_T PEX2 , real_T PEX3 , real_T PEX4 , real_T PKX1 , real_T PKX2 ,
real_T PKX3 , real_T PHX1 , real_T PHX2 , real_T PVX1 , real_T PVX2 , real_T
PPX1 , real_T PPX2 , real_T PPX3 , real_T PPX4 , real_T lam_Fzo , real_T
lam_muV , real_T lam_mux , real_T lam_Kxkappa , real_T lam_Cx , real_T lam_Ex
, real_T lam_Hx , real_T lam_Vx ) { real_T Fxo ; real_T dpi ; real_T dfz ;
real_T kappa_x ; real_T Vsx ; real_T Cx ; real_T unusedU0 ; int32_T trueCount
; real_T k_data ; real_T unusedU0_data ; real_T tmp_data ; int32_T
unusedU0_size [ 2 ] ; int32_T tmp_size [ 2 ] ; real_T b_idx_0 ; real_T
f_idx_0 ; real_T g_idx_0 ; real_T h_idx_0 ; real_T Cx_tmp ; b_idx_0 = Fz ; if
( Fz < b_FZMIN ) { b_idx_0 = b_FZMIN ; } if ( b_idx_0 > b_FZMAX ) { b_idx_0 =
b_FZMAX ; } dfz = press ; if ( press < PRESMIN ) { dfz = PRESMIN ; } if ( dfz
> PRESMAX ) { dfz = PRESMAX ; } dpi = ( dfz - NOMPRES ) / NOMPRES ; dfz = (
b_idx_0 - FNOMIN * lam_Fzo ) / FNOMIN * lam_Fzo ; kappa_x = ( PHX2 * dfz +
PHX1 ) * lam_Hx + kappa ; Vsx = - muDoubleScalarAbs ( Vx ) * kappa ; Vsx =
lam_mux / ( muDoubleScalarSqrt ( Vsx * Vsx ) * lam_muV / LONGVL + 1.0 ) ; Cx
= PCX1 * lam_Cx ; f_idx_0 = Cx ; if ( Cx < 0.0 ) { f_idx_0 = 0.0 ; } Cx_tmp =
dpi * dpi ; Cx = ( ( PPX3 * dpi + 1.0 ) + Cx_tmp * PPX4 ) * ( PDX2 * dfz +
PDX1 ) * ( 1.0 - b_gamma * b_gamma * PDX3 ) * Vsx * b_idx_0 ; g_idx_0 = Cx ;
if ( Cx < 0.0 ) { g_idx_0 = 0.0 ; } Cx = ( ( PEX2 * dfz + PEX1 ) + dfz * dfz
* PEX3 ) * ( 1.0 - muDoubleScalarTanh ( 10.0 * kappa_x ) * PEX4 ) * lam_Ex ;
h_idx_0 = Cx ; if ( Cx > 1.0 ) { h_idx_0 = 1.0 ; } Cx = f_idx_0 * g_idx_0 ;
unusedU0 = muDoubleScalarAbs ( Cx ) ; trueCount = 0 ; if ( unusedU0 < 0.1 ) {
trueCount = 1 ; } unusedU0_size [ 0 ] = 1 ; unusedU0_size [ 1 ] = trueCount ;
if ( 0 <= trueCount - 1 ) { unusedU0_data = unusedU0 / 0.1 ; } idsfnt51tf ( &
unusedU0_data , unusedU0_size , & tmp_data , tmp_size ) ; if ( 0 <= trueCount
- 1 ) { k_data = 0.2 / ( 3.0 - tmp_data ) ; } if ( unusedU0 < 0.1 ) {
unusedU0 = k_data ; } trueCount = 0 ; if ( Cx < 0.0 ) { trueCount = 1 ; } if
( 0 <= trueCount - 1 ) { k_data = - unusedU0 ; } if ( Cx < 0.0 ) { unusedU0 =
k_data ; } dpi = ( PKX2 * dfz + PKX1 ) * b_idx_0 * muDoubleScalarExp ( PKX3 *
dfz ) * ( ( PPX1 * dpi + 1.0 ) + Cx_tmp * PPX2 ) * lam_Kxkappa / unusedU0 ;
dpi *= kappa_x ; Fxo = muDoubleScalarSin ( muDoubleScalarAtan ( dpi - ( dpi -
muDoubleScalarAtan ( dpi ) ) * h_idx_0 ) * f_idx_0 ) * g_idx_0 + ( PVX2 * dfz
+ PVX1 ) * b_idx_0 * ( Vsx * 10.0 / ( 9.0 * Vsx + 1.0 ) ) * lam_Vx ; return
Fxo ; } static real_T ifxdy0al4w ( real_T Fz , real_T omega , real_T Vx ,
real_T press , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T QSY7 , real_T
QSY8 , real_T UNLOADED_RADIUS , real_T b_FZMIN , real_T b_FZMAX , real_T
PRESMIN , real_T PRESMAX ) { real_T b_idx_0 ; real_T d_idx_0 ; b_idx_0 =
press ; if ( press < PRESMIN ) { b_idx_0 = PRESMIN ; } if ( b_idx_0 > PRESMAX
) { b_idx_0 = PRESMAX ; } d_idx_0 = Fz ; if ( Fz < b_FZMIN ) { d_idx_0 =
b_FZMIN ; } if ( d_idx_0 > b_FZMAX ) { d_idx_0 = b_FZMAX ; } return ( ( QSY2
* muDoubleScalarAbs ( Vx ) + QSY1 ) + Vx * Vx * QSY3 ) * ( muDoubleScalarTanh
( omega ) * UNLOADED_RADIUS ) * ( muDoubleScalarPower ( d_idx_0 , QSY7 ) *
muDoubleScalarPower ( b_idx_0 , QSY8 ) ) ; } static real_T isaiucurex (
real_T Fx , real_T Fz , real_T omega , real_T Vx , real_T press , real_T
FNOMIN , real_T NOMPRES , real_T QSY1 , real_T QSY2 , real_T QSY3 , real_T
QSY4 , real_T QSY5 , real_T QSY6 , real_T QSY7 , real_T QSY8 , real_T b_gamma
, real_T lam_My , real_T UNLOADED_RADIUS , real_T b_FZMAX , real_T PRESMIN ,
real_T PRESMAX ) { real_T b_idx_0 ; real_T d_idx_0 ; b_idx_0 = press ; if (
press < PRESMIN ) { b_idx_0 = PRESMIN ; } if ( b_idx_0 > PRESMAX ) { b_idx_0
= PRESMAX ; } d_idx_0 = Fz ; if ( Fz < 0.0 ) { d_idx_0 = 0.0 ; } if ( d_idx_0
> b_FZMAX ) { d_idx_0 = b_FZMAX ; } return ( ( ( ( QSY2 * Fx / FNOMIN + QSY1
) + muDoubleScalarAbs ( Vx / 16.7 ) * QSY3 ) + muDoubleScalarPower ( Vx /
16.7 , 4.0 ) * QSY4 ) + ( QSY6 * d_idx_0 / FNOMIN + QSY5 ) * ( b_gamma *
b_gamma ) ) * ( muDoubleScalarTanh ( omega ) * d_idx_0 * UNLOADED_RADIUS ) *
( muDoubleScalarPower ( d_idx_0 / FNOMIN , QSY7 ) * muDoubleScalarPower (
b_idx_0 / NOMPRES , QSY8 ) ) * lam_My ; } static real_T c42svqng1d ( real_T
Fz , real_T omega , real_T Tamb , real_T Fpl , real_T Cr , real_T Kt , real_T
Tmeas , real_T Re , real_T b_FZMIN , real_T b_FZMAX , real_T TMIN , real_T
TMAX ) { real_T b_idx_0 ; real_T d_idx_0 ; b_idx_0 = Tamb ; if ( Tamb < TMIN
) { b_idx_0 = TMIN ; } if ( b_idx_0 > TMAX ) { b_idx_0 = TMAX ; } d_idx_0 =
Fz ; if ( Fz < b_FZMIN ) { d_idx_0 = b_FZMIN ; } if ( d_idx_0 > b_FZMAX ) {
d_idx_0 = b_FZMAX ; } return ( d_idx_0 * Cr * 0.001 / ( ( b_idx_0 - Tmeas ) *
Kt + 1.0 ) + - Fpl ) * ( muDoubleScalarTanh ( omega ) * Re ) ; } void
ptwb5m53nr ( real_T cved3liee0 , real_T hr35hjpkhm , real_T nr4nhitcji ,
real_T jrgdlfbz0l , real_T k2sxinhxgw , real_T hv2idhietl , real_T ashlevpkyl
, real_T awiwrbj1ah , real_T inzpjy4lsf , real_T hlmrktqqxx , real_T
nskttisvdw , real_T gx2hm5rb2y , const real_T * j5fczfhdct , real_T
hogvqsfuar , real_T b044mnnsii , real_T gf4qpdl150 , real_T pu1ucopikz ,
real_T oast2q50w1 , real_T pcxjf2dejm , real_T ciupjj5jym , real_T ejxwq2ptzb
, real_T al51nl4udn , real_T dgtanepmh3 , real_T pzgccsn2wd , real_T
camr2op5y5 , real_T keqisnbd3f , real_T dhjbvde1ql , real_T itr0vkexlm ,
real_T fb1lsx4wru , real_T ch5mu4pvuj , real_T ffca2wfrbb , real_T gvisb41nzp
, real_T kzpuc5zaqp , real_T lxinzmxu4z , real_T b5rhrqe32p , real_T
apc4wkkzj0 , real_T aqcvmgvimo , const real_T * bn0g4xdsr2 , real_T
f1zwljlqis , real_T faetpfbe3t , real_T f2wrfj3ld4 , real_T pj0acbgno5 ,
real_T jdp0ygo3rk , const real_T m3cuefccje [ 3 ] , const real_T kktb55loxf [
3 ] , const real_T eonbpbm1ha [ 9 ] , real_T fk1k5ewp1k , real_T ptghaz5var ,
real_T oku1yjbub2 , real_T b4mwug2qvn , real_T kswf03qlmx , real_T ev0nmrvz3n
, real_T gmukh33j1x , real_T ogftb2kvic , real_T hovfcz1beb , real_T
cnhq453n1f , real_T pkzjbcphib , real_T msi2x0cy5n , real_T amqujbosc0 ,
real_T ewmdujvrwd , real_T mc1li10ian , const real_T i5qknzmimx [ 3 ] , const
real_T k2ajbqqlbw [ 3 ] , const real_T c1tj0ta223 [ 9 ] , real_T cghblzuxit ,
real_T nnclxiugbw , real_T k3l0t243jz , real_T j3afmcxwz5 , real_T a3e0qsj3au
, real_T mkagm5ibpa , real_T bi25pt2vjy , real_T lmhxu3lxab , real_T
envxrls2yl , real_T iz3vm40vgt , real_T baznp0pjy0 , real_T l1g1n0fail ,
real_T ldjsaiwmlj , real_T lvflwdxi5c , real_T fbu1d4l3xg , real_T lyrupr0dj4
, real_T gkf12fuftl , real_T ezcoorwedf , real_T phwbwigd5c , real_T
k3l0glmlg0 , real_T pnspslh2fe , real_T a3qmcmhclv , real_T hizlzr3fbv ,
real_T nabnbe0jtn , real_T kihhma0xf1 , real_T cf0v1zbgxi , real_T kiu1b33l4h
, real_T * fyn4ujdhcm , real_T * njhenvfe4e , ikqrgkdcac * localB , real_T
rtp_FZMAX , real_T rtp_FZMIN , real_T rtp_VXLOW , real_T rtp_kappamax ) {
real_T Fx ; real_T Re ; real_T b_FzTire ; real_T eonbpbm1ha_p [ 9 ] ; int32_T
i ; real_T Fx_tmp ; localB -> cngbrzew0c [ 0 ] = k2sxinhxgw ; localB ->
cngbrzew0c [ 1 ] = hv2idhietl ; localB -> cngbrzew0c [ 2 ] = ashlevpkyl ;
localB -> cngbrzew0c [ 3 ] = awiwrbj1ah ; localB -> cngbrzew0c [ 4 ] =
inzpjy4lsf ; localB -> kvxvdkvc3b [ 0 ] = hlmrktqqxx ; localB -> kvxvdkvc3b [
1 ] = nskttisvdw ; localB -> kvxvdkvc3b [ 2 ] = gx2hm5rb2y ; localB ->
kvxvdkvc3b [ 3 ] = * j5fczfhdct ; localB -> kvxvdkvc3b [ 4 ] = hogvqsfuar ;
localB -> kvxvdkvc3b [ 5 ] = b044mnnsii ; localB -> kvxvdkvc3b [ 6 ] =
gf4qpdl150 ; localB -> kvxvdkvc3b [ 7 ] = pu1ucopikz ; localB -> kvxvdkvc3b [
8 ] = oast2q50w1 ; localB -> kvxvdkvc3b [ 9 ] = pcxjf2dejm ; localB ->
kvxvdkvc3b [ 10 ] = ciupjj5jym ; localB -> kvxvdkvc3b [ 11 ] = ejxwq2ptzb ;
localB -> kvxvdkvc3b [ 12 ] = al51nl4udn ; localB -> kvxvdkvc3b [ 13 ] =
dgtanepmh3 ; localB -> kvxvdkvc3b [ 14 ] = pzgccsn2wd ; localB -> kvxvdkvc3b
[ 15 ] = camr2op5y5 ; localB -> kvxvdkvc3b [ 16 ] = keqisnbd3f ; localB ->
kvxvdkvc3b [ 17 ] = dhjbvde1ql ; localB -> kvxvdkvc3b [ 18 ] = itr0vkexlm ;
localB -> kvxvdkvc3b [ 19 ] = fb1lsx4wru ; localB -> kvxvdkvc3b [ 20 ] =
ch5mu4pvuj ; localB -> kvxvdkvc3b [ 21 ] = ffca2wfrbb ; localB -> kvxvdkvc3b
[ 22 ] = gvisb41nzp ; localB -> kvxvdkvc3b [ 23 ] = kzpuc5zaqp ; localB ->
kvxvdkvc3b [ 24 ] = lxinzmxu4z ; localB -> kvxvdkvc3b [ 25 ] = b5rhrqe32p ;
localB -> kvxvdkvc3b [ 26 ] = apc4wkkzj0 ; localB -> kvxvdkvc3b [ 27 ] =
aqcvmgvimo ; localB -> kvxvdkvc3b [ 28 ] = * bn0g4xdsr2 ; localB ->
kvxvdkvc3b [ 29 ] = f1zwljlqis ; localB -> kvxvdkvc3b [ 30 ] = faetpfbe3t ;
localB -> kvxvdkvc3b [ 31 ] = f2wrfj3ld4 ; localB -> kvxvdkvc3b [ 32 ] =
pj0acbgno5 ; localB -> kvxvdkvc3b [ 33 ] = jdp0ygo3rk ; localB -> j2px0ljv0m
[ 0 ] = * j5fczfhdct ; localB -> j2px0ljv0m [ 1 ] = fk1k5ewp1k ; localB ->
j2px0ljv0m [ 2 ] = ptghaz5var ; localB -> j2px0ljv0m [ 3 ] = oku1yjbub2 ;
localB -> j2px0ljv0m [ 4 ] = b4mwug2qvn ; localB -> j2px0ljv0m [ 5 ] =
kswf03qlmx ; localB -> j2px0ljv0m [ 6 ] = ev0nmrvz3n ; localB -> j2px0ljv0m [
7 ] = gmukh33j1x ; localB -> j2px0ljv0m [ 8 ] = ogftb2kvic ; localB ->
j2px0ljv0m [ 9 ] = hovfcz1beb ; localB -> j2px0ljv0m [ 10 ] = cnhq453n1f ;
localB -> j2px0ljv0m [ 11 ] = pkzjbcphib ; localB -> j2px0ljv0m [ 12 ] =
msi2x0cy5n ; localB -> j2px0ljv0m [ 13 ] = amqujbosc0 ; localB -> j2px0ljv0m
[ 14 ] = ewmdujvrwd ; localB -> j2px0ljv0m [ 15 ] = mc1li10ian ; localB ->
p4bflvewss [ 0 ] = * j5fczfhdct ; localB -> p4bflvewss [ 1 ] = nnclxiugbw ;
localB -> p4bflvewss [ 2 ] = k3l0t243jz ; localB -> p4bflvewss [ 3 ] =
j3afmcxwz5 ; localB -> p4bflvewss [ 4 ] = a3e0qsj3au ; localB -> p4bflvewss [
5 ] = mkagm5ibpa ; localB -> p4bflvewss [ 6 ] = bi25pt2vjy ; localB ->
p4bflvewss [ 7 ] = lmhxu3lxab ; localB -> p4bflvewss [ 8 ] = envxrls2yl ;
localB -> p4bflvewss [ 9 ] = iz3vm40vgt ; localB -> p4bflvewss [ 10 ] =
baznp0pjy0 ; localB -> p4bflvewss [ 11 ] = l1g1n0fail ; localB -> p4bflvewss
[ 12 ] = ldjsaiwmlj ; localB -> p4bflvewss [ 13 ] = lvflwdxi5c ; localB ->
p4bflvewss [ 14 ] = fbu1d4l3xg ; localB -> p4bflvewss [ 15 ] = lyrupr0dj4 ;
localB -> p4bflvewss [ 16 ] = gkf12fuftl ; localB -> p4bflvewss [ 17 ] =
ezcoorwedf ; localB -> p4bflvewss [ 18 ] = phwbwigd5c ; localB -> p4bflvewss
[ 19 ] = k3l0glmlg0 ; localB -> p4bflvewss [ 20 ] = pnspslh2fe ; localB ->
p4bflvewss [ 21 ] = a3qmcmhclv ; localB -> p4bflvewss [ 22 ] = hizlzr3fbv ;
localB -> p4bflvewss [ 23 ] = nabnbe0jtn ; switch ( ( int32_T ) kiu1b33l4h )
{ case 0 : Re = cved3liee0 ; break ; case 1 : kacppyq1hi ( cghblzuxit ,
nr4nhitcji , & Re , & b_FzTire ) ; break ; case 2 : Re = cved3liee0 ; break ;
default : Re = cved3liee0 ; break ; } b_FzTire = mw400ki20b ( cved3liee0 ,
nr4nhitcji , jrgdlfbz0l , rtp_VXLOW , rtp_kappamax ) ; switch ( ( int32_T )
kihhma0xf1 ) { case 0 : Fx = hr35hjpkhm ; if ( hr35hjpkhm < rtp_FZMIN ) { Fx
= rtp_FZMIN ; } if ( Fx > rtp_FZMAX ) { Fx = rtp_FZMAX ; } Fx_tmp = localB ->
cngbrzew0c [ 2 ] * b_FzTire ; Fx = muDoubleScalarSin ( muDoubleScalarAtan (
Fx_tmp - ( Fx_tmp - muDoubleScalarAtan ( Fx_tmp ) ) * localB -> cngbrzew0c [
3 ] ) * localB -> cngbrzew0c [ 1 ] ) * localB -> cngbrzew0c [ 0 ] * ( Fx *
localB -> cngbrzew0c [ 4 ] ) ; break ; case 2 : Fx = m0bj1boftk ( b_FzTire ,
jrgdlfbz0l , hr35hjpkhm , localB -> kvxvdkvc3b [ 0 ] , localB -> kvxvdkvc3b [
1 ] , localB -> kvxvdkvc3b [ 2 ] , rtp_FZMIN , rtp_FZMAX , localB ->
kvxvdkvc3b [ 3 ] , localB -> kvxvdkvc3b [ 4 ] , localB -> kvxvdkvc3b [ 5 ] ,
localB -> kvxvdkvc3b [ 6 ] , localB -> kvxvdkvc3b [ 7 ] , localB ->
kvxvdkvc3b [ 8 ] , localB -> kvxvdkvc3b [ 9 ] , localB -> kvxvdkvc3b [ 10 ] ,
localB -> kvxvdkvc3b [ 11 ] , localB -> kvxvdkvc3b [ 12 ] , localB ->
kvxvdkvc3b [ 13 ] , localB -> kvxvdkvc3b [ 14 ] , localB -> kvxvdkvc3b [ 15 ]
, localB -> kvxvdkvc3b [ 16 ] , localB -> kvxvdkvc3b [ 17 ] , localB ->
kvxvdkvc3b [ 18 ] , localB -> kvxvdkvc3b [ 19 ] , localB -> kvxvdkvc3b [ 20 ]
, localB -> kvxvdkvc3b [ 21 ] , localB -> kvxvdkvc3b [ 22 ] , localB ->
kvxvdkvc3b [ 23 ] , localB -> kvxvdkvc3b [ 24 ] , localB -> kvxvdkvc3b [ 25 ]
, localB -> kvxvdkvc3b [ 26 ] , localB -> kvxvdkvc3b [ 27 ] , localB ->
kvxvdkvc3b [ 28 ] , localB -> kvxvdkvc3b [ 29 ] , localB -> kvxvdkvc3b [ 30 ]
, localB -> kvxvdkvc3b [ 31 ] , localB -> kvxvdkvc3b [ 32 ] , localB ->
kvxvdkvc3b [ 33 ] ) ; break ; case 3 : Fx = hr35hjpkhm ; if ( hr35hjpkhm <
rtp_FZMIN ) { Fx = rtp_FZMIN ; } if ( Fx > rtp_FZMAX ) { Fx = rtp_FZMAX ; }
for ( i = 0 ; i < 3 ; i ++ ) { eonbpbm1ha_p [ 3 * i ] = eonbpbm1ha [ i ] ;
eonbpbm1ha_p [ 1 + 3 * i ] = eonbpbm1ha [ i + 3 ] ; eonbpbm1ha_p [ 2 + 3 * i
] = eonbpbm1ha [ i + 6 ] ; } Fx = interp2_5YaFqjgU ( m3cuefccje , kktb55loxf
, eonbpbm1ha_p , b_FzTire , Fx ) * localB -> cngbrzew0c [ 4 ] ; break ;
default : Fx = 0.0 ; b_FzTire = 0.0 ; break ; } switch ( ( int32_T )
cf0v1zbgxi ) { case 0 : localB -> imuoerh5jm = 0.0 ; break ; case 1 : localB
-> imuoerh5jm = ifxdy0al4w ( hr35hjpkhm , nr4nhitcji , jrgdlfbz0l , localB ->
j2px0ljv0m [ 0 ] , localB -> j2px0ljv0m [ 3 ] , localB -> j2px0ljv0m [ 4 ] ,
localB -> j2px0ljv0m [ 5 ] , localB -> j2px0ljv0m [ 9 ] , localB ->
j2px0ljv0m [ 10 ] , localB -> j2px0ljv0m [ 13 ] , rtp_FZMIN , rtp_FZMAX ,
localB -> j2px0ljv0m [ 14 ] , localB -> j2px0ljv0m [ 15 ] ) ; break ; case 2
: localB -> imuoerh5jm = isaiucurex ( Fx , hr35hjpkhm , nr4nhitcji ,
jrgdlfbz0l , localB -> j2px0ljv0m [ 0 ] , localB -> j2px0ljv0m [ 1 ] , localB
-> j2px0ljv0m [ 2 ] , localB -> j2px0ljv0m [ 3 ] , localB -> j2px0ljv0m [ 4 ]
, localB -> j2px0ljv0m [ 5 ] , localB -> j2px0ljv0m [ 6 ] , localB ->
j2px0ljv0m [ 7 ] , localB -> j2px0ljv0m [ 8 ] , localB -> j2px0ljv0m [ 9 ] ,
localB -> j2px0ljv0m [ 10 ] , localB -> j2px0ljv0m [ 11 ] , localB ->
j2px0ljv0m [ 12 ] , localB -> j2px0ljv0m [ 13 ] , rtp_FZMAX , localB ->
j2px0ljv0m [ 14 ] , localB -> j2px0ljv0m [ 15 ] ) ; break ; case 3 : Fx_tmp =
hr35hjpkhm ; if ( hr35hjpkhm < 0.0 ) { Fx_tmp = 0.0 ; } if ( Fx_tmp >
rtp_FZMAX ) { Fx_tmp = rtp_FZMAX ; } for ( i = 0 ; i < 3 ; i ++ ) {
eonbpbm1ha_p [ 3 * i ] = c1tj0ta223 [ i ] ; eonbpbm1ha_p [ 1 + 3 * i ] =
c1tj0ta223 [ i + 3 ] ; eonbpbm1ha_p [ 2 + 3 * i ] = c1tj0ta223 [ i + 6 ] ; }
localB -> imuoerh5jm = muDoubleScalarTanh ( nr4nhitcji ) * interp2_5YaFqjgU (
i5qknzmimx , k2ajbqqlbw , eonbpbm1ha_p , jrgdlfbz0l , Fx_tmp ) ; break ; case
4 : localB -> imuoerh5jm = c42svqng1d ( hr35hjpkhm , nr4nhitcji , localB ->
j2px0ljv0m [ 0 ] , localB -> j2px0ljv0m [ 3 ] , localB -> j2px0ljv0m [ 4 ] ,
localB -> j2px0ljv0m [ 5 ] , localB -> j2px0ljv0m [ 6 ] , Re , rtp_FZMIN ,
rtp_FZMAX , localB -> j2px0ljv0m [ 14 ] , localB -> j2px0ljv0m [ 15 ] ) ;
break ; default : localB -> imuoerh5jm = 0.0 ; break ; } localB -> dbw42rwkve
= Fx ; * fyn4ujdhcm = b_FzTire ; * njhenvfe4e = Re ; } void gnhczwf3q0 (
pa50wxsaaa * const hokadafud5 ) { if ( rtmGetTaskTime ( hokadafud5 , 0 ) !=
rtmGetTStart ( hokadafud5 ) ) { ssSetBlockStateForSolverChangedAtMajorStep (
hokadafud5 -> _mdlRefSfcnS ) ; } } void nm4ubjqz2k ( pa50wxsaaa * const
hokadafud5 ) { ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } void fw4l3ijud5 ( pa50wxsaaa * const hokadafud5 , real_T *
mi0h4y2kzi , real_T * jx5augwlqz , real_T * n0geutqbnv , i1lzbfmeqz * localB
, hznwrkfhta * localP ) { if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> cbtyne50cb = localP ->
P_1 ; localB -> hauge3fqzq = localP -> P_2 ; } * mi0h4y2kzi = localB ->
cbtyne50cb ; * jx5augwlqz = localB -> hauge3fqzq ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
ekcsb45f1m = localP -> P_3 ; } * n0geutqbnv = localB -> ekcsb45f1m ; } static
void hewkpcvg5g ( real_T Ftire_x , real_T Ftire_y , real_T b_Fxtire_sat ,
real_T b_Fytire_sat , real_T * Ftire_xs , real_T * Ftire_ys ) { real_T
theta_Ftire ; real_T Ftire_mag ; real_T Ftire_x_max ; real_T Ftire_x_max_tmp
; theta_Ftire = muDoubleScalarAtan2 ( Ftire_x , Ftire_y ) ; Ftire_x_max_tmp =
muDoubleScalarCos ( theta_Ftire ) ; Ftire_x_max = b_Fxtire_sat *
Ftire_x_max_tmp ; theta_Ftire = muDoubleScalarSin ( theta_Ftire ) ; Ftire_mag
= b_Fytire_sat * theta_Ftire ; Ftire_mag = b_Fxtire_sat * b_Fytire_sat /
muDoubleScalarSqrt ( Ftire_x_max * Ftire_x_max + Ftire_mag * Ftire_mag ) ;
Ftire_x_max = Ftire_mag * theta_Ftire ; theta_Ftire = Ftire_mag *
Ftire_x_max_tmp ; * Ftire_xs = Ftire_x ; if ( muDoubleScalarAbs ( Ftire_x ) >
muDoubleScalarAbs ( Ftire_x_max ) ) { * Ftire_xs = Ftire_x_max ; } * Ftire_ys
= Ftire_y ; if ( muDoubleScalarAbs ( Ftire_y ) > muDoubleScalarAbs (
theta_Ftire ) ) { * Ftire_ys = theta_Ftire ; } } void hzczw4rimi ( pa50wxsaaa
* const hokadafud5 , real_T * hnk0xxowmm , real_T * io1pn0hnwg , real_T *
av1e2e2zlq , real_T * amgwfcyfmi , real_T * hzkodf3i3c , real_T g2tnztcpzi [
4 ] , bpefjqedzq * localDW , hcqlainyez * localX ) { localX -> dgtbqd0og2 [ 0
] = becrktx0d0 . P_261 ; localX -> dgtbqd0og2 [ 1 ] = becrktx0d0 . P_261 ;
localX -> dgtbqd0og2 [ 2 ] = becrktx0d0 . P_261 ; localX -> dgtbqd0og2 [ 3 ]
= becrktx0d0 . P_261 ; localX -> boq0sjomkz = becrktx0d0 . P_266 ; localDW ->
czmfx0f2q0 = becrktx0d0 . P_504 ; * io1pn0hnwg = becrktx0d0 . P_276 ; if (
rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> n5tb00omor [ 0 ] = 0.0 ;
localX -> n5tb00omor [ 1 ] = 0.0 ; localX -> n5tb00omor [ 2 ] = 0.0 ; localX
-> n5tb00omor [ 3 ] = 0.0 ; localX -> bmsz0qfwwr [ 0 ] = 0.0 ; localX ->
bmsz0qfwwr [ 1 ] = 0.0 ; } localDW -> kvj4uckeqc = 1 ; * hnk0xxowmm =
becrktx0d0 . P_278 ; localX -> g4fxozrdb2 = becrktx0d0 . P_330 ; localDW ->
ok0qcfhc1h = becrktx0d0 . P_506 ; localX -> i12d3wngfk = becrktx0d0 . P_385 ;
localDW -> mjbxwgkncv = becrktx0d0 . P_508 ; localX -> betxkjviha =
becrktx0d0 . P_440 ; localDW -> nsc0idk5is = becrktx0d0 . P_510 ; localDW ->
bokb5rvw5x = 1 ; * av1e2e2zlq = becrktx0d0 . P_500 ; * hzkodf3i3c =
becrktx0d0 . P_501 ; * amgwfcyfmi = becrktx0d0 . P_502 ; g2tnztcpzi [ 0 ] =
becrktx0d0 . P_503 [ 0 ] ; g2tnztcpzi [ 1 ] = becrktx0d0 . P_503 [ 1 ] ;
g2tnztcpzi [ 2 ] = becrktx0d0 . P_503 [ 2 ] ; g2tnztcpzi [ 3 ] = becrktx0d0 .
P_503 [ 3 ] ; if ( rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> kcyjzyu2vu
= 0.0 ; } localDW -> cxn1gifobd = 1 ; if ( rtmIsFirstInitCond ( hokadafud5 )
) { localX -> ny5f4grmco = 0.0 ; localX -> cxpr0gz2hj = 0.0 ; } localDW ->
ew15w55ihb = 1 ; localDW -> hrozwqlazz = 1 ; if ( rtmIsFirstInitCond (
hokadafud5 ) ) { localX -> lqp2to1kjt = 0.0 ; } localDW -> p30ktu555o = 1 ; }
void ps1ayp5pv5 ( pa50wxsaaa * const hokadafud5 , real_T * hnk0xxowmm ,
real_T * io1pn0hnwg , real_T * av1e2e2zlq , real_T * amgwfcyfmi , real_T *
hzkodf3i3c , real_T g2tnztcpzi [ 4 ] , bpefjqedzq * localDW , hcqlainyez *
localX ) { localX -> dgtbqd0og2 [ 0 ] = becrktx0d0 . P_261 ; localX ->
dgtbqd0og2 [ 1 ] = becrktx0d0 . P_261 ; localX -> dgtbqd0og2 [ 2 ] =
becrktx0d0 . P_261 ; localX -> dgtbqd0og2 [ 3 ] = becrktx0d0 . P_261 ; localX
-> boq0sjomkz = becrktx0d0 . P_266 ; localDW -> czmfx0f2q0 = becrktx0d0 .
P_504 ; * io1pn0hnwg = becrktx0d0 . P_276 ; if ( rtmIsFirstInitCond (
hokadafud5 ) ) { localX -> n5tb00omor [ 0 ] = 0.0 ; localX -> n5tb00omor [ 1
] = 0.0 ; localX -> n5tb00omor [ 2 ] = 0.0 ; localX -> n5tb00omor [ 3 ] = 0.0
; localX -> bmsz0qfwwr [ 0 ] = 0.0 ; localX -> bmsz0qfwwr [ 1 ] = 0.0 ; }
localDW -> kvj4uckeqc = 1 ; * hnk0xxowmm = becrktx0d0 . P_278 ; localX ->
g4fxozrdb2 = becrktx0d0 . P_330 ; localDW -> ok0qcfhc1h = becrktx0d0 . P_506
; localX -> i12d3wngfk = becrktx0d0 . P_385 ; localDW -> mjbxwgkncv =
becrktx0d0 . P_508 ; localX -> betxkjviha = becrktx0d0 . P_440 ; localDW ->
nsc0idk5is = becrktx0d0 . P_510 ; localDW -> bokb5rvw5x = 1 ; * av1e2e2zlq =
becrktx0d0 . P_500 ; * hzkodf3i3c = becrktx0d0 . P_501 ; * amgwfcyfmi =
becrktx0d0 . P_502 ; g2tnztcpzi [ 0 ] = becrktx0d0 . P_503 [ 0 ] ; g2tnztcpzi
[ 1 ] = becrktx0d0 . P_503 [ 1 ] ; g2tnztcpzi [ 2 ] = becrktx0d0 . P_503 [ 2
] ; g2tnztcpzi [ 3 ] = becrktx0d0 . P_503 [ 3 ] ; } void g3iefm0j4w (
pa50wxsaaa * const hokadafud5 , bpefjqedzq * localDW , dn0l2t323g * localXdis
) { switch ( localDW -> pbnr1alend ) { case 0 : nm4ubjqz2k ( hokadafud5 ) ;
break ; case 1 : ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; localXdis -> kcyjzyu2vu = 1 ; break ; } localDW ->
pbnr1alend = - 1 ; switch ( localDW -> py0qqcx0x3 ) { case 0 : nm4ubjqz2k (
hokadafud5 ) ; break ; case 1 : ssSetBlockStateForSolverChangedAtMajorStep (
hokadafud5 -> _mdlRefSfcnS ) ; localXdis -> ny5f4grmco = 1 ; break ; }
localDW -> py0qqcx0x3 = - 1 ; switch ( localDW -> g1nszypg1o ) { case 0 :
nm4ubjqz2k ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> cxpr0gz2hj = 1 ; break ; } localDW -> g1nszypg1o = - 1 ; switch
( localDW -> ksj4vofnxt ) { case 0 : nm4ubjqz2k ( hokadafud5 ) ; break ; case
1 : ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS )
; localXdis -> lqp2to1kjt = 1 ; break ; } localDW -> ksj4vofnxt = - 1 ; }
void aoae4c423r ( real_T * hnk0xxowmm , real_T * io1pn0hnwg , real_T *
av1e2e2zlq , real_T * amgwfcyfmi , real_T * hzkodf3i3c , real_T g2tnztcpzi [
4 ] , id4lpjcjia * localB , bpefjqedzq * localDW ) { localDW -> cwhzvq3g0k =
true ; localDW -> clzbvhgwst = true ; localDW -> pbnr1alend = - 1 ; *
io1pn0hnwg = becrktx0d0 . P_276 ; * hnk0xxowmm = becrktx0d0 . P_278 ; localB
-> f2xqgnxkqm [ 0 ] = becrktx0d0 . P_292 [ 0 ] ; localB -> a1nh1kadu4 [ 0 ] =
becrktx0d0 . P_293 [ 0 ] ; localB -> f2xqgnxkqm [ 1 ] = becrktx0d0 . P_292 [
1 ] ; localB -> a1nh1kadu4 [ 1 ] = becrktx0d0 . P_293 [ 1 ] ; localB ->
f2xqgnxkqm [ 2 ] = becrktx0d0 . P_292 [ 2 ] ; localB -> a1nh1kadu4 [ 2 ] =
becrktx0d0 . P_293 [ 2 ] ; localB -> gbddmx5qus [ 0 ] = becrktx0d0 . P_297 [
0 ] ; localB -> bswxr3glt4 [ 0 ] = becrktx0d0 . P_298 [ 0 ] ; localB ->
gbddmx5qus [ 1 ] = becrktx0d0 . P_297 [ 1 ] ; localB -> bswxr3glt4 [ 1 ] =
becrktx0d0 . P_298 [ 1 ] ; localB -> gbddmx5qus [ 2 ] = becrktx0d0 . P_297 [
2 ] ; localB -> bswxr3glt4 [ 2 ] = becrktx0d0 . P_298 [ 2 ] ; memcpy ( &
localB -> p21kvs5mbb [ 0 ] , & becrktx0d0 . P_294 [ 0 ] , 9U * sizeof (
real_T ) ) ; memcpy ( & localB -> crh3sglt3v [ 0 ] , & becrktx0d0 . P_299 [ 0
] , 9U * sizeof ( real_T ) ) ; localB -> kfqbvv4uff = becrktx0d0 . P_323 ;
localB -> oetza3lke4 = becrktx0d0 . P_324 ; localB -> l1cwkfgzdt = becrktx0d0
. P_325 ; localDW -> letpwa1hho = true ; localDW -> lbpmeols54 = true ;
localDW -> py0qqcx0x3 = - 1 ; localB -> f2oit4mz1m [ 0 ] = becrktx0d0 . P_347
[ 0 ] ; localB -> bcuad4qgnk [ 0 ] = becrktx0d0 . P_348 [ 0 ] ; localB ->
f2oit4mz1m [ 1 ] = becrktx0d0 . P_347 [ 1 ] ; localB -> bcuad4qgnk [ 1 ] =
becrktx0d0 . P_348 [ 1 ] ; localB -> f2oit4mz1m [ 2 ] = becrktx0d0 . P_347 [
2 ] ; localB -> bcuad4qgnk [ 2 ] = becrktx0d0 . P_348 [ 2 ] ; localB ->
nybfkmk1v2 [ 0 ] = becrktx0d0 . P_352 [ 0 ] ; localB -> fe2jbk1ow2 [ 0 ] =
becrktx0d0 . P_353 [ 0 ] ; localB -> nybfkmk1v2 [ 1 ] = becrktx0d0 . P_352 [
1 ] ; localB -> fe2jbk1ow2 [ 1 ] = becrktx0d0 . P_353 [ 1 ] ; localB ->
nybfkmk1v2 [ 2 ] = becrktx0d0 . P_352 [ 2 ] ; localB -> fe2jbk1ow2 [ 2 ] =
becrktx0d0 . P_353 [ 2 ] ; memcpy ( & localB -> bc3tmfjmfl [ 0 ] , &
becrktx0d0 . P_349 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
ie4eubfmr2 [ 0 ] , & becrktx0d0 . P_354 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> afa0svr0rr = becrktx0d0 . P_378 ; localB -> e41wl2nsj3 = becrktx0d0
. P_379 ; localB -> lzuculkkg0 = becrktx0d0 . P_380 ; localDW -> m1ndv25sb4 =
true ; localDW -> guacixjgv3 = true ; localDW -> g1nszypg1o = - 1 ; localB ->
idnuvsq50z [ 0 ] = becrktx0d0 . P_402 [ 0 ] ; localB -> k2magdngkl [ 0 ] =
becrktx0d0 . P_403 [ 0 ] ; localB -> idnuvsq50z [ 1 ] = becrktx0d0 . P_402 [
1 ] ; localB -> k2magdngkl [ 1 ] = becrktx0d0 . P_403 [ 1 ] ; localB ->
idnuvsq50z [ 2 ] = becrktx0d0 . P_402 [ 2 ] ; localB -> k2magdngkl [ 2 ] =
becrktx0d0 . P_403 [ 2 ] ; localB -> k4ryvi4c1f [ 0 ] = becrktx0d0 . P_407 [
0 ] ; localB -> awaqkahv5l [ 0 ] = becrktx0d0 . P_408 [ 0 ] ; localB ->
k4ryvi4c1f [ 1 ] = becrktx0d0 . P_407 [ 1 ] ; localB -> awaqkahv5l [ 1 ] =
becrktx0d0 . P_408 [ 1 ] ; localB -> k4ryvi4c1f [ 2 ] = becrktx0d0 . P_407 [
2 ] ; localB -> awaqkahv5l [ 2 ] = becrktx0d0 . P_408 [ 2 ] ; memcpy ( &
localB -> lfpjk1p50l [ 0 ] , & becrktx0d0 . P_404 [ 0 ] , 9U * sizeof (
real_T ) ) ; memcpy ( & localB -> bhtsxyrihr [ 0 ] , & becrktx0d0 . P_409 [ 0
] , 9U * sizeof ( real_T ) ) ; localB -> nx2qtlsqdh = becrktx0d0 . P_433 ;
localB -> j4bdy242sp = becrktx0d0 . P_434 ; localB -> ex2ckz41n1 = becrktx0d0
. P_435 ; localDW -> gihmnw5lcd = true ; localDW -> ffcbqtf0x4 = true ;
localDW -> ksj4vofnxt = - 1 ; localB -> fqxqkg1alg [ 0 ] = becrktx0d0 . P_457
[ 0 ] ; localB -> csf03krjk1 [ 0 ] = becrktx0d0 . P_458 [ 0 ] ; localB ->
fqxqkg1alg [ 1 ] = becrktx0d0 . P_457 [ 1 ] ; localB -> csf03krjk1 [ 1 ] =
becrktx0d0 . P_458 [ 1 ] ; localB -> fqxqkg1alg [ 2 ] = becrktx0d0 . P_457 [
2 ] ; localB -> csf03krjk1 [ 2 ] = becrktx0d0 . P_458 [ 2 ] ; localB ->
gv4e3mhryb [ 0 ] = becrktx0d0 . P_462 [ 0 ] ; localB -> mnmnycaifv [ 0 ] =
becrktx0d0 . P_463 [ 0 ] ; localB -> gv4e3mhryb [ 1 ] = becrktx0d0 . P_462 [
1 ] ; localB -> mnmnycaifv [ 1 ] = becrktx0d0 . P_463 [ 1 ] ; localB ->
gv4e3mhryb [ 2 ] = becrktx0d0 . P_462 [ 2 ] ; localB -> mnmnycaifv [ 2 ] =
becrktx0d0 . P_463 [ 2 ] ; memcpy ( & localB -> f4nd4h3rdi [ 0 ] , &
becrktx0d0 . P_459 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
cigblwahak [ 0 ] , & becrktx0d0 . P_464 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> m4domxuial = becrktx0d0 . P_488 ; localB -> nc1rcr52pc = becrktx0d0
. P_489 ; localB -> fjht5toahx = becrktx0d0 . P_490 ; localDW -> fvd2istvuu =
0 ; * av1e2e2zlq = becrktx0d0 . P_500 ; * hzkodf3i3c = becrktx0d0 . P_501 ; *
amgwfcyfmi = becrktx0d0 . P_502 ; g2tnztcpzi [ 0 ] = becrktx0d0 . P_503 [ 0 ]
; g2tnztcpzi [ 1 ] = becrktx0d0 . P_503 [ 1 ] ; g2tnztcpzi [ 2 ] = becrktx0d0
. P_503 [ 2 ] ; g2tnztcpzi [ 3 ] = becrktx0d0 . P_503 [ 3 ] ; } void
PassVeh7DOF ( pa50wxsaaa * const hokadafud5 , const real_T fo3cvtmfih [ 4 ] ,
const real_T dfx1ca0pmi [ 4 ] , const real_T pf4xf35zus [ 3 ] , const real_T
gxlrb30ei4 [ 4 ] , const real_T bv2zp3o4ji [ 4 ] , const real_T czlc2qmxmx [
4 ] , real_T * lfffcfi0vv , real_T * o4a5winsib , real_T * c040sjjy2f ,
real_T * hnk0xxowmm , real_T * io1pn0hnwg , real_T * hb0nga1cnl , real_T
cyqteuatay [ 4 ] , real_T av2ap4nkgj [ 4 ] , real_T * cqivd3kemx , real_T *
n0fjwjtmw3 , real_T * dfywnyxbtq , real_T * av1e2e2zlq , real_T * pu1mlebux4
, real_T * hxjzroc5ux , real_T * amgwfcyfmi , real_T * hzkodf3i3c , real_T
eueb01ol1w [ 4 ] , real_T g2tnztcpzi [ 4 ] , real_T ebhsrqq1o4 [ 4 ] , real_T
eplypn1mx4 [ 4 ] , id4lpjcjia * localB , bpefjqedzq * localDW , hcqlainyez *
localX , pcbmq2m11v * localZCE , dn0l2t323g * localXdis ) { real_T ffnn3i1mdg
[ 4 ] ; int32_T eufvenxnxf ; ZCEventType zcEvent ; real_T alfa_fr ; real_T
alfa_rl ; real_T Fz_rnom ; real_T Fx_fr ; real_T Fy_fl ; real_T Fy_fr ;
real_T xddot ; int8_T rtPrevAction ; int8_T rtAction ; real_T p13owk0emg [ 3
] ; real_T mtt4yva3gs_p ; real_T iywjngy1pp_p ; real_T jkml1dhgc4_p ; real_T
bdhjtvge12_p ; real_T eh1kt4tbfs_p ; real_T gdlhgdf2w4_p ; real_T
ewytrsohkb_p [ 3 ] ; real_T egwdhsr12b_p [ 3 ] ; real_T pdfylu1fax_p [ 3 ] ;
real_T dlf4omiy42_p [ 6 ] ; real_T okap0sparj_p [ 9 ] ; real_T ipxtggw2ad_p ;
real_T kiyqi1kpj4_p [ 12 ] ; real_T feixrhnufu_p [ 12 ] ; int32_T i ; real_T
okap0sparj_e [ 3 ] ; int32_T loop_ub ; real_T nd20r1di23_p ; real_T
nd20r1di23_idx_0 ; real_T nd20r1di23_idx_1 ; real_T nd20r1di23_idx_2 ; real_T
nkp14nzj3q_idx_0 ; real_T nkp14nzj3q_idx_1 ; real_T nkp14nzj3q_idx_2 ; real_T
nkp14nzj3q_idx_3 ; real_T lbi5iovzof_idx_0 ; real_T lbi5iovzof_idx_1 ; real_T
lbi5iovzof_idx_2 ; real_T lbi5iovzof_idx_3 ; real_T phs3p3rmuf_idx_1 ; real_T
phs3p3rmuf_idx_2 ; real_T Fz_idx_0 ; real_T Fz_idx_1 ; real_T Fz_idx_2 ;
real_T Fz_idx_3 ; real_T Fx_fl_tmp ; real_T Fx_fl_tmp_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> is5r5qizkw [ 0 ] = becrktx0d0 . P_176 ; localB -> is5r5qizkw [ 1
] = becrktx0d0 . P_176 ; localB -> is5r5qizkw [ 2 ] = becrktx0d0 . P_176 ;
localB -> is5r5qizkw [ 3 ] = becrktx0d0 . P_176 ; localB -> oxucuqlz4d =
becrktx0d0 . P_150 ; if ( localDW -> cwhzvq3g0k ) { localDW -> cwhzvq3g0k =
false ; localB -> dtdpfiz3ya = becrktx0d0 . P_263 ; } else { localB ->
dtdpfiz3ya = becrktx0d0 . P_262 ; } localB -> n2ifxcu5ka = becrktx0d0 . P_239
; } nkp14nzj3q_idx_0 = localX -> dgtbqd0og2 [ 0 ] ; nkp14nzj3q_idx_1 = localX
-> dgtbqd0og2 [ 1 ] ; nkp14nzj3q_idx_2 = localX -> dgtbqd0og2 [ 2 ] ;
nkp14nzj3q_idx_3 = localX -> dgtbqd0og2 [ 3 ] ; if ( localB -> dtdpfiz3ya >
becrktx0d0 . P_264 ) { ipxtggw2ad_p = localX -> kcyjzyu2vu ; } else {
ipxtggw2ad_p = localB -> n2ifxcu5ka ; } if ( rtmIsMajorTimeStep ( hokadafud5
) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { zcEvent = rt_ZCFcn (
ANY_ZERO_CROSSING , & localZCE -> kz0kfjign2 , ( ipxtggw2ad_p - becrktx0d0 .
P_265 ) ) ; if ( localDW -> c15gh1znkl == 0 ) { if ( zcEvent != NO_ZCEVENT )
{ localB -> gtxfpctd3l = ! localB -> gtxfpctd3l ; localDW -> c15gh1znkl = 1 ;
} else if ( localB -> gtxfpctd3l ) { if ( ipxtggw2ad_p != becrktx0d0 . P_265
) { localB -> gtxfpctd3l = false ; } } else { if ( ipxtggw2ad_p == becrktx0d0
. P_265 ) { localB -> gtxfpctd3l = true ; } } } else { if ( ipxtggw2ad_p !=
becrktx0d0 . P_265 ) { localB -> gtxfpctd3l = false ; } localDW -> c15gh1znkl
= 0 ; } localB -> fsmoaxrbwz = becrktx0d0 . P_178 ; localB -> a1iqcl35nc =
becrktx0d0 . P_269 * localB -> fsmoaxrbwz ; localB -> guehcsrift = becrktx0d0
. P_235 ; } ipxtggw2ad_p = localX -> boq0sjomkz ; mtt4yva3gs_p = ( fo3cvtmfih
[ 0 ] - localX -> boq0sjomkz * localB -> oxucuqlz4d ) * becrktx0d0 . P_267 ;
localB -> ncwalb4mpa = becrktx0d0 . P_268 * dfx1ca0pmi [ 0 ] * localB ->
a1iqcl35nc * localB -> fsmoaxrbwz * localB -> guehcsrift ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { localDW -> d0v5i0l0p3 = localB ->
ncwalb4mpa >= becrktx0d0 . P_270 ? 1 : localB -> ncwalb4mpa > becrktx0d0 .
P_271 ? 0 : - 1 ; } iywjngy1pp_p = becrktx0d0 . P_154 * becrktx0d0 . P_227 *
( localDW -> d0v5i0l0p3 == 1 ? becrktx0d0 . P_270 : localDW -> d0v5i0l0p3 ==
- 1 ? becrktx0d0 . P_271 : localB -> ncwalb4mpa ) ; jkml1dhgc4_p = becrktx0d0
. P_231 / becrktx0d0 . P_227 * iywjngy1pp_p ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
kk21lbu5b5 = becrktx0d0 . P_172 * becrktx0d0 . P_272 ; localB -> dxu0itewb4 =
localDW -> czmfx0f2q0 ; } localB -> fkf4utoetv = becrktx0d0 . P_505 [ ( ( (
muDoubleScalarAbs ( ( ( 0.0 - mtt4yva3gs_p ) - localB -> kk21lbu5b5 ) +
localB -> kk21lbu5b5 ) >= jkml1dhgc4_p ) + ( ( uint32_T ) ( localB ->
gtxfpctd3l && ( muDoubleScalarAbs ( - mtt4yva3gs_p ) <= jkml1dhgc4_p ) ) << 1
) ) << 1 ) + localB -> dxu0itewb4 ] ; if ( rtmIsMajorTimeStep ( hokadafud5 )
&& rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { if ( localDW -> clzbvhgwst ) {
localDW -> clzbvhgwst = false ; jkml1dhgc4_p = becrktx0d0 . P_274 ; } else {
jkml1dhgc4_p = becrktx0d0 . P_273 ; } if ( jkml1dhgc4_p > becrktx0d0 . P_275
) { localB -> bbh5egeydw = becrktx0d0 . P_272 ; } else { localB -> bbh5egeydw
= becrktx0d0 . P_239 ; } } rtPrevAction = localDW -> pbnr1alend ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction = ( int8_T ) ! localB ->
fkf4utoetv ; localDW -> pbnr1alend = rtAction ; } else { rtAction = localDW
-> pbnr1alend ; } if ( rtPrevAction != rtAction ) { switch ( rtPrevAction ) {
case 0 : nm4ubjqz2k ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> kcyjzyu2vu = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { gnhczwf3q0 ( hokadafud5 ) ; } fw4l3ijud5 (
hokadafud5 , & localB -> bjtohmekdm , & mtt4yva3gs_p , & iywjngy1pp_p , &
localB -> fw4l3ijud5i , & becrktx0d0 . fw4l3ijud5i ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { srUpdateBC ( localDW -> fw4l3ijud5i .
nizc43tvct ) ; } break ; case 1 : if ( rtAction != rtPrevAction ) { if (
rtmIsFirstInitCond ( hokadafud5 ) ) { localX -> kcyjzyu2vu = 0.0 ; } localDW
-> cxn1gifobd = 1 ; if ( rtmGetTaskTime ( hokadafud5 , 0 ) != rtmGetTStart (
hokadafud5 ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localXdis -> kcyjzyu2vu = 0 ; } if ( localDW -> cxn1gifobd
!= 0 ) { localX -> kcyjzyu2vu = localB -> bbh5egeydw ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> hrvz4xdqsk = ( ( muDoubleScalarTanh ( becrktx0d0
. P_252 * localX -> kcyjzyu2vu ) * iywjngy1pp_p - mtt4yva3gs_p ) - becrktx0d0
. P_172 * localX -> kcyjzyu2vu ) * ( 1.0 / becrktx0d0 . P_21 ) ; localB ->
bjtohmekdm = localX -> kcyjzyu2vu ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> ihlln100lm ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { * io1pn0hnwg =
becrktx0d0 . P_276 ; localB -> eknuy4xov4 [ 0 ] = becrktx0d0 . P_169 ; localB
-> eknuy4xov4 [ 1 ] = becrktx0d0 . P_277 * becrktx0d0 . P_246 [ 0 ] -
becrktx0d0 . P_177 ; localB -> eknuy4xov4 [ 2 ] = becrktx0d0 . P_187 ; localB
-> jrtgn0jxaw = * io1pn0hnwg * localB -> eknuy4xov4 [ 2 ] ; localB ->
klqtuuwl0t [ 0 ] = becrktx0d0 . P_248 ; localB -> klqtuuwl0t [ 1 ] =
becrktx0d0 . P_250 ; localB -> klqtuuwl0t [ 2 ] = becrktx0d0 . P_243 ; localB
-> klqtuuwl0t [ 3 ] = becrktx0d0 . P_244 ; } if ( localDW -> kvj4uckeqc != 0
) { localX -> n5tb00omor [ 0 ] = localB -> klqtuuwl0t [ 0 ] ; localX ->
n5tb00omor [ 1 ] = localB -> klqtuuwl0t [ 1 ] ; localX -> n5tb00omor [ 2 ] =
localB -> klqtuuwl0t [ 2 ] ; localX -> n5tb00omor [ 3 ] = localB ->
klqtuuwl0t [ 3 ] ; } lbi5iovzof_idx_0 = localX -> n5tb00omor [ 0 ] ;
lbi5iovzof_idx_1 = localX -> n5tb00omor [ 1 ] ; lbi5iovzof_idx_2 = localX ->
n5tb00omor [ 2 ] ; lbi5iovzof_idx_3 = localX -> n5tb00omor [ 3 ] ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ * hnk0xxowmm = becrktx0d0 . P_278 ; localB -> jl0mb0sdt1 = * hnk0xxowmm *
localB -> eknuy4xov4 [ 1 ] ; localB -> e4qnpneaf0 = * hnk0xxowmm * localB ->
eknuy4xov4 [ 2 ] ; localB -> aqcplxkx2q = * io1pn0hnwg * localB -> eknuy4xov4
[ 0 ] ; localB -> mvptpmngpx = becrktx0d0 . P_279 ; localB -> d51wwqdsap [ 0
] = becrktx0d0 . P_169 ; localB -> d51wwqdsap [ 1 ] = becrktx0d0 . P_280 *
becrktx0d0 . P_246 [ 0 ] - becrktx0d0 . P_177 ; localB -> d51wwqdsap [ 2 ] =
becrktx0d0 . P_187 ; localB -> g3ck2kdoiu = * io1pn0hnwg * localB ->
d51wwqdsap [ 2 ] ; localB -> jd5btdlbta = * hnk0xxowmm * localB -> d51wwqdsap
[ 1 ] ; localB -> fuiqq1g2y1 = * hnk0xxowmm * localB -> d51wwqdsap [ 2 ] ;
localB -> on0e1amc4b = * io1pn0hnwg * localB -> d51wwqdsap [ 0 ] ; }
kiyqi1kpj4_p [ 0 ] = ( localB -> jrtgn0jxaw - localX -> n5tb00omor [ 3 ] *
localB -> eknuy4xov4 [ 1 ] ) + localX -> n5tb00omor [ 0 ] ; kiyqi1kpj4_p [ 1
] = ( localX -> n5tb00omor [ 3 ] * localB -> eknuy4xov4 [ 0 ] - localB ->
e4qnpneaf0 ) + localX -> n5tb00omor [ 1 ] ; kiyqi1kpj4_p [ 2 ] = ( localB ->
jl0mb0sdt1 - localB -> aqcplxkx2q ) + localB -> mvptpmngpx ; kiyqi1kpj4_p [ 3
] = ( localB -> g3ck2kdoiu - localX -> n5tb00omor [ 3 ] * localB ->
d51wwqdsap [ 1 ] ) + localX -> n5tb00omor [ 0 ] ; kiyqi1kpj4_p [ 4 ] = (
localX -> n5tb00omor [ 3 ] * localB -> d51wwqdsap [ 0 ] - localB ->
fuiqq1g2y1 ) + localX -> n5tb00omor [ 1 ] ; kiyqi1kpj4_p [ 5 ] = ( localB ->
jd5btdlbta - localB -> on0e1amc4b ) + localB -> mvptpmngpx ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> fznsoivi2v [ 0 ] = - becrktx0d0 . P_170 ; localB -> fznsoivi2v [
1 ] = becrktx0d0 . P_281 * becrktx0d0 . P_246 [ 0 ] - becrktx0d0 . P_177 ;
localB -> fznsoivi2v [ 2 ] = becrktx0d0 . P_187 ; localB -> pr13gdcnok = *
io1pn0hnwg * localB -> fznsoivi2v [ 2 ] ; localB -> jvb0u51fhy = * hnk0xxowmm
* localB -> fznsoivi2v [ 1 ] ; localB -> ctd0sgwtys = * hnk0xxowmm * localB
-> fznsoivi2v [ 2 ] ; localB -> lqmh0s1j05 = * io1pn0hnwg * localB ->
fznsoivi2v [ 0 ] ; localB -> esf1woxugv [ 0 ] = - becrktx0d0 . P_170 ; localB
-> esf1woxugv [ 1 ] = becrktx0d0 . P_282 * becrktx0d0 . P_246 [ 0 ] -
becrktx0d0 . P_177 ; localB -> esf1woxugv [ 2 ] = becrktx0d0 . P_187 ; localB
-> fu0ssgbvmj = * io1pn0hnwg * localB -> esf1woxugv [ 2 ] ; localB ->
mza4fnkd4w = * hnk0xxowmm * localB -> esf1woxugv [ 1 ] ; localB -> kqddg2sxi4
= * hnk0xxowmm * localB -> esf1woxugv [ 2 ] ; localB -> kxepkmrspn = *
io1pn0hnwg * localB -> esf1woxugv [ 0 ] ; } kiyqi1kpj4_p [ 6 ] = ( localB ->
pr13gdcnok - localX -> n5tb00omor [ 3 ] * localB -> fznsoivi2v [ 1 ] ) +
localX -> n5tb00omor [ 0 ] ; kiyqi1kpj4_p [ 7 ] = ( localX -> n5tb00omor [ 3
] * localB -> fznsoivi2v [ 0 ] - localB -> ctd0sgwtys ) + localX ->
n5tb00omor [ 1 ] ; kiyqi1kpj4_p [ 8 ] = ( localB -> jvb0u51fhy - localB ->
lqmh0s1j05 ) + localB -> mvptpmngpx ; kiyqi1kpj4_p [ 9 ] = ( localB ->
fu0ssgbvmj - localX -> n5tb00omor [ 3 ] * localB -> esf1woxugv [ 1 ] ) +
localX -> n5tb00omor [ 0 ] ; kiyqi1kpj4_p [ 10 ] = ( localX -> n5tb00omor [ 3
] * localB -> esf1woxugv [ 0 ] - localB -> kqddg2sxi4 ) + localX ->
n5tb00omor [ 1 ] ; kiyqi1kpj4_p [ 11 ] = ( localB -> mza4fnkd4w - localB ->
kxepkmrspn ) + localB -> mvptpmngpx ; if ( rtmIsMajorTimeStep ( hokadafud5 )
&& rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> ggjfrkknel [ 0 ] =
becrktx0d0 . P_283 [ 0 ] ; localB -> ggjfrkknel [ 1 ] = becrktx0d0 . P_283 [
1 ] ; localB -> ggjfrkknel [ 2 ] = becrktx0d0 . P_283 [ 2 ] ; localB ->
ggjfrkknel [ 3 ] = becrktx0d0 . P_283 [ 3 ] ; localB -> iw5zv3exm3 =
becrktx0d0 . P_284 ; } feixrhnufu_p [ 0 ] = localB -> ggjfrkknel [ 0 ] ;
feixrhnufu_p [ 1 ] = localB -> is5r5qizkw [ 0 ] ; feixrhnufu_p [ 2 ] =
gxlrb30ei4 [ 0 ] ; feixrhnufu_p [ 3 ] = localB -> ggjfrkknel [ 1 ] ;
feixrhnufu_p [ 4 ] = localB -> is5r5qizkw [ 1 ] ; feixrhnufu_p [ 5 ] =
gxlrb30ei4 [ 1 ] + localB -> iw5zv3exm3 ; feixrhnufu_p [ 6 ] = localB ->
ggjfrkknel [ 2 ] ; feixrhnufu_p [ 7 ] = localB -> is5r5qizkw [ 2 ] ;
feixrhnufu_p [ 8 ] = gxlrb30ei4 [ 2 ] ; feixrhnufu_p [ 9 ] = localB ->
ggjfrkknel [ 3 ] ; feixrhnufu_p [ 10 ] = localB -> is5r5qizkw [ 3 ] ;
feixrhnufu_p [ 11 ] = gxlrb30ei4 [ 3 ] + localB -> iw5zv3exm3 ; for (
eufvenxnxf = 0 ; eufvenxnxf < 4 ; eufvenxnxf ++ ) { ewytrsohkb_p [ 0 ] =
feixrhnufu_p [ 3 * eufvenxnxf ] ; ewytrsohkb_p [ 1 ] = feixrhnufu_p [ 3 *
eufvenxnxf + 1 ] ; ewytrsohkb_p [ 2 ] = feixrhnufu_p [ 3 * eufvenxnxf + 2 ] ;
egwdhsr12b_p [ 0 ] = kiyqi1kpj4_p [ 3 * eufvenxnxf ] ; egwdhsr12b_p [ 1 ] =
kiyqi1kpj4_p [ 3 * eufvenxnxf + 1 ] ; egwdhsr12b_p [ 2 ] = kiyqi1kpj4_p [ 3 *
eufvenxnxf + 2 ] ; muDoubleScalarSinCos ( ewytrsohkb_p [ 2 ] , & gdlhgdf2w4_p
, & mtt4yva3gs_p ) ; muDoubleScalarSinCos ( ewytrsohkb_p [ 1 ] , & Fz_idx_0 ,
& Fz_idx_1 ) ; muDoubleScalarSinCos ( ewytrsohkb_p [ 0 ] , & Fz_rnom , &
Fy_fr ) ; okap0sparj_p [ 0 ] = Fz_idx_1 * mtt4yva3gs_p ; iywjngy1pp_p =
Fz_rnom * Fz_idx_0 ; okap0sparj_p [ 1 ] = iywjngy1pp_p * mtt4yva3gs_p - Fy_fr
* gdlhgdf2w4_p ; jkml1dhgc4_p = Fy_fr * Fz_idx_0 ; okap0sparj_p [ 2 ] =
jkml1dhgc4_p * mtt4yva3gs_p + Fz_rnom * gdlhgdf2w4_p ; okap0sparj_p [ 3 ] =
Fz_idx_1 * gdlhgdf2w4_p ; okap0sparj_p [ 4 ] = iywjngy1pp_p * gdlhgdf2w4_p +
Fy_fr * mtt4yva3gs_p ; okap0sparj_p [ 5 ] = jkml1dhgc4_p * gdlhgdf2w4_p -
Fz_rnom * mtt4yva3gs_p ; okap0sparj_p [ 6 ] = - Fz_idx_0 ; okap0sparj_p [ 7 ]
= Fz_rnom * Fz_idx_1 ; okap0sparj_p [ 8 ] = Fy_fr * Fz_idx_1 ; for ( i = 0 ;
i < 3 ; i ++ ) { okap0sparj_e [ i ] = okap0sparj_p [ i + 6 ] * egwdhsr12b_p [
2 ] + ( okap0sparj_p [ i + 3 ] * egwdhsr12b_p [ 1 ] + okap0sparj_p [ i ] *
egwdhsr12b_p [ 0 ] ) ; } localB -> fp0lz1z3pw [ eufvenxnxf ] = okap0sparj_e [
0 ] ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5
, 1 , 0 ) ) { localB -> iiwypnhwyh = becrktx0d0 . P_285 ; localB ->
egbusy3rcf = becrktx0d0 . P_286 ; localB -> eyjqc3zg20 = becrktx0d0 . P_287 ;
localB -> eeh3yoxtqk = becrktx0d0 . P_288 ; localB -> dptguhaesv = becrktx0d0
. P_289 ; localB -> di1y3sdj0d = becrktx0d0 . P_183 ; localB -> caogvivler =
becrktx0d0 . P_26 ; localB -> bg3tax3rgv = becrktx0d0 . P_8 ; localB ->
kdyzo5shnm = becrktx0d0 . P_35 ; localB -> fw2njrswyb = becrktx0d0 . P_290 ;
localB -> codfhoiqk1 = becrktx0d0 . P_291 ; localB -> erj50lr4lf = becrktx0d0
. P_40 ; localB -> lbucqhslax = becrktx0d0 . P_44 ; localB -> d1ao4nvb3r =
becrktx0d0 . P_48 ; localB -> gfjrkfs43t = becrktx0d0 . P_52 ; localB ->
pic3pyjewm = becrktx0d0 . P_56 ; localB -> f5xpwds5uf = becrktx0d0 . P_60 ;
localB -> i050wrra1b = becrktx0d0 . P_64 ; localB -> cxsj5e3v3a = becrktx0d0
. P_68 ; localB -> isedmshyce = becrktx0d0 . P_80 ; localB -> d4lcrcrqdn =
becrktx0d0 . P_84 ; localB -> g4rortd5gm = becrktx0d0 . P_88 ; localB ->
clz3iyr5qx = becrktx0d0 . P_72 ; localB -> pyadsbtv4s = becrktx0d0 . P_76 ;
localB -> bdx2e3myiv = becrktx0d0 . P_108 ; localB -> exronxah0g = becrktx0d0
. P_112 ; localB -> ebzbgbgkgh = becrktx0d0 . P_92 ; localB -> bxd44k2unh =
becrktx0d0 . P_96 ; localB -> kzrkqtt0ra = becrktx0d0 . P_100 ; localB ->
lzinhif1jz = becrktx0d0 . P_104 ; localB -> ka3b1xmz3e = becrktx0d0 . P_200 ;
localB -> imvrqtjhmt = becrktx0d0 . P_220 ; localB -> lrumv5m0rz = becrktx0d0
. P_208 ; localB -> ibq2geeedj = becrktx0d0 . P_192 ; localB -> ezjxcx5jjr =
becrktx0d0 . P_196 ; localB -> fhcy0rvapt = becrktx0d0 . P_204 ; localB ->
j0girqlod4 = becrktx0d0 . P_216 ; localB -> f2xqgnxkqm [ 0 ] = becrktx0d0 .
P_292 [ 0 ] ; localB -> a1nh1kadu4 [ 0 ] = becrktx0d0 . P_293 [ 0 ] ; localB
-> f2xqgnxkqm [ 1 ] = becrktx0d0 . P_292 [ 1 ] ; localB -> a1nh1kadu4 [ 1 ] =
becrktx0d0 . P_293 [ 1 ] ; localB -> f2xqgnxkqm [ 2 ] = becrktx0d0 . P_292 [
2 ] ; localB -> a1nh1kadu4 [ 2 ] = becrktx0d0 . P_293 [ 2 ] ; localB ->
gtjrxup1j4 = becrktx0d0 . P_8 ; localB -> ihms03kaqg = becrktx0d0 . P_35 ;
localB -> lwln0imtwr = becrktx0d0 . P_117 ; localB -> fpll2uqxj0 = becrktx0d0
. P_121 ; localB -> oo4mibkckw = becrktx0d0 . P_125 ; localB -> guz5uyqmni =
becrktx0d0 . P_129 ; localB -> jpbgvu3ysx = becrktx0d0 . P_133 ; localB ->
ivdv3kteoq = becrktx0d0 . P_137 ; localB -> ilukdeejlg = becrktx0d0 . P_141 ;
localB -> fwvqhlsifq = becrktx0d0 . P_145 ; localB -> n4gka4ggb3 = becrktx0d0
. P_183 ; localB -> l4dk5thw4j = becrktx0d0 . P_212 ; localB -> e4tas2ftdh =
becrktx0d0 . P_159 ; localB -> npvsjubahx = becrktx0d0 . P_295 ; localB ->
ik2hq3tl51 = becrktx0d0 . P_296 ; localB -> gbddmx5qus [ 0 ] = becrktx0d0 .
P_297 [ 0 ] ; localB -> bswxr3glt4 [ 0 ] = becrktx0d0 . P_298 [ 0 ] ; localB
-> gbddmx5qus [ 1 ] = becrktx0d0 . P_297 [ 1 ] ; localB -> bswxr3glt4 [ 1 ] =
becrktx0d0 . P_298 [ 1 ] ; localB -> gbddmx5qus [ 2 ] = becrktx0d0 . P_297 [
2 ] ; localB -> bswxr3glt4 [ 2 ] = becrktx0d0 . P_298 [ 2 ] ; memcpy ( &
localB -> p21kvs5mbb [ 0 ] , & becrktx0d0 . P_294 [ 0 ] , 9U * sizeof (
real_T ) ) ; memcpy ( & localB -> crh3sglt3v [ 0 ] , & becrktx0d0 . P_299 [ 0
] , 9U * sizeof ( real_T ) ) ; localB -> n4rna1kebg = becrktx0d0 . P_300 ;
localB -> gxpylv2kph = becrktx0d0 . P_301 ; localB -> cu5djmnfyj = becrktx0d0
. P_302 ; localB -> gf104bu43p = becrktx0d0 . P_303 ; localB -> n5bbn5bt0q =
becrktx0d0 . P_304 ; localB -> kf5eha1owu = becrktx0d0 . P_305 ; localB ->
nilrmjc1gv = becrktx0d0 . P_306 ; localB -> hgggja214h = becrktx0d0 . P_307 ;
localB -> ocasm0fm15 = becrktx0d0 . P_308 ; localB -> irwjnphqqw = becrktx0d0
. P_309 ; localB -> pxftkur41v = becrktx0d0 . P_310 ; localB -> hfvm1qgrw3 =
becrktx0d0 . P_311 ; localB -> fhdp2eu5jt = becrktx0d0 . P_312 ; localB ->
canrgzivnr = becrktx0d0 . P_313 ; localB -> cr5hpd151d = becrktx0d0 . P_314 ;
localB -> ar23uftlis = becrktx0d0 . P_315 ; localB -> fsos5hphde = becrktx0d0
. P_316 ; localB -> bunpahqovu = becrktx0d0 . P_317 ; localB -> ocjwenstkc =
becrktx0d0 . P_318 ; localB -> m0ysfew3rk = becrktx0d0 . P_319 ; localB ->
dbdgakxnow = becrktx0d0 . P_320 ; localB -> gmcaz15cv4 = becrktx0d0 . P_321 ;
localB -> nlwwlu3lrx = becrktx0d0 . P_322 ; localB -> kfqbvv4uff = becrktx0d0
. P_323 ; localB -> oetza3lke4 = becrktx0d0 . P_324 ; localB -> l1cwkfgzdt =
becrktx0d0 . P_325 ; } ptwb5m53nr ( localB -> oxucuqlz4d , nkp14nzj3q_idx_0 ,
localB -> bjtohmekdm , localB -> fp0lz1z3pw [ 0 ] , localB -> iiwypnhwyh ,
localB -> egbusy3rcf , localB -> eyjqc3zg20 , localB -> eeh3yoxtqk , localB
-> dptguhaesv , localB -> di1y3sdj0d , localB -> caogvivler , localB ->
bg3tax3rgv , & bv2zp3o4ji [ 0 ] , localB -> kdyzo5shnm , localB -> fw2njrswyb
, localB -> codfhoiqk1 , localB -> erj50lr4lf , localB -> lbucqhslax , localB
-> d1ao4nvb3r , localB -> gfjrkfs43t , localB -> pic3pyjewm , localB ->
f5xpwds5uf , localB -> i050wrra1b , localB -> cxsj5e3v3a , localB ->
isedmshyce , localB -> d4lcrcrqdn , localB -> g4rortd5gm , localB ->
clz3iyr5qx , localB -> pyadsbtv4s , localB -> bdx2e3myiv , localB ->
exronxah0g , localB -> ebzbgbgkgh , localB -> bxd44k2unh , localB ->
kzrkqtt0ra , localB -> lzinhif1jz , localB -> ka3b1xmz3e , localB ->
imvrqtjhmt , & czlc2qmxmx [ 0 ] , localB -> lrumv5m0rz , localB -> ibq2geeedj
, localB -> ezjxcx5jjr , localB -> fhcy0rvapt , localB -> j0girqlod4 , localB
-> f2xqgnxkqm , localB -> a1nh1kadu4 , localB -> p21kvs5mbb , localB ->
gtjrxup1j4 , localB -> ihms03kaqg , localB -> lwln0imtwr , localB ->
fpll2uqxj0 , localB -> oo4mibkckw , localB -> guz5uyqmni , localB ->
jpbgvu3ysx , localB -> ivdv3kteoq , localB -> ilukdeejlg , localB ->
fwvqhlsifq , localB -> n4gka4ggb3 , localB -> l4dk5thw4j , localB ->
e4tas2ftdh , localB -> npvsjubahx , localB -> ik2hq3tl51 , localB ->
gbddmx5qus , localB -> bswxr3glt4 , localB -> crh3sglt3v , 0.0 , localB ->
n4rna1kebg , localB -> gxpylv2kph , localB -> cu5djmnfyj , localB ->
gf104bu43p , localB -> n5bbn5bt0q , localB -> kf5eha1owu , localB ->
nilrmjc1gv , localB -> hgggja214h , localB -> ocasm0fm15 , localB ->
irwjnphqqw , localB -> pxftkur41v , localB -> hfvm1qgrw3 , localB ->
fhdp2eu5jt , localB -> canrgzivnr , localB -> cr5hpd151d , localB ->
ar23uftlis , localB -> fsos5hphde , localB -> bunpahqovu , localB ->
ocjwenstkc , localB -> m0ysfew3rk , localB -> dbdgakxnow , localB ->
gmcaz15cv4 , localB -> nlwwlu3lrx , localB -> kfqbvv4uff , localB ->
oetza3lke4 , localB -> l1cwkfgzdt , & cyqteuatay [ 0 ] , & ffnn3i1mdg [ 0 ] ,
& localB -> f1abnn2ast , becrktx0d0 . P_12 , becrktx0d0 . P_16 , becrktx0d0 .
P_163 , becrktx0d0 . P_188 ) ; nd20r1di23_idx_0 = localB -> f1abnn2ast .
dbw42rwkve ; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit (
hokadafud5 , 1 , 0 ) ) { localB -> fugevmefkb = becrktx0d0 . P_151 ; if (
localDW -> letpwa1hho ) { localDW -> letpwa1hho = false ; localB ->
mldroewczt = becrktx0d0 . P_327 ; } else { localB -> mldroewczt = becrktx0d0
. P_326 ; } localB -> bsoukwzr1y = becrktx0d0 . P_240 ; } if ( localB ->
mldroewczt > becrktx0d0 . P_328 ) { mtt4yva3gs_p = localX -> ny5f4grmco ; }
else { mtt4yva3gs_p = localB -> bsoukwzr1y ; } if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { zcEvent = rt_ZCFcn
( ANY_ZERO_CROSSING , & localZCE -> ga0zahod5b , ( mtt4yva3gs_p - becrktx0d0
. P_329 ) ) ; if ( localDW -> jc2adk33a2 == 0 ) { if ( zcEvent != NO_ZCEVENT
) { localB -> cykabqkq24 = ! localB -> cykabqkq24 ; localDW -> jc2adk33a2 = 1
; } else if ( localB -> cykabqkq24 ) { if ( mtt4yva3gs_p != becrktx0d0 .
P_329 ) { localB -> cykabqkq24 = false ; } } else { if ( mtt4yva3gs_p ==
becrktx0d0 . P_329 ) { localB -> cykabqkq24 = true ; } } } else { if (
mtt4yva3gs_p != becrktx0d0 . P_329 ) { localB -> cykabqkq24 = false ; }
localDW -> jc2adk33a2 = 0 ; } localB -> fbezbyum3x = becrktx0d0 . P_179 ;
localB -> heipunlrmg = becrktx0d0 . P_333 * localB -> fbezbyum3x ; localB ->
epq3bk14ul = becrktx0d0 . P_236 ; } mtt4yva3gs_p = localX -> g4fxozrdb2 ;
iywjngy1pp_p = ( fo3cvtmfih [ 1 ] - localX -> g4fxozrdb2 * localB ->
fugevmefkb ) * becrktx0d0 . P_331 ; localB -> l3sezdykbm = becrktx0d0 . P_332
* dfx1ca0pmi [ 1 ] * localB -> heipunlrmg * localB -> fbezbyum3x * localB ->
epq3bk14ul ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { localDW -> izlbjsap24
= localB -> l3sezdykbm >= becrktx0d0 . P_334 ? 1 : localB -> l3sezdykbm >
becrktx0d0 . P_335 ? 0 : - 1 ; } jkml1dhgc4_p = becrktx0d0 . P_155 *
becrktx0d0 . P_228 * ( localDW -> izlbjsap24 == 1 ? becrktx0d0 . P_334 :
localDW -> izlbjsap24 == - 1 ? becrktx0d0 . P_335 : localB -> l3sezdykbm ) ;
bdhjtvge12_p = becrktx0d0 . P_232 / becrktx0d0 . P_228 * jkml1dhgc4_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> dgxtzac1n0 = becrktx0d0 . P_173 * becrktx0d0 . P_336 ; localB ->
oisuxakp0k = localDW -> ok0qcfhc1h ; } localB -> kaw4drkctd = becrktx0d0 .
P_507 [ ( ( ( muDoubleScalarAbs ( ( ( 0.0 - iywjngy1pp_p ) - localB ->
dgxtzac1n0 ) + localB -> dgxtzac1n0 ) >= bdhjtvge12_p ) + ( ( uint32_T ) (
localB -> cykabqkq24 && ( muDoubleScalarAbs ( - iywjngy1pp_p ) <=
bdhjtvge12_p ) ) << 1 ) ) << 1 ) + localB -> oisuxakp0k ] ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ if ( localDW -> lbpmeols54 ) { localDW -> lbpmeols54 = false ; bdhjtvge12_p
= becrktx0d0 . P_338 ; } else { bdhjtvge12_p = becrktx0d0 . P_337 ; } if (
bdhjtvge12_p > becrktx0d0 . P_339 ) { localB -> d4ro5g30v1 = becrktx0d0 .
P_336 ; } else { localB -> d4ro5g30v1 = becrktx0d0 . P_240 ; } } rtPrevAction
= localDW -> py0qqcx0x3 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction
= ( int8_T ) ! localB -> kaw4drkctd ; localDW -> py0qqcx0x3 = rtAction ; }
else { rtAction = localDW -> py0qqcx0x3 ; } if ( rtPrevAction != rtAction ) {
switch ( rtPrevAction ) { case 0 : nm4ubjqz2k ( hokadafud5 ) ; break ; case 1
: ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> ny5f4grmco = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { gnhczwf3q0 ( hokadafud5 ) ; } fw4l3ijud5 (
hokadafud5 , & localB -> hhuwm0io3s , & iywjngy1pp_p , & jkml1dhgc4_p , &
localB -> d1a5f5cvti , & becrktx0d0 . d1a5f5cvti ) ; if ( rtmIsMajorTimeStep
( hokadafud5 ) ) { srUpdateBC ( localDW -> d1a5f5cvti . nizc43tvct ) ; }
break ; case 1 : if ( rtAction != rtPrevAction ) { if ( rtmIsFirstInitCond (
hokadafud5 ) ) { localX -> ny5f4grmco = 0.0 ; } localDW -> ew15w55ihb = 1 ;
if ( rtmGetTaskTime ( hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> ny5f4grmco = 0 ; } if ( localDW -> ew15w55ihb != 0 ) { localX ->
ny5f4grmco = localB -> d4ro5g30v1 ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> da10kctuqi = ( ( muDoubleScalarTanh ( becrktx0d0
. P_254 * localX -> ny5f4grmco ) * jkml1dhgc4_p - iywjngy1pp_p ) - becrktx0d0
. P_173 * localX -> ny5f4grmco ) * ( 1.0 / becrktx0d0 . P_22 ) ; localB ->
hhuwm0io3s = localX -> ny5f4grmco ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> ad5kqdj2zm ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
ogdgtyjzqi = becrktx0d0 . P_340 ; localB -> axdicvi5m3 = becrktx0d0 . P_341 ;
localB -> pj23yhglrw = becrktx0d0 . P_342 ; localB -> fpcofdvmxq = becrktx0d0
. P_343 ; localB -> otfnmfg3va = becrktx0d0 . P_344 ; localB -> dqctahwqe1 =
becrktx0d0 . P_184 ; localB -> cc0g0dr1oo = becrktx0d0 . P_27 ; localB ->
jm10hwmol3 = becrktx0d0 . P_9 ; localB -> iff1evzlmg = becrktx0d0 . P_36 ;
localB -> ffbjki2fot = becrktx0d0 . P_345 ; localB -> bijvgsz5qh = becrktx0d0
. P_346 ; localB -> e0zyukaonm = becrktx0d0 . P_41 ; localB -> pvyk213plh =
becrktx0d0 . P_45 ; localB -> oe0jus4god = becrktx0d0 . P_49 ; localB ->
hhzo15do51 = becrktx0d0 . P_53 ; localB -> cg3yxlcnph = becrktx0d0 . P_57 ;
localB -> belfgokcfy = becrktx0d0 . P_61 ; localB -> damawwa4tl = becrktx0d0
. P_65 ; localB -> bylvuz1vtv = becrktx0d0 . P_69 ; localB -> hcksgh5oai =
becrktx0d0 . P_81 ; localB -> hzjr0ik2hm = becrktx0d0 . P_85 ; localB ->
jbpx4i1xkq = becrktx0d0 . P_89 ; localB -> eevaz32yfw = becrktx0d0 . P_73 ;
localB -> o3wkgn5vb2 = becrktx0d0 . P_77 ; localB -> ffriktbsym = becrktx0d0
. P_109 ; localB -> ifwowqeogx = becrktx0d0 . P_113 ; localB -> ev3cht2oax =
becrktx0d0 . P_93 ; localB -> mmasgazjgu = becrktx0d0 . P_97 ; localB ->
ox2j5d5cxd = becrktx0d0 . P_101 ; localB -> m0csgicmpb = becrktx0d0 . P_105 ;
localB -> cqvsmkaral = becrktx0d0 . P_201 ; localB -> aby1ez2fhi = becrktx0d0
. P_221 ; localB -> mzni2kpsns = becrktx0d0 . P_209 ; localB -> jtrtvaajns =
becrktx0d0 . P_193 ; localB -> mimmdu3yox = becrktx0d0 . P_197 ; localB ->
eholklbdno = becrktx0d0 . P_205 ; localB -> eh1bnxmco2 = becrktx0d0 . P_217 ;
localB -> f2oit4mz1m [ 0 ] = becrktx0d0 . P_347 [ 0 ] ; localB -> bcuad4qgnk
[ 0 ] = becrktx0d0 . P_348 [ 0 ] ; localB -> f2oit4mz1m [ 1 ] = becrktx0d0 .
P_347 [ 1 ] ; localB -> bcuad4qgnk [ 1 ] = becrktx0d0 . P_348 [ 1 ] ; localB
-> f2oit4mz1m [ 2 ] = becrktx0d0 . P_347 [ 2 ] ; localB -> bcuad4qgnk [ 2 ] =
becrktx0d0 . P_348 [ 2 ] ; localB -> paxqjicrvd = becrktx0d0 . P_9 ; localB
-> bnlxmyw0x2 = becrktx0d0 . P_36 ; localB -> h505jhxdmz = becrktx0d0 . P_118
; localB -> gmcr3j0cex = becrktx0d0 . P_122 ; localB -> fuoqxgs3gc =
becrktx0d0 . P_126 ; localB -> cfn2c1bhhp = becrktx0d0 . P_130 ; localB ->
pknzmehues = becrktx0d0 . P_134 ; localB -> jw4cbjklwg = becrktx0d0 . P_138 ;
localB -> eiaffadlxg = becrktx0d0 . P_142 ; localB -> m0jx3pzpz3 = becrktx0d0
. P_146 ; localB -> flqtpdddos = becrktx0d0 . P_184 ; localB -> ctdqrhk0wl =
becrktx0d0 . P_213 ; localB -> fkqww4lf3n = becrktx0d0 . P_160 ; localB ->
at3nbptmo3 = becrktx0d0 . P_350 ; localB -> pisy4totyk = becrktx0d0 . P_351 ;
localB -> nybfkmk1v2 [ 0 ] = becrktx0d0 . P_352 [ 0 ] ; localB -> fe2jbk1ow2
[ 0 ] = becrktx0d0 . P_353 [ 0 ] ; localB -> nybfkmk1v2 [ 1 ] = becrktx0d0 .
P_352 [ 1 ] ; localB -> fe2jbk1ow2 [ 1 ] = becrktx0d0 . P_353 [ 1 ] ; localB
-> nybfkmk1v2 [ 2 ] = becrktx0d0 . P_352 [ 2 ] ; localB -> fe2jbk1ow2 [ 2 ] =
becrktx0d0 . P_353 [ 2 ] ; memcpy ( & localB -> bc3tmfjmfl [ 0 ] , &
becrktx0d0 . P_349 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
ie4eubfmr2 [ 0 ] , & becrktx0d0 . P_354 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> dz4cqcxuur = becrktx0d0 . P_355 ; localB -> aokkriuvci = becrktx0d0
. P_356 ; localB -> bex1os0zvb = becrktx0d0 . P_357 ; localB -> n5cwbhrehw =
becrktx0d0 . P_358 ; localB -> jgkqc5zrqf = becrktx0d0 . P_359 ; localB ->
mlmqh1u0g5 = becrktx0d0 . P_360 ; localB -> khtbqd2u0y = becrktx0d0 . P_361 ;
localB -> gk3dmmmcgw = becrktx0d0 . P_362 ; localB -> eowqx4z04r = becrktx0d0
. P_363 ; localB -> naaa2ruf15 = becrktx0d0 . P_364 ; localB -> br2j2u1vjb =
becrktx0d0 . P_365 ; localB -> htao0p45hs = becrktx0d0 . P_366 ; localB ->
gcjllctxbs = becrktx0d0 . P_367 ; localB -> fonl15lhi1 = becrktx0d0 . P_368 ;
localB -> et0mptjuaw = becrktx0d0 . P_369 ; localB -> hyazmlrepy = becrktx0d0
. P_370 ; localB -> p1lp0buo44 = becrktx0d0 . P_371 ; localB -> nhbd0blqhw =
becrktx0d0 . P_372 ; localB -> fzii3sxltg = becrktx0d0 . P_373 ; localB ->
lpk13hnzik = becrktx0d0 . P_374 ; localB -> oz43sbwtkf = becrktx0d0 . P_375 ;
localB -> nzhkhzb0lt = becrktx0d0 . P_376 ; localB -> bwhx4u5ecx = becrktx0d0
. P_377 ; localB -> afa0svr0rr = becrktx0d0 . P_378 ; localB -> e41wl2nsj3 =
becrktx0d0 . P_379 ; localB -> lzuculkkg0 = becrktx0d0 . P_380 ; } ptwb5m53nr
( localB -> fugevmefkb , nkp14nzj3q_idx_1 , localB -> hhuwm0io3s , localB ->
fp0lz1z3pw [ 1 ] , localB -> ogdgtyjzqi , localB -> axdicvi5m3 , localB ->
pj23yhglrw , localB -> fpcofdvmxq , localB -> otfnmfg3va , localB ->
dqctahwqe1 , localB -> cc0g0dr1oo , localB -> jm10hwmol3 , & bv2zp3o4ji [ 1 ]
, localB -> iff1evzlmg , localB -> ffbjki2fot , localB -> bijvgsz5qh , localB
-> e0zyukaonm , localB -> pvyk213plh , localB -> oe0jus4god , localB ->
hhzo15do51 , localB -> cg3yxlcnph , localB -> belfgokcfy , localB ->
damawwa4tl , localB -> bylvuz1vtv , localB -> hcksgh5oai , localB ->
hzjr0ik2hm , localB -> jbpx4i1xkq , localB -> eevaz32yfw , localB ->
o3wkgn5vb2 , localB -> ffriktbsym , localB -> ifwowqeogx , localB ->
ev3cht2oax , localB -> mmasgazjgu , localB -> ox2j5d5cxd , localB ->
m0csgicmpb , localB -> cqvsmkaral , localB -> aby1ez2fhi , & czlc2qmxmx [ 1 ]
, localB -> mzni2kpsns , localB -> jtrtvaajns , localB -> mimmdu3yox , localB
-> eholklbdno , localB -> eh1bnxmco2 , localB -> f2oit4mz1m , localB ->
bcuad4qgnk , localB -> bc3tmfjmfl , localB -> paxqjicrvd , localB ->
bnlxmyw0x2 , localB -> h505jhxdmz , localB -> gmcr3j0cex , localB ->
fuoqxgs3gc , localB -> cfn2c1bhhp , localB -> pknzmehues , localB ->
jw4cbjklwg , localB -> eiaffadlxg , localB -> m0jx3pzpz3 , localB ->
flqtpdddos , localB -> ctdqrhk0wl , localB -> fkqww4lf3n , localB ->
at3nbptmo3 , localB -> pisy4totyk , localB -> nybfkmk1v2 , localB ->
fe2jbk1ow2 , localB -> ie4eubfmr2 , 0.0 , localB -> dz4cqcxuur , localB ->
aokkriuvci , localB -> bex1os0zvb , localB -> n5cwbhrehw , localB ->
jgkqc5zrqf , localB -> mlmqh1u0g5 , localB -> khtbqd2u0y , localB ->
gk3dmmmcgw , localB -> eowqx4z04r , localB -> naaa2ruf15 , localB ->
br2j2u1vjb , localB -> htao0p45hs , localB -> gcjllctxbs , localB ->
fonl15lhi1 , localB -> et0mptjuaw , localB -> hyazmlrepy , localB ->
p1lp0buo44 , localB -> nhbd0blqhw , localB -> fzii3sxltg , localB ->
lpk13hnzik , localB -> oz43sbwtkf , localB -> nzhkhzb0lt , localB ->
bwhx4u5ecx , localB -> afa0svr0rr , localB -> e41wl2nsj3 , localB ->
lzuculkkg0 , & cyqteuatay [ 1 ] , & ffnn3i1mdg [ 1 ] , & localB -> dycowragfc
, becrktx0d0 . P_13 , becrktx0d0 . P_17 , becrktx0d0 . P_164 , becrktx0d0 .
P_189 ) ; nd20r1di23_idx_1 = localB -> dycowragfc . dbw42rwkve ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> heksh3fd4a = becrktx0d0 . P_152 ; if ( localDW -> m1ndv25sb4 ) {
localDW -> m1ndv25sb4 = false ; localB -> ltxahmkvv0 = becrktx0d0 . P_382 ; }
else { localB -> ltxahmkvv0 = becrktx0d0 . P_381 ; } localB -> hhomyb0ut1 =
becrktx0d0 . P_241 ; } if ( localB -> ltxahmkvv0 > becrktx0d0 . P_383 ) {
iywjngy1pp_p = localX -> cxpr0gz2hj ; } else { iywjngy1pp_p = localB ->
hhomyb0ut1 ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit (
hokadafud5 , 1 , 0 ) ) { zcEvent = rt_ZCFcn ( ANY_ZERO_CROSSING , & localZCE
-> jlsbehjebk , ( iywjngy1pp_p - becrktx0d0 . P_384 ) ) ; if ( localDW ->
nhfu44frt0 == 0 ) { if ( zcEvent != NO_ZCEVENT ) { localB -> jmccqq5v03 = !
localB -> jmccqq5v03 ; localDW -> nhfu44frt0 = 1 ; } else if ( localB ->
jmccqq5v03 ) { if ( iywjngy1pp_p != becrktx0d0 . P_384 ) { localB ->
jmccqq5v03 = false ; } } else { if ( iywjngy1pp_p == becrktx0d0 . P_384 ) {
localB -> jmccqq5v03 = true ; } } } else { if ( iywjngy1pp_p != becrktx0d0 .
P_384 ) { localB -> jmccqq5v03 = false ; } localDW -> nhfu44frt0 = 0 ; }
localB -> jq1bwwonwz = becrktx0d0 . P_180 ; localB -> nvzel15wxv = becrktx0d0
. P_388 * localB -> jq1bwwonwz ; localB -> lvh5brlvcm = becrktx0d0 . P_237 ;
} iywjngy1pp_p = localX -> i12d3wngfk ; jkml1dhgc4_p = ( fo3cvtmfih [ 2 ] -
localX -> i12d3wngfk * localB -> heksh3fd4a ) * becrktx0d0 . P_386 ; localB
-> mo0spoj2dp = becrktx0d0 . P_387 * dfx1ca0pmi [ 2 ] * localB -> nvzel15wxv
* localB -> jq1bwwonwz * localB -> lvh5brlvcm ; if ( rtmIsMajorTimeStep (
hokadafud5 ) ) { localDW -> mu4qgi2zax = localB -> mo0spoj2dp >= becrktx0d0 .
P_389 ? 1 : localB -> mo0spoj2dp > becrktx0d0 . P_390 ? 0 : - 1 ; }
bdhjtvge12_p = becrktx0d0 . P_156 * becrktx0d0 . P_229 * ( localDW ->
mu4qgi2zax == 1 ? becrktx0d0 . P_389 : localDW -> mu4qgi2zax == - 1 ?
becrktx0d0 . P_390 : localB -> mo0spoj2dp ) ; eh1kt4tbfs_p = becrktx0d0 .
P_233 / becrktx0d0 . P_229 * bdhjtvge12_p ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
ncq4vocfhq = becrktx0d0 . P_174 * becrktx0d0 . P_391 ; localB -> p3xkkxvu2y =
localDW -> mjbxwgkncv ; } localB -> knfdwxmyft = becrktx0d0 . P_509 [ ( ( (
muDoubleScalarAbs ( ( ( 0.0 - jkml1dhgc4_p ) - localB -> ncq4vocfhq ) +
localB -> ncq4vocfhq ) >= eh1kt4tbfs_p ) + ( ( uint32_T ) ( localB ->
jmccqq5v03 && ( muDoubleScalarAbs ( - jkml1dhgc4_p ) <= eh1kt4tbfs_p ) ) << 1
) ) << 1 ) + localB -> p3xkkxvu2y ] ; if ( rtmIsMajorTimeStep ( hokadafud5 )
&& rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { if ( localDW -> guacixjgv3 ) {
localDW -> guacixjgv3 = false ; eh1kt4tbfs_p = becrktx0d0 . P_393 ; } else {
eh1kt4tbfs_p = becrktx0d0 . P_392 ; } if ( eh1kt4tbfs_p > becrktx0d0 . P_394
) { localB -> ck21n4sgox = becrktx0d0 . P_391 ; } else { localB -> ck21n4sgox
= becrktx0d0 . P_241 ; } } rtPrevAction = localDW -> g1nszypg1o ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction = ( int8_T ) ! localB ->
knfdwxmyft ; localDW -> g1nszypg1o = rtAction ; } else { rtAction = localDW
-> g1nszypg1o ; } if ( rtPrevAction != rtAction ) { switch ( rtPrevAction ) {
case 0 : nm4ubjqz2k ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> cxpr0gz2hj = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { gnhczwf3q0 ( hokadafud5 ) ; } fw4l3ijud5 (
hokadafud5 , & localB -> nwft3snr2v , & jkml1dhgc4_p , & bdhjtvge12_p , &
localB -> jbxcrsbwh4 , & becrktx0d0 . jbxcrsbwh4 ) ; if ( rtmIsMajorTimeStep
( hokadafud5 ) ) { srUpdateBC ( localDW -> jbxcrsbwh4 . nizc43tvct ) ; }
break ; case 1 : if ( rtAction != rtPrevAction ) { if ( rtmIsFirstInitCond (
hokadafud5 ) ) { localX -> cxpr0gz2hj = 0.0 ; } localDW -> hrozwqlazz = 1 ;
if ( rtmGetTaskTime ( hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> cxpr0gz2hj = 0 ; } if ( localDW -> hrozwqlazz != 0 ) { localX ->
cxpr0gz2hj = localB -> ck21n4sgox ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> kyoliujx0j = ( ( muDoubleScalarTanh ( becrktx0d0
. P_256 * localX -> cxpr0gz2hj ) * bdhjtvge12_p - jkml1dhgc4_p ) - becrktx0d0
. P_174 * localX -> cxpr0gz2hj ) * ( 1.0 / becrktx0d0 . P_23 ) ; localB ->
nwft3snr2v = localX -> cxpr0gz2hj ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> etneh3gh5z ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
f0vsgrygsi = becrktx0d0 . P_395 ; localB -> onmfhkxj2b = becrktx0d0 . P_396 ;
localB -> makwuduny0 = becrktx0d0 . P_397 ; localB -> jfmfqfxlpf = becrktx0d0
. P_398 ; localB -> ka2g0q2dyz = becrktx0d0 . P_399 ; localB -> mcfsleb4vj =
becrktx0d0 . P_185 ; localB -> p04qegtreq = becrktx0d0 . P_28 ; localB ->
btyc3uconk = becrktx0d0 . P_10 ; localB -> ppbyftquej = becrktx0d0 . P_37 ;
localB -> j0ssdpfz3p = becrktx0d0 . P_400 ; localB -> d4q4amkhq0 = becrktx0d0
. P_401 ; localB -> gtcgkc52ss = becrktx0d0 . P_42 ; localB -> bdlwmagotg =
becrktx0d0 . P_46 ; localB -> ds1pko0yhn = becrktx0d0 . P_50 ; localB ->
pnx5kql1jb = becrktx0d0 . P_54 ; localB -> oqpf5cus4o = becrktx0d0 . P_58 ;
localB -> dkx50lv42s = becrktx0d0 . P_62 ; localB -> jqd2leehy4 = becrktx0d0
. P_66 ; localB -> buqrhazl3d = becrktx0d0 . P_70 ; localB -> kdkxsiypqx =
becrktx0d0 . P_82 ; localB -> kvoytc2kx3 = becrktx0d0 . P_86 ; localB ->
nmlatm1b13 = becrktx0d0 . P_90 ; localB -> didrtgo00z = becrktx0d0 . P_74 ;
localB -> b1umyxgfps = becrktx0d0 . P_78 ; localB -> jar2j2zazo = becrktx0d0
. P_110 ; localB -> ezmnobsxzk = becrktx0d0 . P_114 ; localB -> nxgmc04elj =
becrktx0d0 . P_94 ; localB -> kltug5vlk2 = becrktx0d0 . P_98 ; localB ->
lnk3wadcrw = becrktx0d0 . P_102 ; localB -> b0g0d14xp0 = becrktx0d0 . P_106 ;
localB -> ip2o31scew = becrktx0d0 . P_202 ; localB -> odpixqjulv = becrktx0d0
. P_222 ; localB -> eucw5jdhgs = becrktx0d0 . P_210 ; localB -> kbdxbjmwcc =
becrktx0d0 . P_194 ; localB -> dmpgiccwmv = becrktx0d0 . P_198 ; localB ->
ltguoy1kgf = becrktx0d0 . P_206 ; localB -> bg0ucefe4s = becrktx0d0 . P_218 ;
localB -> idnuvsq50z [ 0 ] = becrktx0d0 . P_402 [ 0 ] ; localB -> k2magdngkl
[ 0 ] = becrktx0d0 . P_403 [ 0 ] ; localB -> idnuvsq50z [ 1 ] = becrktx0d0 .
P_402 [ 1 ] ; localB -> k2magdngkl [ 1 ] = becrktx0d0 . P_403 [ 1 ] ; localB
-> idnuvsq50z [ 2 ] = becrktx0d0 . P_402 [ 2 ] ; localB -> k2magdngkl [ 2 ] =
becrktx0d0 . P_403 [ 2 ] ; localB -> cus1r3btzm = becrktx0d0 . P_10 ; localB
-> emtbde10ax = becrktx0d0 . P_37 ; localB -> is01xwy4pb = becrktx0d0 . P_119
; localB -> brtiijmgcl = becrktx0d0 . P_123 ; localB -> k3llj3imqx =
becrktx0d0 . P_127 ; localB -> b005u0x43d = becrktx0d0 . P_131 ; localB ->
nqoelq42lv = becrktx0d0 . P_135 ; localB -> lb3nqak1lw = becrktx0d0 . P_139 ;
localB -> nxu33k25qi = becrktx0d0 . P_143 ; localB -> ab5e5rggav = becrktx0d0
. P_147 ; localB -> o2sgb25vdi = becrktx0d0 . P_185 ; localB -> genmkrinba =
becrktx0d0 . P_214 ; localB -> jxhdosell2 = becrktx0d0 . P_161 ; localB ->
grnndi1soi = becrktx0d0 . P_405 ; localB -> g4ebwhkl3a = becrktx0d0 . P_406 ;
localB -> k4ryvi4c1f [ 0 ] = becrktx0d0 . P_407 [ 0 ] ; localB -> awaqkahv5l
[ 0 ] = becrktx0d0 . P_408 [ 0 ] ; localB -> k4ryvi4c1f [ 1 ] = becrktx0d0 .
P_407 [ 1 ] ; localB -> awaqkahv5l [ 1 ] = becrktx0d0 . P_408 [ 1 ] ; localB
-> k4ryvi4c1f [ 2 ] = becrktx0d0 . P_407 [ 2 ] ; localB -> awaqkahv5l [ 2 ] =
becrktx0d0 . P_408 [ 2 ] ; memcpy ( & localB -> lfpjk1p50l [ 0 ] , &
becrktx0d0 . P_404 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
bhtsxyrihr [ 0 ] , & becrktx0d0 . P_409 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> fn1rx2vpsu = becrktx0d0 . P_410 ; localB -> kecjsfbkos = becrktx0d0
. P_411 ; localB -> knpe41bj2w = becrktx0d0 . P_412 ; localB -> jnl2jrcrq0 =
becrktx0d0 . P_413 ; localB -> jnzfhnelbw = becrktx0d0 . P_414 ; localB ->
l5a1fuyb1v = becrktx0d0 . P_415 ; localB -> fku0o25hj3 = becrktx0d0 . P_416 ;
localB -> g53szwlk03 = becrktx0d0 . P_417 ; localB -> oxl2gdvlbd = becrktx0d0
. P_418 ; localB -> e5qabfmbvm = becrktx0d0 . P_419 ; localB -> fhm2jfzjpv =
becrktx0d0 . P_420 ; localB -> fmqhoucoxn = becrktx0d0 . P_421 ; localB ->
gzmu3j35nf = becrktx0d0 . P_422 ; localB -> akoimjrkbf = becrktx0d0 . P_423 ;
localB -> d5djjqarit = becrktx0d0 . P_424 ; localB -> i4itn0vlmx = becrktx0d0
. P_425 ; localB -> efpubwovgw = becrktx0d0 . P_426 ; localB -> a21u1bb14f =
becrktx0d0 . P_427 ; localB -> fmoybge41a = becrktx0d0 . P_428 ; localB ->
nhhxa0cvfm = becrktx0d0 . P_429 ; localB -> hlsow32b05 = becrktx0d0 . P_430 ;
localB -> bjuqnpreia = becrktx0d0 . P_431 ; localB -> dqix5d3stt = becrktx0d0
. P_432 ; localB -> nx2qtlsqdh = becrktx0d0 . P_433 ; localB -> j4bdy242sp =
becrktx0d0 . P_434 ; localB -> ex2ckz41n1 = becrktx0d0 . P_435 ; } ptwb5m53nr
( localB -> heksh3fd4a , nkp14nzj3q_idx_2 , localB -> nwft3snr2v , localB ->
fp0lz1z3pw [ 2 ] , localB -> f0vsgrygsi , localB -> onmfhkxj2b , localB ->
makwuduny0 , localB -> jfmfqfxlpf , localB -> ka2g0q2dyz , localB ->
mcfsleb4vj , localB -> p04qegtreq , localB -> btyc3uconk , & bv2zp3o4ji [ 2 ]
, localB -> ppbyftquej , localB -> j0ssdpfz3p , localB -> d4q4amkhq0 , localB
-> gtcgkc52ss , localB -> bdlwmagotg , localB -> ds1pko0yhn , localB ->
pnx5kql1jb , localB -> oqpf5cus4o , localB -> dkx50lv42s , localB ->
jqd2leehy4 , localB -> buqrhazl3d , localB -> kdkxsiypqx , localB ->
kvoytc2kx3 , localB -> nmlatm1b13 , localB -> didrtgo00z , localB ->
b1umyxgfps , localB -> jar2j2zazo , localB -> ezmnobsxzk , localB ->
nxgmc04elj , localB -> kltug5vlk2 , localB -> lnk3wadcrw , localB ->
b0g0d14xp0 , localB -> ip2o31scew , localB -> odpixqjulv , & czlc2qmxmx [ 2 ]
, localB -> eucw5jdhgs , localB -> kbdxbjmwcc , localB -> dmpgiccwmv , localB
-> ltguoy1kgf , localB -> bg0ucefe4s , localB -> idnuvsq50z , localB ->
k2magdngkl , localB -> lfpjk1p50l , localB -> cus1r3btzm , localB ->
emtbde10ax , localB -> is01xwy4pb , localB -> brtiijmgcl , localB ->
k3llj3imqx , localB -> b005u0x43d , localB -> nqoelq42lv , localB ->
lb3nqak1lw , localB -> nxu33k25qi , localB -> ab5e5rggav , localB ->
o2sgb25vdi , localB -> genmkrinba , localB -> jxhdosell2 , localB ->
grnndi1soi , localB -> g4ebwhkl3a , localB -> k4ryvi4c1f , localB ->
awaqkahv5l , localB -> bhtsxyrihr , 0.0 , localB -> fn1rx2vpsu , localB ->
kecjsfbkos , localB -> knpe41bj2w , localB -> jnl2jrcrq0 , localB ->
jnzfhnelbw , localB -> l5a1fuyb1v , localB -> fku0o25hj3 , localB ->
g53szwlk03 , localB -> oxl2gdvlbd , localB -> e5qabfmbvm , localB ->
fhm2jfzjpv , localB -> fmqhoucoxn , localB -> gzmu3j35nf , localB ->
akoimjrkbf , localB -> d5djjqarit , localB -> i4itn0vlmx , localB ->
efpubwovgw , localB -> a21u1bb14f , localB -> fmoybge41a , localB ->
nhhxa0cvfm , localB -> hlsow32b05 , localB -> bjuqnpreia , localB ->
dqix5d3stt , localB -> nx2qtlsqdh , localB -> j4bdy242sp , localB ->
ex2ckz41n1 , & cyqteuatay [ 2 ] , & ffnn3i1mdg [ 2 ] , & localB -> i24h43uxd3
, becrktx0d0 . P_14 , becrktx0d0 . P_18 , becrktx0d0 . P_165 , becrktx0d0 .
P_190 ) ; nd20r1di23_idx_2 = localB -> i24h43uxd3 . dbw42rwkve ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> kabqz3ukzq = becrktx0d0 . P_153 ; if ( localDW -> gihmnw5lcd ) {
localDW -> gihmnw5lcd = false ; localB -> ewn13goqxs = becrktx0d0 . P_437 ; }
else { localB -> ewn13goqxs = becrktx0d0 . P_436 ; } localB -> bwitvgjxxj =
becrktx0d0 . P_242 ; } if ( localB -> ewn13goqxs > becrktx0d0 . P_438 ) {
jkml1dhgc4_p = localX -> lqp2to1kjt ; } else { jkml1dhgc4_p = localB ->
bwitvgjxxj ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit (
hokadafud5 , 1 , 0 ) ) { zcEvent = rt_ZCFcn ( ANY_ZERO_CROSSING , & localZCE
-> l2ffm5hvos , ( jkml1dhgc4_p - becrktx0d0 . P_439 ) ) ; if ( localDW ->
d2q5lsapa3 == 0 ) { if ( zcEvent != NO_ZCEVENT ) { localB -> aix4vz50d4 = !
localB -> aix4vz50d4 ; localDW -> d2q5lsapa3 = 1 ; } else if ( localB ->
aix4vz50d4 ) { if ( jkml1dhgc4_p != becrktx0d0 . P_439 ) { localB ->
aix4vz50d4 = false ; } } else { if ( jkml1dhgc4_p == becrktx0d0 . P_439 ) {
localB -> aix4vz50d4 = true ; } } } else { if ( jkml1dhgc4_p != becrktx0d0 .
P_439 ) { localB -> aix4vz50d4 = false ; } localDW -> d2q5lsapa3 = 0 ; }
localB -> es2aoshppl = becrktx0d0 . P_181 ; localB -> h41sr5mq0f = becrktx0d0
. P_443 * localB -> es2aoshppl ; localB -> fsh4di2i1p = becrktx0d0 . P_238 ;
} jkml1dhgc4_p = localX -> betxkjviha ; bdhjtvge12_p = ( fo3cvtmfih [ 3 ] -
localX -> betxkjviha * localB -> kabqz3ukzq ) * becrktx0d0 . P_441 ; localB
-> mtju0hxa2v = becrktx0d0 . P_442 * dfx1ca0pmi [ 3 ] * localB -> h41sr5mq0f
* localB -> es2aoshppl * localB -> fsh4di2i1p ; if ( rtmIsMajorTimeStep (
hokadafud5 ) ) { localDW -> bzktqcr5po = localB -> mtju0hxa2v >= becrktx0d0 .
P_444 ? 1 : localB -> mtju0hxa2v > becrktx0d0 . P_445 ? 0 : - 1 ; }
eh1kt4tbfs_p = becrktx0d0 . P_157 * becrktx0d0 . P_230 * ( localDW ->
bzktqcr5po == 1 ? becrktx0d0 . P_444 : localDW -> bzktqcr5po == - 1 ?
becrktx0d0 . P_445 : localB -> mtju0hxa2v ) ; gdlhgdf2w4_p = becrktx0d0 .
P_234 / becrktx0d0 . P_230 * eh1kt4tbfs_p ; if ( rtmIsMajorTimeStep (
hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
lri4q5yxl4 = becrktx0d0 . P_175 * becrktx0d0 . P_446 ; localB -> lkqtbfqism =
localDW -> nsc0idk5is ; } localB -> cjos3prroo = becrktx0d0 . P_511 [ ( ( (
muDoubleScalarAbs ( ( ( 0.0 - bdhjtvge12_p ) - localB -> lri4q5yxl4 ) +
localB -> lri4q5yxl4 ) >= gdlhgdf2w4_p ) + ( ( uint32_T ) ( localB ->
aix4vz50d4 && ( muDoubleScalarAbs ( - bdhjtvge12_p ) <= gdlhgdf2w4_p ) ) << 1
) ) << 1 ) + localB -> lkqtbfqism ] ; if ( rtmIsMajorTimeStep ( hokadafud5 )
&& rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { if ( localDW -> ffcbqtf0x4 ) {
localDW -> ffcbqtf0x4 = false ; gdlhgdf2w4_p = becrktx0d0 . P_448 ; } else {
gdlhgdf2w4_p = becrktx0d0 . P_447 ; } if ( gdlhgdf2w4_p > becrktx0d0 . P_449
) { localB -> dssenryajr = becrktx0d0 . P_446 ; } else { localB -> dssenryajr
= becrktx0d0 . P_242 ; } } rtPrevAction = localDW -> ksj4vofnxt ; if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { rtAction = ( int8_T ) ! localB ->
cjos3prroo ; localDW -> ksj4vofnxt = rtAction ; } else { rtAction = localDW
-> ksj4vofnxt ; } if ( rtPrevAction != rtAction ) { switch ( rtPrevAction ) {
case 0 : nm4ubjqz2k ( hokadafud5 ) ; break ; case 1 :
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ;
localXdis -> lqp2to1kjt = 1 ; break ; } } switch ( rtAction ) { case 0 : if (
rtAction != rtPrevAction ) { gnhczwf3q0 ( hokadafud5 ) ; } fw4l3ijud5 (
hokadafud5 , & localB -> etg50mmxko , & bdhjtvge12_p , & eh1kt4tbfs_p , &
localB -> jb5oqg1xv1 , & becrktx0d0 . jb5oqg1xv1 ) ; if ( rtmIsMajorTimeStep
( hokadafud5 ) ) { srUpdateBC ( localDW -> jb5oqg1xv1 . nizc43tvct ) ; }
break ; case 1 : if ( rtAction != rtPrevAction ) { if ( rtmIsFirstInitCond (
hokadafud5 ) ) { localX -> lqp2to1kjt = 0.0 ; } localDW -> p30ktu555o = 1 ;
if ( rtmGetTaskTime ( hokadafud5 , 0 ) != rtmGetTStart ( hokadafud5 ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 -> _mdlRefSfcnS ) ; }
localXdis -> lqp2to1kjt = 0 ; } if ( localDW -> p30ktu555o != 0 ) { localX ->
lqp2to1kjt = localB -> dssenryajr ;
ssSetContTimeOutputInconsistentWithStateAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; } localB -> my2ijmg4ja = ( ( muDoubleScalarTanh ( becrktx0d0
. P_258 * localX -> lqp2to1kjt ) * eh1kt4tbfs_p - bdhjtvge12_p ) - becrktx0d0
. P_175 * localX -> lqp2to1kjt ) * ( 1.0 / becrktx0d0 . P_24 ) ; localB ->
etg50mmxko = localX -> lqp2to1kjt ; if ( rtmIsMajorTimeStep ( hokadafud5 ) )
{ srUpdateBC ( localDW -> cujexquuia ) ; } break ; } if ( rtmIsMajorTimeStep
( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB ->
lbyadjdncx = becrktx0d0 . P_450 ; localB -> lh2p35lc50 = becrktx0d0 . P_451 ;
localB -> d3l5c3efvv = becrktx0d0 . P_452 ; localB -> fgxgazmjuv = becrktx0d0
. P_453 ; localB -> omlqqotem3 = becrktx0d0 . P_454 ; localB -> lle222r3j0 =
becrktx0d0 . P_186 ; localB -> pchqhi1ge4 = becrktx0d0 . P_29 ; localB ->
jrkpmqxqzg = becrktx0d0 . P_11 ; localB -> k2m1bl3r20 = becrktx0d0 . P_38 ;
localB -> a4eu3vnrpy = becrktx0d0 . P_455 ; localB -> pkwfnpnafc = becrktx0d0
. P_456 ; localB -> bgdkdg01tl = becrktx0d0 . P_43 ; localB -> mg3pmuefg4 =
becrktx0d0 . P_47 ; localB -> ctmsdct5g1 = becrktx0d0 . P_51 ; localB ->
izptjpab53 = becrktx0d0 . P_55 ; localB -> nkapvnd2vd = becrktx0d0 . P_59 ;
localB -> jcwcnjif1u = becrktx0d0 . P_63 ; localB -> j4hs5qkqll = becrktx0d0
. P_67 ; localB -> ieqhfhksug = becrktx0d0 . P_71 ; localB -> lb0yj1o1mb =
becrktx0d0 . P_83 ; localB -> jflqep0teo = becrktx0d0 . P_87 ; localB ->
nko50awlgb = becrktx0d0 . P_91 ; localB -> fo0lbkinxi = becrktx0d0 . P_75 ;
localB -> apyxj1livc = becrktx0d0 . P_79 ; localB -> kch0r3cpm0 = becrktx0d0
. P_111 ; localB -> p2penhk4ls = becrktx0d0 . P_115 ; localB -> adeucydncx =
becrktx0d0 . P_95 ; localB -> c1vxxjdkmt = becrktx0d0 . P_99 ; localB ->
n5uwu02nod = becrktx0d0 . P_103 ; localB -> bcigtnratx = becrktx0d0 . P_107 ;
localB -> nedy5ldyk4 = becrktx0d0 . P_203 ; localB -> kmai0par5q = becrktx0d0
. P_223 ; localB -> ds51cr1pqj = becrktx0d0 . P_211 ; localB -> ek2gcvl551 =
becrktx0d0 . P_195 ; localB -> cdy3v0ud4e = becrktx0d0 . P_199 ; localB ->
n2cirx1p0q = becrktx0d0 . P_207 ; localB -> f54jwwj4gx = becrktx0d0 . P_219 ;
localB -> fqxqkg1alg [ 0 ] = becrktx0d0 . P_457 [ 0 ] ; localB -> csf03krjk1
[ 0 ] = becrktx0d0 . P_458 [ 0 ] ; localB -> fqxqkg1alg [ 1 ] = becrktx0d0 .
P_457 [ 1 ] ; localB -> csf03krjk1 [ 1 ] = becrktx0d0 . P_458 [ 1 ] ; localB
-> fqxqkg1alg [ 2 ] = becrktx0d0 . P_457 [ 2 ] ; localB -> csf03krjk1 [ 2 ] =
becrktx0d0 . P_458 [ 2 ] ; localB -> buuub0grk3 = becrktx0d0 . P_11 ; localB
-> ezev30mpgc = becrktx0d0 . P_38 ; localB -> c1jshz5jay = becrktx0d0 . P_120
; localB -> ddx2axounw = becrktx0d0 . P_124 ; localB -> i3rbkx4cxs =
becrktx0d0 . P_128 ; localB -> kctu0ahldd = becrktx0d0 . P_132 ; localB ->
m2v5mweb4k = becrktx0d0 . P_136 ; localB -> knlurbsiqt = becrktx0d0 . P_140 ;
localB -> ipnvro5jnu = becrktx0d0 . P_144 ; localB -> f1pabfvtek = becrktx0d0
. P_148 ; localB -> huqqwotobu = becrktx0d0 . P_186 ; localB -> d4ikkqecf4 =
becrktx0d0 . P_215 ; localB -> fks0ntwklm = becrktx0d0 . P_162 ; localB ->
i5iluqyceo = becrktx0d0 . P_460 ; localB -> kjzjtihdtp = becrktx0d0 . P_461 ;
localB -> gv4e3mhryb [ 0 ] = becrktx0d0 . P_462 [ 0 ] ; localB -> mnmnycaifv
[ 0 ] = becrktx0d0 . P_463 [ 0 ] ; localB -> gv4e3mhryb [ 1 ] = becrktx0d0 .
P_462 [ 1 ] ; localB -> mnmnycaifv [ 1 ] = becrktx0d0 . P_463 [ 1 ] ; localB
-> gv4e3mhryb [ 2 ] = becrktx0d0 . P_462 [ 2 ] ; localB -> mnmnycaifv [ 2 ] =
becrktx0d0 . P_463 [ 2 ] ; memcpy ( & localB -> f4nd4h3rdi [ 0 ] , &
becrktx0d0 . P_459 [ 0 ] , 9U * sizeof ( real_T ) ) ; memcpy ( & localB ->
cigblwahak [ 0 ] , & becrktx0d0 . P_464 [ 0 ] , 9U * sizeof ( real_T ) ) ;
localB -> d4na1jxh2p = becrktx0d0 . P_465 ; localB -> hhl0nour2n = becrktx0d0
. P_466 ; localB -> h1a54ayhvb = becrktx0d0 . P_467 ; localB -> oskikps4cd =
becrktx0d0 . P_468 ; localB -> lfcxaxdqqa = becrktx0d0 . P_469 ; localB ->
gi4hvkrulw = becrktx0d0 . P_470 ; localB -> mxiwfmh0m2 = becrktx0d0 . P_471 ;
localB -> hmm1nxv52h = becrktx0d0 . P_472 ; localB -> b3iurqll4v = becrktx0d0
. P_473 ; localB -> by214ztw3x = becrktx0d0 . P_474 ; localB -> djpzfwrqq0 =
becrktx0d0 . P_475 ; localB -> p1h0l1qmrs = becrktx0d0 . P_476 ; localB ->
l12eogpfa5 = becrktx0d0 . P_477 ; localB -> n3gz0mz23s = becrktx0d0 . P_478 ;
localB -> m1ysf5objc = becrktx0d0 . P_479 ; localB -> daaxem51rl = becrktx0d0
. P_480 ; localB -> fpwy5z1ghs = becrktx0d0 . P_481 ; localB -> bcx3tf0im1 =
becrktx0d0 . P_482 ; localB -> ix4r0g0kd4 = becrktx0d0 . P_483 ; localB ->
oidumovatz = becrktx0d0 . P_484 ; localB -> hgenpusx24 = becrktx0d0 . P_485 ;
localB -> dsumzfgjxq = becrktx0d0 . P_486 ; localB -> e2ezk3qkym = becrktx0d0
. P_487 ; localB -> m4domxuial = becrktx0d0 . P_488 ; localB -> nc1rcr52pc =
becrktx0d0 . P_489 ; localB -> fjht5toahx = becrktx0d0 . P_490 ; } ptwb5m53nr
( localB -> kabqz3ukzq , nkp14nzj3q_idx_3 , localB -> etg50mmxko , localB ->
fp0lz1z3pw [ 3 ] , localB -> lbyadjdncx , localB -> lh2p35lc50 , localB ->
d3l5c3efvv , localB -> fgxgazmjuv , localB -> omlqqotem3 , localB ->
lle222r3j0 , localB -> pchqhi1ge4 , localB -> jrkpmqxqzg , & bv2zp3o4ji [ 3 ]
, localB -> k2m1bl3r20 , localB -> a4eu3vnrpy , localB -> pkwfnpnafc , localB
-> bgdkdg01tl , localB -> mg3pmuefg4 , localB -> ctmsdct5g1 , localB ->
izptjpab53 , localB -> nkapvnd2vd , localB -> jcwcnjif1u , localB ->
j4hs5qkqll , localB -> ieqhfhksug , localB -> lb0yj1o1mb , localB ->
jflqep0teo , localB -> nko50awlgb , localB -> fo0lbkinxi , localB ->
apyxj1livc , localB -> kch0r3cpm0 , localB -> p2penhk4ls , localB ->
adeucydncx , localB -> c1vxxjdkmt , localB -> n5uwu02nod , localB ->
bcigtnratx , localB -> nedy5ldyk4 , localB -> kmai0par5q , & czlc2qmxmx [ 3 ]
, localB -> ds51cr1pqj , localB -> ek2gcvl551 , localB -> cdy3v0ud4e , localB
-> n2cirx1p0q , localB -> f54jwwj4gx , localB -> fqxqkg1alg , localB ->
csf03krjk1 , localB -> f4nd4h3rdi , localB -> buuub0grk3 , localB ->
ezev30mpgc , localB -> c1jshz5jay , localB -> ddx2axounw , localB ->
i3rbkx4cxs , localB -> kctu0ahldd , localB -> m2v5mweb4k , localB ->
knlurbsiqt , localB -> ipnvro5jnu , localB -> f1pabfvtek , localB ->
huqqwotobu , localB -> d4ikkqecf4 , localB -> fks0ntwklm , localB ->
i5iluqyceo , localB -> kjzjtihdtp , localB -> gv4e3mhryb , localB ->
mnmnycaifv , localB -> cigblwahak , 0.0 , localB -> d4na1jxh2p , localB ->
hhl0nour2n , localB -> h1a54ayhvb , localB -> oskikps4cd , localB ->
lfcxaxdqqa , localB -> gi4hvkrulw , localB -> mxiwfmh0m2 , localB ->
hmm1nxv52h , localB -> b3iurqll4v , localB -> by214ztw3x , localB ->
djpzfwrqq0 , localB -> p1h0l1qmrs , localB -> l12eogpfa5 , localB ->
n3gz0mz23s , localB -> m1ysf5objc , localB -> daaxem51rl , localB ->
fpwy5z1ghs , localB -> bcx3tf0im1 , localB -> ix4r0g0kd4 , localB ->
oidumovatz , localB -> hgenpusx24 , localB -> dsumzfgjxq , localB ->
e2ezk3qkym , localB -> m4domxuial , localB -> nc1rcr52pc , localB ->
fjht5toahx , & cyqteuatay [ 3 ] , & ffnn3i1mdg [ 3 ] , & localB -> fbdb5pexuk
, becrktx0d0 . P_15 , becrktx0d0 . P_19 , becrktx0d0 . P_166 , becrktx0d0 .
P_191 ) ; if ( nd20r1di23_idx_0 > becrktx0d0 . P_492 ) { nd20r1di23_idx_0 -=
becrktx0d0 . P_492 ; } else if ( nd20r1di23_idx_0 >= becrktx0d0 . P_491 ) {
nd20r1di23_idx_0 = 0.0 ; } else { nd20r1di23_idx_0 -= becrktx0d0 . P_491 ; }
if ( nd20r1di23_idx_1 > becrktx0d0 . P_492 ) { nd20r1di23_idx_1 -= becrktx0d0
. P_492 ; } else if ( nd20r1di23_idx_1 >= becrktx0d0 . P_491 ) {
nd20r1di23_idx_1 = 0.0 ; } else { nd20r1di23_idx_1 -= becrktx0d0 . P_491 ; }
if ( nd20r1di23_idx_2 > becrktx0d0 . P_492 ) { nd20r1di23_idx_2 -= becrktx0d0
. P_492 ; } else if ( nd20r1di23_idx_2 >= becrktx0d0 . P_491 ) {
nd20r1di23_idx_2 = 0.0 ; } else { nd20r1di23_idx_2 -= becrktx0d0 . P_491 ; }
if ( localB -> fbdb5pexuk . dbw42rwkve > becrktx0d0 . P_492 ) { nd20r1di23_p
= localB -> fbdb5pexuk . dbw42rwkve - becrktx0d0 . P_492 ; } else if ( localB
-> fbdb5pexuk . dbw42rwkve >= becrktx0d0 . P_491 ) { nd20r1di23_p = 0.0 ; }
else { nd20r1di23_p = localB -> fbdb5pexuk . dbw42rwkve - becrktx0d0 . P_491
; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1
, 0 ) ) { eueb01ol1w [ 0 ] = 0.0 ; eueb01ol1w [ 1 ] = 0.0 ; eueb01ol1w [ 2 ]
= 0.0 ; eueb01ol1w [ 3 ] = 0.0 ; eueb01ol1w [ 0 ] = - eueb01ol1w [ 0 ] ;
eueb01ol1w [ 1 ] = - eueb01ol1w [ 1 ] ; eueb01ol1w [ 2 ] = - eueb01ol1w [ 2 ]
; eueb01ol1w [ 3 ] = - eueb01ol1w [ 3 ] ; localB -> eebgpz0vzg = becrktx0d0 .
P_30 ; localB -> m1s5erfnwn = - becrktx0d0 . P_163 ; localB -> j31uqmhbxd =
becrktx0d0 . P_163 ; } eh1kt4tbfs_p = localB -> bjtohmekdm * localB ->
oxucuqlz4d ; if ( ( eh1kt4tbfs_p >= localB -> m1s5erfnwn ) && ( eh1kt4tbfs_p
<= localB -> j31uqmhbxd ) ) { eh1kt4tbfs_p = 1.0 / ( 3.0 -
muDoubleScalarPower ( eh1kt4tbfs_p / 0.5 , 2.0 ) ) ; } else { eh1kt4tbfs_p =
muDoubleScalarAbs ( eh1kt4tbfs_p ) ; } localB -> dojjjby12g = ( ( localB ->
f1abnn2ast . imuoerh5jm / localB -> oxucuqlz4d + localB -> f1abnn2ast .
dbw42rwkve ) - ipxtggw2ad_p ) * ( eh1kt4tbfs_p / localB -> eebgpz0vzg ) ; if
( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 )
) { localB -> enxc5x5lm4 = becrktx0d0 . P_31 ; localB -> cccdg3551e = -
becrktx0d0 . P_164 ; localB -> c3jn3ij4j1 = becrktx0d0 . P_164 ; }
ipxtggw2ad_p = localB -> hhuwm0io3s * localB -> fugevmefkb ; if ( (
ipxtggw2ad_p >= localB -> cccdg3551e ) && ( ipxtggw2ad_p <= localB ->
c3jn3ij4j1 ) ) { ipxtggw2ad_p = 1.0 / ( 3.0 - muDoubleScalarPower (
ipxtggw2ad_p / 0.5 , 2.0 ) ) ; } else { ipxtggw2ad_p = muDoubleScalarAbs (
ipxtggw2ad_p ) ; } localB -> fircvrvyml = ( ( localB -> dycowragfc .
imuoerh5jm / localB -> fugevmefkb + localB -> dycowragfc . dbw42rwkve ) -
mtt4yva3gs_p ) * ( ipxtggw2ad_p / localB -> enxc5x5lm4 ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> l5cqbsnku1 = becrktx0d0 . P_32 ; localB -> m4emkhvth1 = -
becrktx0d0 . P_165 ; localB -> gdpqix4jpq = becrktx0d0 . P_165 ; }
ipxtggw2ad_p = localB -> nwft3snr2v * localB -> heksh3fd4a ; if ( (
ipxtggw2ad_p >= localB -> m4emkhvth1 ) && ( ipxtggw2ad_p <= localB ->
gdpqix4jpq ) ) { ipxtggw2ad_p = 1.0 / ( 3.0 - muDoubleScalarPower (
ipxtggw2ad_p / 0.5 , 2.0 ) ) ; } else { ipxtggw2ad_p = muDoubleScalarAbs (
ipxtggw2ad_p ) ; } localB -> jyeb4frt10 = ( ( localB -> i24h43uxd3 .
imuoerh5jm / localB -> heksh3fd4a + localB -> i24h43uxd3 . dbw42rwkve ) -
iywjngy1pp_p ) * ( ipxtggw2ad_p / localB -> l5cqbsnku1 ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> fz3fkamkk0 = becrktx0d0 . P_33 ; localB -> m0wl0gwcta = -
becrktx0d0 . P_166 ; localB -> ef4fwgtsyg = becrktx0d0 . P_166 ; }
ipxtggw2ad_p = localB -> etg50mmxko * localB -> kabqz3ukzq ; if ( (
ipxtggw2ad_p >= localB -> m0wl0gwcta ) && ( ipxtggw2ad_p <= localB ->
ef4fwgtsyg ) ) { ipxtggw2ad_p = 1.0 / ( 3.0 - muDoubleScalarPower (
ipxtggw2ad_p / 0.5 , 2.0 ) ) ; } else { ipxtggw2ad_p = muDoubleScalarAbs (
ipxtggw2ad_p ) ; } localB -> d3jtlyfeug = ( ( localB -> fbdb5pexuk .
imuoerh5jm / localB -> kabqz3ukzq + localB -> fbdb5pexuk . dbw42rwkve ) -
jkml1dhgc4_p ) * ( ipxtggw2ad_p / localB -> fz3fkamkk0 ) ; av2ap4nkgj [ 0 ] =
localB -> bjtohmekdm ; av2ap4nkgj [ 1 ] = localB -> hhuwm0io3s ; av2ap4nkgj [
2 ] = localB -> nwft3snr2v ; av2ap4nkgj [ 3 ] = localB -> etg50mmxko ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> jbvz1saibt [ 0 ] = becrktx0d0 . P_493 ; localB -> jbvz1saibt [ 1
] = becrktx0d0 . P_493 ; localB -> cbkp5rxvm4 [ 0 ] = becrktx0d0 . P_494 [ 0
] ; localB -> cbkp5rxvm4 [ 1 ] = becrktx0d0 . P_494 [ 1 ] ; localB ->
cbkp5rxvm4 [ 2 ] = becrktx0d0 . P_494 [ 2 ] ; } muDoubleScalarSinCos (
lbi5iovzof_idx_2 , & ipxtggw2ad_p , & mtt4yva3gs_p ) ; ewytrsohkb_p [ 0 ] =
lbi5iovzof_idx_0 - ( mtt4yva3gs_p * pf4xf35zus [ 0 ] + ipxtggw2ad_p *
pf4xf35zus [ 1 ] ) ; ewytrsohkb_p [ 1 ] = lbi5iovzof_idx_1 - ( mtt4yva3gs_p *
pf4xf35zus [ 1 ] - ipxtggw2ad_p * pf4xf35zus [ 0 ] ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> mi5jvi15pi [ 0 ] = - localB -> cbkp5rxvm4 [ 0 ] ; localB ->
mi5jvi15pi [ 1 ] = - localB -> cbkp5rxvm4 [ 1 ] ; localB -> mi5jvi15pi [ 2 ]
= - localB -> cbkp5rxvm4 [ 2 ] ; } if ( ewytrsohkb_p [ 0 ] >= becrktx0d0 .
P_495 ) { egwdhsr12b_p [ 0 ] = localB -> cbkp5rxvm4 [ 0 ] ; } else {
egwdhsr12b_p [ 0 ] = localB -> mi5jvi15pi [ 0 ] ; } if ( ewytrsohkb_p [ 1 ]
>= becrktx0d0 . P_495 ) { egwdhsr12b_p [ 1 ] = localB -> cbkp5rxvm4 [ 1 ] ; }
else { egwdhsr12b_p [ 1 ] = localB -> mi5jvi15pi [ 1 ] ; } if ( 0.0 -
pf4xf35zus [ 2 ] >= becrktx0d0 . P_495 ) { egwdhsr12b_p [ 2 ] = localB ->
cbkp5rxvm4 [ 2 ] ; } else { egwdhsr12b_p [ 2 ] = localB -> mi5jvi15pi [ 2 ] ;
} iywjngy1pp_p = ( 0.0 - pf4xf35zus [ 2 ] ) * ( 0.0 - pf4xf35zus [ 2 ] ) + (
ewytrsohkb_p [ 0 ] * ewytrsohkb_p [ 0 ] + ewytrsohkb_p [ 1 ] * ewytrsohkb_p [
1 ] ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) ) { if ( localDW -> fvd2istvuu
!= 0 ) { ssSetBlockStateForSolverChangedAtMajorStep ( hokadafud5 ->
_mdlRefSfcnS ) ; localDW -> fvd2istvuu = 0 ; } ipxtggw2ad_p =
muDoubleScalarSqrt ( iywjngy1pp_p ) ; } else if ( iywjngy1pp_p < 0.0 ) {
ipxtggw2ad_p = - muDoubleScalarSqrt ( muDoubleScalarAbs ( iywjngy1pp_p ) ) ;
localDW -> fvd2istvuu = 1 ; } else { ipxtggw2ad_p = muDoubleScalarSqrt (
iywjngy1pp_p ) ; } iywjngy1pp_p = ipxtggw2ad_p * ipxtggw2ad_p ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> gtwgjfs43r [ 0 ] = becrktx0d0 . P_1 ; } ipxtggw2ad_p =
muDoubleScalarAtan2 ( ewytrsohkb_p [ 1 ] , ewytrsohkb_p [ 0 ] ) ; localB ->
gtwgjfs43r [ 1 ] = look1_binlcpw ( ipxtggw2ad_p , becrktx0d0 . P_171 ,
becrktx0d0 . P_4 , 30U ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> gtwgjfs43r [ 2 ] =
becrktx0d0 . P_2 ; localB -> nllk5i4gzs = becrktx0d0 . P_3 ; } localB ->
gtwgjfs43r [ 3 ] = look1_binlxpw ( ipxtggw2ad_p , becrktx0d0 . P_497 ,
becrktx0d0 . P_496 , 1U ) ; localB -> gtwgjfs43r [ 4 ] = egwdhsr12b_p [ 0 ] *
localB -> nllk5i4gzs ; localB -> gtwgjfs43r [ 5 ] = look1_binlxpw (
ipxtggw2ad_p , becrktx0d0 . P_171 , becrktx0d0 . P_7 , 30U ) ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> ndkynghq1s = becrktx0d0 . P_158 ; } ipxtggw2ad_p = 0.5 *
becrktx0d0 . P_0 * becrktx0d0 . P_116 / becrktx0d0 . P_149 ; for ( i = 0 ; i
< 6 ; i ++ ) { dlf4omiy42_p [ i ] = iywjngy1pp_p * localB -> gtwgjfs43r [ i ]
/ localB -> ndkynghq1s * ipxtggw2ad_p ; } egwdhsr12b_p [ 0 ] = - (
egwdhsr12b_p [ 0 ] * dlf4omiy42_p [ 0 ] ) ; egwdhsr12b_p [ 1 ] = - (
egwdhsr12b_p [ 1 ] * dlf4omiy42_p [ 1 ] ) ; ipxtggw2ad_p = - ( egwdhsr12b_p [
2 ] * dlf4omiy42_p [ 2 ] ) ; if ( rtmIsMajorTimeStep ( hokadafud5 ) &&
rtmIsSampleHit ( hokadafud5 , 1 , 0 ) ) { localB -> namy5gwh0d = becrktx0d0 .
P_169 + becrktx0d0 . P_170 ; localB -> i3bz4euitt [ 0 ] = becrktx0d0 . P_5 ;
localB -> i3bz4euitt [ 1 ] = becrktx0d0 . P_5 ; localB -> mvdxvswfk4 [ 0 ] =
becrktx0d0 . P_6 ; localB -> mvdxvswfk4 [ 1 ] = becrktx0d0 . P_6 ; }
ewytrsohkb_p [ 0 ] = - ( dlf4omiy42_p [ 3 ] * localB -> namy5gwh0d ) ;
ewytrsohkb_p [ 1 ] = - ( dlf4omiy42_p [ 4 ] * localB -> namy5gwh0d ) ;
ewytrsohkb_p [ 2 ] = - ( dlf4omiy42_p [ 5 ] * localB -> namy5gwh0d ) ;
gdlhgdf2w4_p = muDoubleScalarAbs ( lbi5iovzof_idx_0 ) ; i = 0 ; if (
gdlhgdf2w4_p < becrktx0d0 . P_249 ) { i = 1 ; } if ( 0 <= i - 1 ) { alfa_fr =
gdlhgdf2w4_p / becrktx0d0 . P_249 ; alfa_rl = alfa_fr ; } if ( 0 <= i - 1 ) {
alfa_rl = alfa_fr * alfa_fr ; } loop_ub = i - 1 ; iywjngy1pp_p = alfa_rl ;
for ( i = 0 ; i <= loop_ub ; i ++ ) { iywjngy1pp_p = 2.0 * becrktx0d0 . P_249
/ ( 3.0 - iywjngy1pp_p ) ; alfa_rl = iywjngy1pp_p ; } mtt4yva3gs_p =
gdlhgdf2w4_p ; if ( gdlhgdf2w4_p < becrktx0d0 . P_249 ) { mtt4yva3gs_p =
alfa_rl ; } i = 0 ; if ( lbi5iovzof_idx_0 < 0.0 ) { i = 1 ; } if ( 0 <= i - 1
) { alfa_fr = - mtt4yva3gs_p ; } if ( lbi5iovzof_idx_0 < 0.0 ) { mtt4yva3gs_p
= alfa_fr ; } iywjngy1pp_p = gxlrb30ei4 [ 0 ] ; jkml1dhgc4_p = gxlrb30ei4 [ 1
] ; bdhjtvge12_p = localB -> jbvz1saibt [ 0 ] ; eh1kt4tbfs_p = localB ->
jbvz1saibt [ 1 ] ; if ( gdlhgdf2w4_p <= becrktx0d0 . P_249 ) { Fz_idx_0 =
muDoubleScalarTanh ( 4.0 * muDoubleScalarAbs ( lbi5iovzof_idx_1 ) ) ;
gdlhgdf2w4_p = ( muDoubleScalarAtan ( ( becrktx0d0 . P_169 * lbi5iovzof_idx_3
+ lbi5iovzof_idx_1 ) / ( becrktx0d0 . P_246 [ 0 ] / 2.0 * lbi5iovzof_idx_3 +
mtt4yva3gs_p ) ) - gxlrb30ei4 [ 0 ] ) * Fz_idx_0 ; alfa_fr = (
muDoubleScalarAtan ( ( becrktx0d0 . P_169 * lbi5iovzof_idx_3 +
lbi5iovzof_idx_1 ) / ( mtt4yva3gs_p - becrktx0d0 . P_246 [ 0 ] / 2.0 *
lbi5iovzof_idx_3 ) ) - gxlrb30ei4 [ 1 ] ) * Fz_idx_0 ; alfa_rl = (
muDoubleScalarAtan ( ( lbi5iovzof_idx_1 - becrktx0d0 . P_170 *
lbi5iovzof_idx_3 ) / ( becrktx0d0 . P_246 [ 1 ] / 2.0 * lbi5iovzof_idx_3 +
mtt4yva3gs_p ) ) - localB -> jbvz1saibt [ 0 ] ) * Fz_idx_0 ; mtt4yva3gs_p = (
muDoubleScalarAtan ( ( lbi5iovzof_idx_1 - becrktx0d0 . P_170 *
lbi5iovzof_idx_3 ) / ( mtt4yva3gs_p - becrktx0d0 . P_246 [ 1 ] / 2.0 *
lbi5iovzof_idx_3 ) ) - localB -> jbvz1saibt [ 1 ] ) * Fz_idx_0 ; } else {
alfa_fr = becrktx0d0 . P_246 [ 0 ] / 2.0 * lbi5iovzof_idx_3 ; alfa_rl =
becrktx0d0 . P_169 * lbi5iovzof_idx_3 + lbi5iovzof_idx_1 ; Fz_idx_0 =
muDoubleScalarTanh ( 4.0 * lbi5iovzof_idx_0 ) ; gdlhgdf2w4_p = (
muDoubleScalarAtan ( alfa_rl / ( alfa_fr + mtt4yva3gs_p ) ) - gxlrb30ei4 [ 0
] ) * Fz_idx_0 ; alfa_fr = ( muDoubleScalarAtan ( alfa_rl / ( mtt4yva3gs_p -
alfa_fr ) ) - gxlrb30ei4 [ 1 ] ) * Fz_idx_0 ; Fz_idx_1 = becrktx0d0 . P_246 [
1 ] / 2.0 * lbi5iovzof_idx_3 ; Fz_rnom = lbi5iovzof_idx_1 - becrktx0d0 .
P_170 * lbi5iovzof_idx_3 ; alfa_rl = ( muDoubleScalarAtan ( Fz_rnom / (
Fz_idx_1 + mtt4yva3gs_p ) ) - localB -> jbvz1saibt [ 0 ] ) * Fz_idx_0 ;
mtt4yva3gs_p = ( muDoubleScalarAtan ( Fz_rnom / ( mtt4yva3gs_p - Fz_idx_1 ) )
- localB -> jbvz1saibt [ 1 ] ) * Fz_idx_0 ; } Fz_idx_0 = 0.0 ; Fz_idx_1 = 0.0
; Fz_idx_2 = 0.0 ; Fz_idx_3 = 0.0 ; for ( i = 0 ; i < 11 ; i ++ ) { if ( i ==
0 ) { Fz_idx_0 = - lbi5iovzof_idx_1 * lbi5iovzof_idx_3 * becrktx0d0 . P_187 ;
xddot = egwdhsr12b_p [ 0 ] * becrktx0d0 . P_187 ; Fz_idx_1 = ( ( ( (
becrktx0d0 . P_182 * becrktx0d0 . P_170 - Fz_idx_0 ) * becrktx0d0 . P_226 +
ipxtggw2ad_p * becrktx0d0 . P_170 ) + xddot ) - ewytrsohkb_p [ 1 ] ) / (
becrktx0d0 . P_169 + becrktx0d0 . P_170 ) ; Fz_rnom = ( ( ( ( Fz_idx_0 +
becrktx0d0 . P_182 * becrktx0d0 . P_169 ) * becrktx0d0 . P_226 + ipxtggw2ad_p
* becrktx0d0 . P_169 ) - xddot ) + ewytrsohkb_p [ 1 ] ) / ( becrktx0d0 .
P_169 + becrktx0d0 . P_170 ) ; Fz_idx_2 = lbi5iovzof_idx_0 * lbi5iovzof_idx_3
; Fy_fr = egwdhsr12b_p [ 1 ] * becrktx0d0 . P_187 ; xddot = ( Fz_idx_2 *
becrktx0d0 . P_226 * becrktx0d0 . P_187 - Fy_fr ) + ewytrsohkb_p [ 0 ] ;
Fz_idx_0 = ( xddot + Fz_idx_1 ) * ( becrktx0d0 . P_246 [ 0 ] / 2.0 -
becrktx0d0 . P_177 ) / ( becrktx0d0 . P_246 [ 0 ] / 2.0 ) ; Fz_idx_3 = (
Fz_idx_2 * - becrktx0d0 . P_226 * becrktx0d0 . P_187 + Fy_fr ) + ewytrsohkb_p
[ 0 ] ; Fz_idx_1 = ( Fz_idx_3 + Fz_idx_1 ) * ( becrktx0d0 . P_246 [ 0 ] / 2.0
+ becrktx0d0 . P_177 ) / ( becrktx0d0 . P_246 [ 0 ] / 2.0 ) ; Fz_idx_2 = (
xddot + Fz_rnom ) * ( becrktx0d0 . P_246 [ 1 ] / 2.0 - becrktx0d0 . P_177 ) /
( becrktx0d0 . P_246 [ 1 ] / 2.0 ) ; Fz_idx_3 = ( Fz_idx_3 + Fz_rnom ) * (
becrktx0d0 . P_246 [ 1 ] / 2.0 + becrktx0d0 . P_177 ) / ( becrktx0d0 . P_246
[ 1 ] / 2.0 ) ; if ( Fz_idx_0 < 0.0 ) { Fz_idx_0 = 0.0 ; } if ( Fz_idx_1 <
0.0 ) { Fz_idx_1 = 0.0 ; } if ( Fz_idx_2 < 0.0 ) { Fz_idx_2 = 0.0 ; } if (
Fz_idx_3 < 0.0 ) { Fz_idx_3 = 0.0 ; } } hewkpcvg5g ( nd20r1di23_idx_0 , -
localB -> i3bz4euitt [ 0 ] / 2.0 * gdlhgdf2w4_p * czlc2qmxmx [ 0 ] * Fz_idx_0
/ becrktx0d0 . P_20 , becrktx0d0 . P_259 * Fz_idx_0 / becrktx0d0 . P_20 ,
becrktx0d0 . P_260 * Fz_idx_0 / becrktx0d0 . P_20 , & Fy_fl , & Fx_fr ) ;
hewkpcvg5g ( nd20r1di23_idx_1 , - localB -> i3bz4euitt [ 1 ] / 2.0 * alfa_fr
* czlc2qmxmx [ 2 ] * Fz_idx_1 / becrktx0d0 . P_20 , becrktx0d0 . P_259 *
Fz_idx_1 / becrktx0d0 . P_20 , becrktx0d0 . P_260 * Fz_idx_1 / becrktx0d0 .
P_20 , & Fy_fr , & Fz_idx_0 ) ; hewkpcvg5g ( nd20r1di23_idx_2 , - localB ->
mvdxvswfk4 [ 0 ] / 2.0 * alfa_rl * czlc2qmxmx [ 1 ] * Fz_idx_2 / becrktx0d0 .
P_20 , becrktx0d0 . P_259 * Fz_idx_2 / becrktx0d0 . P_20 , becrktx0d0 . P_260
* Fz_idx_2 / becrktx0d0 . P_20 , & Fz_idx_1 , & Fz_rnom ) ; hewkpcvg5g (
nd20r1di23_p , - localB -> mvdxvswfk4 [ 1 ] / 2.0 * mtt4yva3gs_p * czlc2qmxmx
[ 3 ] * Fz_idx_3 / becrktx0d0 . P_20 , becrktx0d0 . P_259 * Fz_idx_3 /
becrktx0d0 . P_20 , becrktx0d0 . P_260 * Fz_idx_3 / becrktx0d0 . P_20 , &
Fz_idx_2 , & xddot ) ; Fx_fl_tmp = muDoubleScalarCos ( iywjngy1pp_p ) ;
Fx_fl_tmp_p = muDoubleScalarSin ( iywjngy1pp_p ) ; Fz_idx_3 = Fy_fl *
Fx_fl_tmp - Fx_fr * Fx_fl_tmp_p ; Fy_fl = Fx_fr * Fx_fl_tmp - Fy_fl *
Fx_fl_tmp_p ; Fx_fl_tmp = muDoubleScalarCos ( jkml1dhgc4_p ) ; Fx_fl_tmp_p =
muDoubleScalarSin ( jkml1dhgc4_p ) ; Fx_fr = Fy_fr * Fx_fl_tmp - Fz_idx_0 *
Fx_fl_tmp_p ; Fy_fr = Fz_idx_0 * Fx_fl_tmp - Fy_fr * Fx_fl_tmp_p ; Fx_fl_tmp
= muDoubleScalarCos ( bdhjtvge12_p ) ; Fx_fl_tmp_p = muDoubleScalarSin (
bdhjtvge12_p ) ; Fz_idx_0 = Fz_idx_1 * Fx_fl_tmp - Fz_rnom * Fx_fl_tmp_p ;
Fz_idx_1 = Fz_rnom * Fx_fl_tmp - Fz_idx_1 * Fx_fl_tmp_p ; Fx_fl_tmp =
muDoubleScalarCos ( eh1kt4tbfs_p ) ; Fx_fl_tmp_p = muDoubleScalarSin (
eh1kt4tbfs_p ) ; Fz_rnom = Fz_idx_2 * Fx_fl_tmp - xddot * Fx_fl_tmp_p ;
Fz_idx_2 = xddot * Fx_fl_tmp - Fz_idx_2 * Fx_fl_tmp_p ; Fx_fl_tmp =
lbi5iovzof_idx_1 * lbi5iovzof_idx_3 ; xddot = ( ( ( ( ( Fz_idx_3 + Fx_fr ) +
Fz_idx_0 ) + Fz_rnom ) - becrktx0d0 . P_182 * 0.0 ) + egwdhsr12b_p [ 0 ] ) /
becrktx0d0 . P_226 + Fx_fl_tmp ; Fy_fr += Fy_fl ; Fy_fl = ( ( ( Fy_fr +
Fz_idx_1 ) + Fz_idx_2 ) + egwdhsr12b_p [ 1 ] ) / becrktx0d0 . P_226 + -
lbi5iovzof_idx_0 * lbi5iovzof_idx_3 ; Fx_fr = ( ( ( ( Fy_fr * becrktx0d0 .
P_169 - ( Fz_idx_1 + Fz_idx_2 ) * becrktx0d0 . P_170 ) + becrktx0d0 . P_246 [
0 ] / 2.0 * ( Fz_idx_3 - Fx_fr ) ) + becrktx0d0 . P_246 [ 1 ] / 2.0 * (
Fz_idx_0 - Fz_rnom ) ) + ewytrsohkb_p [ 2 ] ) / becrktx0d0 . P_25 ; Fz_idx_0
= ( xddot - Fx_fl_tmp ) * becrktx0d0 . P_187 ; Fz_idx_1 = ( ( ( ( becrktx0d0
. P_182 * becrktx0d0 . P_170 - Fz_idx_0 ) * becrktx0d0 . P_226 + ipxtggw2ad_p
* becrktx0d0 . P_170 ) + egwdhsr12b_p [ 0 ] * becrktx0d0 . P_187 ) -
ewytrsohkb_p [ 1 ] ) / ( becrktx0d0 . P_169 + becrktx0d0 . P_170 ) ; Fz_rnom
= ( ( ( ( Fz_idx_0 + becrktx0d0 . P_182 * becrktx0d0 . P_169 ) * becrktx0d0 .
P_226 + ipxtggw2ad_p * becrktx0d0 . P_169 ) - egwdhsr12b_p [ 0 ] * becrktx0d0
. P_187 ) + ewytrsohkb_p [ 1 ] ) / ( becrktx0d0 . P_169 + becrktx0d0 . P_170
) ; Fz_idx_2 = lbi5iovzof_idx_0 * lbi5iovzof_idx_3 + Fy_fl ; Fy_fr = (
Fz_idx_2 * becrktx0d0 . P_226 * becrktx0d0 . P_187 - egwdhsr12b_p [ 1 ] *
becrktx0d0 . P_187 ) + ewytrsohkb_p [ 0 ] ; Fz_idx_0 = ( Fy_fr + Fz_idx_1 ) *
( becrktx0d0 . P_246 [ 0 ] / 2.0 - becrktx0d0 . P_177 ) / ( becrktx0d0 .
P_246 [ 0 ] / 2.0 ) ; Fz_idx_3 = ( Fz_idx_2 * - becrktx0d0 . P_226 *
becrktx0d0 . P_187 + egwdhsr12b_p [ 1 ] * becrktx0d0 . P_187 ) + ewytrsohkb_p
[ 0 ] ; Fz_idx_1 = ( Fz_idx_3 + Fz_idx_1 ) * ( becrktx0d0 . P_246 [ 0 ] / 2.0
+ becrktx0d0 . P_177 ) / ( becrktx0d0 . P_246 [ 0 ] / 2.0 ) ; Fz_idx_2 = (
Fy_fr + Fz_rnom ) * ( becrktx0d0 . P_246 [ 1 ] / 2.0 - becrktx0d0 . P_177 ) /
( becrktx0d0 . P_246 [ 1 ] / 2.0 ) ; Fz_idx_3 = ( Fz_idx_3 + Fz_rnom ) * (
becrktx0d0 . P_246 [ 1 ] / 2.0 + becrktx0d0 . P_177 ) / ( becrktx0d0 . P_246
[ 1 ] / 2.0 ) ; if ( Fz_idx_0 < 0.0 ) { Fz_idx_0 = 0.0 ; } if ( Fz_idx_1 <
0.0 ) { Fz_idx_1 = 0.0 ; } if ( Fz_idx_2 < 0.0 ) { Fz_idx_2 = 0.0 ; } if (
Fz_idx_3 < 0.0 ) { Fz_idx_3 = 0.0 ; } } localB -> dmluove2os [ 0 ] = xddot ;
localB -> dmluove2os [ 1 ] = Fy_fl ; localB -> dmluove2os [ 2 ] =
lbi5iovzof_idx_3 ; localB -> dmluove2os [ 3 ] = Fx_fr ; xddot = Fz_idx_0 /
becrktx0d0 . P_34 ; iywjngy1pp_p = Fz_idx_1 / becrktx0d0 . P_34 ;
jkml1dhgc4_p = Fz_idx_2 / becrktx0d0 . P_39 ; nd20r1di23_idx_0 = Fz_idx_3 /
becrktx0d0 . P_39 ; if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit
( hokadafud5 , 1 , 0 ) ) { localB -> dmat2ltg45 = becrktx0d0 . P_247 ; } if (
xddot > becrktx0d0 . P_498 ) { xddot = becrktx0d0 . P_498 ; } else { if (
xddot < becrktx0d0 . P_499 ) { xddot = becrktx0d0 . P_499 ; } } localB ->
bhv2qsbrzq [ 0 ] = ( xddot - nkp14nzj3q_idx_0 ) * localB -> dmat2ltg45 ; if (
iywjngy1pp_p > becrktx0d0 . P_498 ) { iywjngy1pp_p = becrktx0d0 . P_498 ; }
else { if ( iywjngy1pp_p < becrktx0d0 . P_499 ) { iywjngy1pp_p = becrktx0d0 .
P_499 ; } } localB -> bhv2qsbrzq [ 1 ] = ( iywjngy1pp_p - nkp14nzj3q_idx_1 )
* localB -> dmat2ltg45 ; if ( jkml1dhgc4_p > becrktx0d0 . P_498 ) {
jkml1dhgc4_p = becrktx0d0 . P_498 ; } else { if ( jkml1dhgc4_p < becrktx0d0 .
P_499 ) { jkml1dhgc4_p = becrktx0d0 . P_499 ; } } localB -> bhv2qsbrzq [ 2 ]
= ( jkml1dhgc4_p - nkp14nzj3q_idx_2 ) * localB -> dmat2ltg45 ; if (
nd20r1di23_idx_0 > becrktx0d0 . P_498 ) { nd20r1di23_idx_0 = becrktx0d0 .
P_498 ; } else { if ( nd20r1di23_idx_0 < becrktx0d0 . P_499 ) {
nd20r1di23_idx_0 = becrktx0d0 . P_499 ; } } localB -> bhv2qsbrzq [ 3 ] = (
nd20r1di23_idx_0 - nkp14nzj3q_idx_3 ) * localB -> dmat2ltg45 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localB -> eboal33xnr [ 0 ] = becrktx0d0 . P_167 ; localB -> eboal33xnr [ 1
] = becrktx0d0 . P_168 ; * av1e2e2zlq = becrktx0d0 . P_500 ; * hzkodf3i3c =
becrktx0d0 . P_501 ; * amgwfcyfmi = becrktx0d0 . P_502 ; } if ( localDW ->
bokb5rvw5x != 0 ) { localX -> bmsz0qfwwr [ 0 ] = localB -> eboal33xnr [ 0 ] ;
localX -> bmsz0qfwwr [ 1 ] = localB -> eboal33xnr [ 1 ] ; }
muDoubleScalarSinCos ( lbi5iovzof_idx_2 , & p13owk0emg [ 0 ] , &
nkp14nzj3q_idx_0 ) ; muDoubleScalarSinCos ( * hzkodf3i3c , & p13owk0emg [ 1 ]
, & phs3p3rmuf_idx_1 ) ; muDoubleScalarSinCos ( * amgwfcyfmi , & p13owk0emg [
2 ] , & phs3p3rmuf_idx_2 ) ; okap0sparj_p [ 0 ] = phs3p3rmuf_idx_1 *
nkp14nzj3q_idx_0 ; iywjngy1pp_p = p13owk0emg [ 2 ] * p13owk0emg [ 1 ] ;
okap0sparj_p [ 1 ] = iywjngy1pp_p * nkp14nzj3q_idx_0 - phs3p3rmuf_idx_2 *
p13owk0emg [ 0 ] ; jkml1dhgc4_p = phs3p3rmuf_idx_2 * p13owk0emg [ 1 ] ;
okap0sparj_p [ 2 ] = jkml1dhgc4_p * nkp14nzj3q_idx_0 + p13owk0emg [ 2 ] *
p13owk0emg [ 0 ] ; okap0sparj_p [ 3 ] = phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] ;
okap0sparj_p [ 4 ] = iywjngy1pp_p * p13owk0emg [ 0 ] + phs3p3rmuf_idx_2 *
nkp14nzj3q_idx_0 ; okap0sparj_p [ 5 ] = jkml1dhgc4_p * p13owk0emg [ 0 ] -
p13owk0emg [ 2 ] * nkp14nzj3q_idx_0 ; okap0sparj_p [ 6 ] = - p13owk0emg [ 1 ]
; okap0sparj_p [ 7 ] = p13owk0emg [ 2 ] * phs3p3rmuf_idx_1 ; okap0sparj_p [ 8
] = phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 ; okap0sparj_e [ 0 ] = localX ->
bmsz0qfwwr [ 0 ] ; okap0sparj_e [ 1 ] = localX -> bmsz0qfwwr [ 1 ] ;
okap0sparj_e [ 2 ] = * av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) {
ewytrsohkb_p [ i ] = okap0sparj_e [ i ] + ( okap0sparj_p [ 3 * i + 2 ] *
localB -> eknuy4xov4 [ 2 ] + ( okap0sparj_p [ 3 * i + 1 ] * localB ->
eknuy4xov4 [ 1 ] + okap0sparj_p [ 3 * i ] * localB -> eknuy4xov4 [ 0 ] ) ) ;
} muDoubleScalarSinCos ( lbi5iovzof_idx_2 , & nkp14nzj3q_idx_0 , & p13owk0emg
[ 0 ] ) ; muDoubleScalarSinCos ( * hzkodf3i3c , & phs3p3rmuf_idx_1 , &
p13owk0emg [ 1 ] ) ; muDoubleScalarSinCos ( * amgwfcyfmi , & phs3p3rmuf_idx_2
, & p13owk0emg [ 2 ] ) ; okap0sparj_p [ 0 ] = p13owk0emg [ 1 ] * p13owk0emg [
0 ] ; okap0sparj_p [ 1 ] = phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 * p13owk0emg [
0 ] - p13owk0emg [ 2 ] * nkp14nzj3q_idx_0 ; okap0sparj_p [ 2 ] = p13owk0emg [
2 ] * phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] + phs3p3rmuf_idx_2 *
nkp14nzj3q_idx_0 ; okap0sparj_p [ 3 ] = p13owk0emg [ 1 ] * nkp14nzj3q_idx_0 ;
okap0sparj_p [ 4 ] = phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 * nkp14nzj3q_idx_0 +
p13owk0emg [ 2 ] * p13owk0emg [ 0 ] ; okap0sparj_p [ 5 ] = p13owk0emg [ 2 ] *
phs3p3rmuf_idx_1 * nkp14nzj3q_idx_0 - phs3p3rmuf_idx_2 * p13owk0emg [ 0 ] ;
okap0sparj_p [ 6 ] = - phs3p3rmuf_idx_1 ; okap0sparj_p [ 7 ] =
phs3p3rmuf_idx_2 * p13owk0emg [ 1 ] ; okap0sparj_p [ 8 ] = p13owk0emg [ 2 ] *
p13owk0emg [ 1 ] ; okap0sparj_e [ 0 ] = localX -> bmsz0qfwwr [ 0 ] ;
okap0sparj_e [ 1 ] = localX -> bmsz0qfwwr [ 1 ] ; okap0sparj_e [ 2 ] = *
av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) { egwdhsr12b_p [ i ] = okap0sparj_e
[ i ] + ( okap0sparj_p [ 3 * i + 2 ] * localB -> d51wwqdsap [ 2 ] + (
okap0sparj_p [ 3 * i + 1 ] * localB -> d51wwqdsap [ 1 ] + okap0sparj_p [ 3 *
i ] * localB -> d51wwqdsap [ 0 ] ) ) ; } muDoubleScalarSinCos (
lbi5iovzof_idx_2 , & nkp14nzj3q_idx_0 , & p13owk0emg [ 0 ] ) ;
muDoubleScalarSinCos ( * hzkodf3i3c , & phs3p3rmuf_idx_1 , & p13owk0emg [ 1 ]
) ; muDoubleScalarSinCos ( * amgwfcyfmi , & phs3p3rmuf_idx_2 , & p13owk0emg [
2 ] ) ; muDoubleScalarSinCos ( lbi5iovzof_idx_2 , & nkp14nzj3q_idx_0 , &
p13owk0emg [ 0 ] ) ; muDoubleScalarSinCos ( * hzkodf3i3c , & phs3p3rmuf_idx_1
, & p13owk0emg [ 1 ] ) ; muDoubleScalarSinCos ( * amgwfcyfmi , &
phs3p3rmuf_idx_2 , & p13owk0emg [ 2 ] ) ; okap0sparj_p [ 0 ] = p13owk0emg [ 1
] * p13owk0emg [ 0 ] ; okap0sparj_p [ 1 ] = phs3p3rmuf_idx_2 *
phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] - p13owk0emg [ 2 ] * nkp14nzj3q_idx_0 ;
okap0sparj_p [ 2 ] = p13owk0emg [ 2 ] * phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] +
phs3p3rmuf_idx_2 * nkp14nzj3q_idx_0 ; okap0sparj_p [ 3 ] = p13owk0emg [ 1 ] *
nkp14nzj3q_idx_0 ; okap0sparj_p [ 4 ] = phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 *
nkp14nzj3q_idx_0 + p13owk0emg [ 2 ] * p13owk0emg [ 0 ] ; okap0sparj_p [ 5 ] =
p13owk0emg [ 2 ] * phs3p3rmuf_idx_1 * nkp14nzj3q_idx_0 - phs3p3rmuf_idx_2 *
p13owk0emg [ 0 ] ; okap0sparj_p [ 6 ] = - phs3p3rmuf_idx_1 ; okap0sparj_p [ 7
] = phs3p3rmuf_idx_2 * p13owk0emg [ 1 ] ; okap0sparj_p [ 8 ] = p13owk0emg [ 2
] * p13owk0emg [ 1 ] ; okap0sparj_e [ 0 ] = localX -> bmsz0qfwwr [ 0 ] ;
okap0sparj_e [ 1 ] = localX -> bmsz0qfwwr [ 1 ] ; okap0sparj_e [ 2 ] = *
av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) { pdfylu1fax_p [ i ] = okap0sparj_e
[ i ] + ( okap0sparj_p [ 3 * i + 2 ] * localB -> fznsoivi2v [ 2 ] + (
okap0sparj_p [ 3 * i + 1 ] * localB -> fznsoivi2v [ 1 ] + okap0sparj_p [ 3 *
i ] * localB -> fznsoivi2v [ 0 ] ) ) ; } muDoubleScalarSinCos (
lbi5iovzof_idx_2 , & nkp14nzj3q_idx_0 , & p13owk0emg [ 0 ] ) ;
muDoubleScalarSinCos ( * hzkodf3i3c , & phs3p3rmuf_idx_1 , & p13owk0emg [ 1 ]
) ; muDoubleScalarSinCos ( * amgwfcyfmi , & phs3p3rmuf_idx_2 , & p13owk0emg [
2 ] ) ; okap0sparj_p [ 0 ] = p13owk0emg [ 1 ] * p13owk0emg [ 0 ] ;
okap0sparj_p [ 1 ] = phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] -
p13owk0emg [ 2 ] * nkp14nzj3q_idx_0 ; okap0sparj_p [ 2 ] = p13owk0emg [ 2 ] *
phs3p3rmuf_idx_1 * p13owk0emg [ 0 ] + phs3p3rmuf_idx_2 * nkp14nzj3q_idx_0 ;
okap0sparj_p [ 3 ] = p13owk0emg [ 1 ] * nkp14nzj3q_idx_0 ; okap0sparj_p [ 4 ]
= phs3p3rmuf_idx_2 * phs3p3rmuf_idx_1 * nkp14nzj3q_idx_0 + p13owk0emg [ 2 ] *
p13owk0emg [ 0 ] ; okap0sparj_p [ 5 ] = p13owk0emg [ 2 ] * phs3p3rmuf_idx_1 *
nkp14nzj3q_idx_0 - phs3p3rmuf_idx_2 * p13owk0emg [ 0 ] ; okap0sparj_p [ 6 ] =
- phs3p3rmuf_idx_1 ; okap0sparj_p [ 7 ] = phs3p3rmuf_idx_2 * p13owk0emg [ 1 ]
; okap0sparj_p [ 8 ] = p13owk0emg [ 2 ] * p13owk0emg [ 1 ] ; okap0sparj_e [ 0
] = localX -> bmsz0qfwwr [ 0 ] ; okap0sparj_e [ 1 ] = localX -> bmsz0qfwwr [
1 ] ; okap0sparj_e [ 2 ] = * av1e2e2zlq ; for ( i = 0 ; i < 3 ; i ++ ) {
p13owk0emg [ i ] = okap0sparj_e [ i ] + ( okap0sparj_p [ 3 * i + 2 ] * localB
-> esf1woxugv [ 2 ] + ( okap0sparj_p [ 3 * i + 1 ] * localB -> esf1woxugv [ 1
] + okap0sparj_p [ 3 * i ] * localB -> esf1woxugv [ 0 ] ) ) ; }
nkp14nzj3q_idx_0 = muDoubleScalarSin ( lbi5iovzof_idx_2 ) ; nkp14nzj3q_idx_1
= muDoubleScalarCos ( lbi5iovzof_idx_2 ) ; localB -> cxokykccmy [ 0 ] =
lbi5iovzof_idx_0 * nkp14nzj3q_idx_1 - lbi5iovzof_idx_1 * nkp14nzj3q_idx_0 ;
localB -> cxokykccmy [ 1 ] = lbi5iovzof_idx_0 * nkp14nzj3q_idx_0 +
lbi5iovzof_idx_1 * nkp14nzj3q_idx_1 ; * cqivd3kemx = ( lbi5iovzof_idx_0 *
lbi5iovzof_idx_3 + Fy_fl ) * 0.10197162129779282 ; eplypn1mx4 [ 0 ] =
ewytrsohkb_p [ 1 ] ; eplypn1mx4 [ 1 ] = egwdhsr12b_p [ 1 ] ; eplypn1mx4 [ 2 ]
= pdfylu1fax_p [ 1 ] ; eplypn1mx4 [ 3 ] = p13owk0emg [ 1 ] ; ebhsrqq1o4 [ 0 ]
= ewytrsohkb_p [ 0 ] ; ebhsrqq1o4 [ 1 ] = egwdhsr12b_p [ 0 ] ; ebhsrqq1o4 [ 2
] = pdfylu1fax_p [ 0 ] ; ebhsrqq1o4 [ 3 ] = p13owk0emg [ 0 ] ; * n0fjwjtmw3 =
localX -> bmsz0qfwwr [ 0 ] ; * pu1mlebux4 = localB -> cxokykccmy [ 0 ] ; *
dfywnyxbtq = localX -> bmsz0qfwwr [ 1 ] ; * hxjzroc5ux = localB -> cxokykccmy
[ 1 ] ; * c040sjjy2f = lbi5iovzof_idx_2 ; * hb0nga1cnl = lbi5iovzof_idx_3 ; *
lfffcfi0vv = lbi5iovzof_idx_0 ; * o4a5winsib = lbi5iovzof_idx_1 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ g2tnztcpzi [ 0 ] = becrktx0d0 . P_503 [ 0 ] ; g2tnztcpzi [ 1 ] = becrktx0d0
. P_503 [ 1 ] ; g2tnztcpzi [ 2 ] = becrktx0d0 . P_503 [ 2 ] ; g2tnztcpzi [ 3
] = becrktx0d0 . P_503 [ 3 ] ; } } void ii3iorkudk ( pa50wxsaaa * const
hokadafud5 , id4lpjcjia * localB , bpefjqedzq * localDW ) { if (
rtmIsMajorTimeStep ( hokadafud5 ) ) { if ( memcmp ( hokadafud5 ->
nonContDerivSignal [ 0 ] . pCurrVal , hokadafud5 -> nonContDerivSignal [ 0 ]
. pPrevVal , hokadafud5 -> nonContDerivSignal [ 0 ] . sizeInBytes ) != 0 ) {
( void ) memcpy ( hokadafud5 -> nonContDerivSignal [ 0 ] . pPrevVal ,
hokadafud5 -> nonContDerivSignal [ 0 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 0 ] . sizeInBytes ) ; ssSetSolverNeedsReset ( hokadafud5
-> _mdlRefSfcnS ) ; } if ( memcmp ( hokadafud5 -> nonContDerivSignal [ 1 ] .
pCurrVal , hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal , hokadafud5 ->
nonContDerivSignal [ 1 ] . sizeInBytes ) != 0 ) { ( void ) memcpy (
hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal , hokadafud5 ->
nonContDerivSignal [ 1 ] . pCurrVal , hokadafud5 -> nonContDerivSignal [ 1 ]
. sizeInBytes ) ; ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if
( memcmp ( hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 2 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 2 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
2 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 2 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 3 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 3 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
3 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 3 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 4 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 4 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
4 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 4 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 5 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 5 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
5 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 5 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 6 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 6 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
6 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 6 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 7 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 7 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
7 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 7 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 8 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 8 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
8 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 8 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 9 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 9 ]
. sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal [
9 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 9 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 10 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 10
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 10 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 10 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 11 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 11
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 11 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 11 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 12 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 12
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 12 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 12 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 13 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 13
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 13 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 13 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 14 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 14
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 14 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 14 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 15 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 15
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 15 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 15 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 16 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 16
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 16 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 16 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 17 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 17
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 17 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 17 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 18 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 18
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 18 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 18 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 19 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 19 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 19
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 19 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 19 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 19 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 20 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 20 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 20
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 20 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 20 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 20 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 21 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 21 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 21
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 21 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 21 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 21 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 22 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 22 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 22
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 22 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 22 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 22 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 23 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 23 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 23
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 23 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 23 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 23 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 24 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 24 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 24
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 24 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 24 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 24 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 25 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 25 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 25
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 25 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 25 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 25 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 26 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 26 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 26
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 26 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 26 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 26 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 27 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 27 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 27
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 27 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 27 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 27 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 28 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 28 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 28
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 28 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 28 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 28 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 29 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 29 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 29
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 29 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 29 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 29 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 30 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 30 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 30
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 30 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 30 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 30 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } if ( memcmp (
hokadafud5 -> nonContDerivSignal [ 31 ] . pCurrVal , hokadafud5 ->
nonContDerivSignal [ 31 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 31
] . sizeInBytes ) != 0 ) { ( void ) memcpy ( hokadafud5 -> nonContDerivSignal
[ 31 ] . pPrevVal , hokadafud5 -> nonContDerivSignal [ 31 ] . pCurrVal ,
hokadafud5 -> nonContDerivSignal [ 31 ] . sizeInBytes ) ;
ssSetSolverNeedsReset ( hokadafud5 -> _mdlRefSfcnS ) ; } } if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localDW -> czmfx0f2q0 = localB -> fkf4utoetv ; } if ( localDW -> pbnr1alend
== 1 ) { localDW -> cxn1gifobd = 0 ; } localDW -> kvj4uckeqc = 0 ; if (
rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5 , 1 , 0 ) )
{ localDW -> ok0qcfhc1h = localB -> kaw4drkctd ; localDW -> mjbxwgkncv =
localB -> knfdwxmyft ; } if ( localDW -> py0qqcx0x3 == 1 ) { localDW ->
ew15w55ihb = 0 ; } if ( localDW -> g1nszypg1o == 1 ) { localDW -> hrozwqlazz
= 0 ; } if ( rtmIsMajorTimeStep ( hokadafud5 ) && rtmIsSampleHit ( hokadafud5
, 1 , 0 ) ) { localDW -> nsc0idk5is = localB -> cjos3prroo ; } if ( localDW
-> ksj4vofnxt == 1 ) { localDW -> p30ktu555o = 0 ; } localDW -> bokb5rvw5x =
0 ; } void iu231drtpw ( id4lpjcjia * localB , bpefjqedzq * localDW ,
ha25zehowz * localXdot ) { localXdot -> dgtbqd0og2 [ 0 ] = localB ->
bhv2qsbrzq [ 0 ] ; localXdot -> dgtbqd0og2 [ 1 ] = localB -> bhv2qsbrzq [ 1 ]
; localXdot -> dgtbqd0og2 [ 2 ] = localB -> bhv2qsbrzq [ 2 ] ; localXdot ->
dgtbqd0og2 [ 3 ] = localB -> bhv2qsbrzq [ 3 ] ; localXdot -> boq0sjomkz =
localB -> dojjjby12g ; localXdot -> kcyjzyu2vu = 0.0 ; if ( localDW ->
pbnr1alend == 1 ) { localXdot -> kcyjzyu2vu = localB -> hrvz4xdqsk ; }
localXdot -> n5tb00omor [ 0 ] = localB -> dmluove2os [ 0 ] ; localXdot ->
n5tb00omor [ 1 ] = localB -> dmluove2os [ 1 ] ; localXdot -> n5tb00omor [ 2 ]
= localB -> dmluove2os [ 2 ] ; localXdot -> n5tb00omor [ 3 ] = localB ->
dmluove2os [ 3 ] ; localXdot -> g4fxozrdb2 = localB -> fircvrvyml ; localXdot
-> ny5f4grmco = 0.0 ; if ( localDW -> py0qqcx0x3 == 1 ) { localXdot ->
ny5f4grmco = localB -> da10kctuqi ; } localXdot -> i12d3wngfk = localB ->
jyeb4frt10 ; localXdot -> cxpr0gz2hj = 0.0 ; if ( localDW -> g1nszypg1o == 1
) { localXdot -> cxpr0gz2hj = localB -> kyoliujx0j ; } localXdot ->
betxkjviha = localB -> d3jtlyfeug ; localXdot -> lqp2to1kjt = 0.0 ; if (
localDW -> ksj4vofnxt == 1 ) { localXdot -> lqp2to1kjt = localB -> my2ijmg4ja
; } localXdot -> bmsz0qfwwr [ 0 ] = localB -> cxokykccmy [ 0 ] ; localXdot ->
bmsz0qfwwr [ 1 ] = localB -> cxokykccmy [ 1 ] ; } void pgy4d5vijx (
id4lpjcjia * localB , kg2zcpxtlx * localZCSV ) { localZCSV -> mlaiafwxlc =
localB -> ncwalb4mpa - becrktx0d0 . P_270 ; localZCSV -> cyrkdznh4m = localB
-> ncwalb4mpa - becrktx0d0 . P_271 ; localZCSV -> ehnijspp1u = localB ->
l3sezdykbm - becrktx0d0 . P_334 ; localZCSV -> oll3oq0535 = localB ->
l3sezdykbm - becrktx0d0 . P_335 ; localZCSV -> arx2z3n41a = localB ->
mo0spoj2dp - becrktx0d0 . P_389 ; localZCSV -> mwerxvw1j5 = localB ->
mo0spoj2dp - becrktx0d0 . P_390 ; localZCSV -> pv0hy3pe3t = localB ->
mtju0hxa2v - becrktx0d0 . P_444 ; localZCSV -> gsf0fruyzy = localB ->
mtju0hxa2v - becrktx0d0 . P_445 ; } void b51av3ulwn ( pa50wxsaaa * const
hokadafud5 ) { if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( hokadafud5 -> _mdlRefSfcnS , "PassVeh7DOF" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void lahi4jyhaj (
SimStruct * _mdlRefSfcnS , ssNonContDerivSigFeedingOutports * *
mr_nonContOutputArray , int_T mdlref_TID0 , int_T mdlref_TID1 , pa50wxsaaa *
const hokadafud5 , id4lpjcjia * localB , bpefjqedzq * localDW , hcqlainyez *
localX , pcbmq2m11v * localZCE , void * sysRanPtr , int contextTid ,
rtwCAPI_ModelMappingInfo * rt_ParentMMI , const char_T * rt_ChildPath , int_T
rt_ChildMMIIdx , int_T rt_CSTATEIdx ) { rt_InitInfAndNaN ( sizeof ( real_T )
) ; becrktx0d0 . P_270 = rtInf ; becrktx0d0 . P_334 = rtInf ; becrktx0d0 .
P_389 = rtInf ; becrktx0d0 . P_444 = rtInf ; ( void ) memset ( ( void * )
hokadafud5 , 0 , sizeof ( pa50wxsaaa ) ) ; hokadafud5 -> Timing .
mdlref_GlobalTID [ 0 ] = mdlref_TID0 ; hokadafud5 -> Timing .
mdlref_GlobalTID [ 1 ] = mdlref_TID1 ; hokadafud5 -> _mdlRefSfcnS = (
_mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( hokadafud5 -> _mdlRefSfcnS , "PassVeh7DOF" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) localB ) , 0 , sizeof ( id4lpjcjia ) ) ; { int32_T i ; for ( i = 0 ; i < 9
; i ++ ) { localB -> p21kvs5mbb [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ )
{ localB -> crh3sglt3v [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB
-> bc3tmfjmfl [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
ie4eubfmr2 [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
lfpjk1p50l [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
bhtsxyrihr [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
f4nd4h3rdi [ i ] = 0.0 ; } for ( i = 0 ; i < 9 ; i ++ ) { localB ->
cigblwahak [ i ] = 0.0 ; } for ( i = 0 ; i < 6 ; i ++ ) { localB ->
gtwgjfs43r [ i ] = 0.0 ; } for ( i = 0 ; i < 5 ; i ++ ) { localB ->
fbdb5pexuk . cngbrzew0c [ i ] = 0.0 ; } for ( i = 0 ; i < 34 ; i ++ ) {
localB -> fbdb5pexuk . kvxvdkvc3b [ i ] = 0.0 ; } for ( i = 0 ; i < 16 ; i ++
) { localB -> fbdb5pexuk . j2px0ljv0m [ i ] = 0.0 ; } for ( i = 0 ; i < 24 ;
i ++ ) { localB -> fbdb5pexuk . p4bflvewss [ i ] = 0.0 ; } for ( i = 0 ; i <
5 ; i ++ ) { localB -> i24h43uxd3 . cngbrzew0c [ i ] = 0.0 ; } for ( i = 0 ;
i < 34 ; i ++ ) { localB -> i24h43uxd3 . kvxvdkvc3b [ i ] = 0.0 ; } for ( i =
0 ; i < 16 ; i ++ ) { localB -> i24h43uxd3 . j2px0ljv0m [ i ] = 0.0 ; } for (
i = 0 ; i < 24 ; i ++ ) { localB -> i24h43uxd3 . p4bflvewss [ i ] = 0.0 ; }
for ( i = 0 ; i < 5 ; i ++ ) { localB -> dycowragfc . cngbrzew0c [ i ] = 0.0
; } for ( i = 0 ; i < 34 ; i ++ ) { localB -> dycowragfc . kvxvdkvc3b [ i ] =
0.0 ; } for ( i = 0 ; i < 16 ; i ++ ) { localB -> dycowragfc . j2px0ljv0m [ i
] = 0.0 ; } for ( i = 0 ; i < 24 ; i ++ ) { localB -> dycowragfc . p4bflvewss
[ i ] = 0.0 ; } for ( i = 0 ; i < 5 ; i ++ ) { localB -> f1abnn2ast .
cngbrzew0c [ i ] = 0.0 ; } for ( i = 0 ; i < 34 ; i ++ ) { localB ->
f1abnn2ast . kvxvdkvc3b [ i ] = 0.0 ; } for ( i = 0 ; i < 16 ; i ++ ) {
localB -> f1abnn2ast . j2px0ljv0m [ i ] = 0.0 ; } for ( i = 0 ; i < 24 ; i ++
) { localB -> f1abnn2ast . p4bflvewss [ i ] = 0.0 ; } localB -> is5r5qizkw [
0 ] = 0.0 ; localB -> is5r5qizkw [ 1 ] = 0.0 ; localB -> is5r5qizkw [ 2 ] =
0.0 ; localB -> is5r5qizkw [ 3 ] = 0.0 ; localB -> oxucuqlz4d = 0.0 ; localB
-> dtdpfiz3ya = 0.0 ; localB -> n2ifxcu5ka = 0.0 ; localB -> fsmoaxrbwz = 0.0
; localB -> a1iqcl35nc = 0.0 ; localB -> guehcsrift = 0.0 ; localB ->
ncwalb4mpa = 0.0 ; localB -> kk21lbu5b5 = 0.0 ; localB -> bbh5egeydw = 0.0 ;
localB -> bjtohmekdm = 0.0 ; localB -> eknuy4xov4 [ 0 ] = 0.0 ; localB ->
eknuy4xov4 [ 1 ] = 0.0 ; localB -> eknuy4xov4 [ 2 ] = 0.0 ; localB ->
jrtgn0jxaw = 0.0 ; localB -> klqtuuwl0t [ 0 ] = 0.0 ; localB -> klqtuuwl0t [
1 ] = 0.0 ; localB -> klqtuuwl0t [ 2 ] = 0.0 ; localB -> klqtuuwl0t [ 3 ] =
0.0 ; localB -> jl0mb0sdt1 = 0.0 ; localB -> e4qnpneaf0 = 0.0 ; localB ->
aqcplxkx2q = 0.0 ; localB -> mvptpmngpx = 0.0 ; localB -> d51wwqdsap [ 0 ] =
0.0 ; localB -> d51wwqdsap [ 1 ] = 0.0 ; localB -> d51wwqdsap [ 2 ] = 0.0 ;
localB -> g3ck2kdoiu = 0.0 ; localB -> jd5btdlbta = 0.0 ; localB ->
fuiqq1g2y1 = 0.0 ; localB -> on0e1amc4b = 0.0 ; localB -> fznsoivi2v [ 0 ] =
0.0 ; localB -> fznsoivi2v [ 1 ] = 0.0 ; localB -> fznsoivi2v [ 2 ] = 0.0 ;
localB -> pr13gdcnok = 0.0 ; localB -> jvb0u51fhy = 0.0 ; localB ->
ctd0sgwtys = 0.0 ; localB -> lqmh0s1j05 = 0.0 ; localB -> esf1woxugv [ 0 ] =
0.0 ; localB -> esf1woxugv [ 1 ] = 0.0 ; localB -> esf1woxugv [ 2 ] = 0.0 ;
localB -> fu0ssgbvmj = 0.0 ; localB -> mza4fnkd4w = 0.0 ; localB ->
kqddg2sxi4 = 0.0 ; localB -> kxepkmrspn = 0.0 ; localB -> ggjfrkknel [ 0 ] =
0.0 ; localB -> ggjfrkknel [ 1 ] = 0.0 ; localB -> ggjfrkknel [ 2 ] = 0.0 ;
localB -> ggjfrkknel [ 3 ] = 0.0 ; localB -> iw5zv3exm3 = 0.0 ; localB ->
iiwypnhwyh = 0.0 ; localB -> egbusy3rcf = 0.0 ; localB -> eyjqc3zg20 = 0.0 ;
localB -> eeh3yoxtqk = 0.0 ; localB -> dptguhaesv = 0.0 ; localB ->
di1y3sdj0d = 0.0 ; localB -> caogvivler = 0.0 ; localB -> bg3tax3rgv = 0.0 ;
localB -> kdyzo5shnm = 0.0 ; localB -> fw2njrswyb = 0.0 ; localB ->
codfhoiqk1 = 0.0 ; localB -> erj50lr4lf = 0.0 ; localB -> lbucqhslax = 0.0 ;
localB -> d1ao4nvb3r = 0.0 ; localB -> gfjrkfs43t = 0.0 ; localB ->
pic3pyjewm = 0.0 ; localB -> f5xpwds5uf = 0.0 ; localB -> i050wrra1b = 0.0 ;
localB -> cxsj5e3v3a = 0.0 ; localB -> isedmshyce = 0.0 ; localB ->
d4lcrcrqdn = 0.0 ; localB -> g4rortd5gm = 0.0 ; localB -> clz3iyr5qx = 0.0 ;
localB -> pyadsbtv4s = 0.0 ; localB -> bdx2e3myiv = 0.0 ; localB ->
exronxah0g = 0.0 ; localB -> ebzbgbgkgh = 0.0 ; localB -> bxd44k2unh = 0.0 ;
localB -> kzrkqtt0ra = 0.0 ; localB -> lzinhif1jz = 0.0 ; localB ->
ka3b1xmz3e = 0.0 ; localB -> imvrqtjhmt = 0.0 ; localB -> lrumv5m0rz = 0.0 ;
localB -> ibq2geeedj = 0.0 ; localB -> ezjxcx5jjr = 0.0 ; localB ->
fhcy0rvapt = 0.0 ; localB -> j0girqlod4 = 0.0 ; localB -> f2xqgnxkqm [ 0 ] =
0.0 ; localB -> f2xqgnxkqm [ 1 ] = 0.0 ; localB -> f2xqgnxkqm [ 2 ] = 0.0 ;
localB -> a1nh1kadu4 [ 0 ] = 0.0 ; localB -> a1nh1kadu4 [ 1 ] = 0.0 ; localB
-> a1nh1kadu4 [ 2 ] = 0.0 ; localB -> gtjrxup1j4 = 0.0 ; localB -> ihms03kaqg
= 0.0 ; localB -> lwln0imtwr = 0.0 ; localB -> fpll2uqxj0 = 0.0 ; localB ->
oo4mibkckw = 0.0 ; localB -> guz5uyqmni = 0.0 ; localB -> jpbgvu3ysx = 0.0 ;
localB -> ivdv3kteoq = 0.0 ; localB -> ilukdeejlg = 0.0 ; localB ->
fwvqhlsifq = 0.0 ; localB -> n4gka4ggb3 = 0.0 ; localB -> l4dk5thw4j = 0.0 ;
localB -> e4tas2ftdh = 0.0 ; localB -> npvsjubahx = 0.0 ; localB ->
ik2hq3tl51 = 0.0 ; localB -> gbddmx5qus [ 0 ] = 0.0 ; localB -> gbddmx5qus [
1 ] = 0.0 ; localB -> gbddmx5qus [ 2 ] = 0.0 ; localB -> bswxr3glt4 [ 0 ] =
0.0 ; localB -> bswxr3glt4 [ 1 ] = 0.0 ; localB -> bswxr3glt4 [ 2 ] = 0.0 ;
localB -> n4rna1kebg = 0.0 ; localB -> gxpylv2kph = 0.0 ; localB ->
cu5djmnfyj = 0.0 ; localB -> gf104bu43p = 0.0 ; localB -> n5bbn5bt0q = 0.0 ;
localB -> kf5eha1owu = 0.0 ; localB -> nilrmjc1gv = 0.0 ; localB ->
hgggja214h = 0.0 ; localB -> ocasm0fm15 = 0.0 ; localB -> irwjnphqqw = 0.0 ;
localB -> pxftkur41v = 0.0 ; localB -> hfvm1qgrw3 = 0.0 ; localB ->
fhdp2eu5jt = 0.0 ; localB -> canrgzivnr = 0.0 ; localB -> cr5hpd151d = 0.0 ;
localB -> ar23uftlis = 0.0 ; localB -> fsos5hphde = 0.0 ; localB ->
bunpahqovu = 0.0 ; localB -> ocjwenstkc = 0.0 ; localB -> m0ysfew3rk = 0.0 ;
localB -> dbdgakxnow = 0.0 ; localB -> gmcaz15cv4 = 0.0 ; localB ->
nlwwlu3lrx = 0.0 ; localB -> kfqbvv4uff = 0.0 ; localB -> oetza3lke4 = 0.0 ;
localB -> l1cwkfgzdt = 0.0 ; localB -> fugevmefkb = 0.0 ; localB ->
mldroewczt = 0.0 ; localB -> bsoukwzr1y = 0.0 ; localB -> fbezbyum3x = 0.0 ;
localB -> heipunlrmg = 0.0 ; localB -> epq3bk14ul = 0.0 ; localB ->
l3sezdykbm = 0.0 ; localB -> dgxtzac1n0 = 0.0 ; localB -> d4ro5g30v1 = 0.0 ;
localB -> hhuwm0io3s = 0.0 ; localB -> ogdgtyjzqi = 0.0 ; localB ->
axdicvi5m3 = 0.0 ; localB -> pj23yhglrw = 0.0 ; localB -> fpcofdvmxq = 0.0 ;
localB -> otfnmfg3va = 0.0 ; localB -> dqctahwqe1 = 0.0 ; localB ->
cc0g0dr1oo = 0.0 ; localB -> jm10hwmol3 = 0.0 ; localB -> iff1evzlmg = 0.0 ;
localB -> ffbjki2fot = 0.0 ; localB -> bijvgsz5qh = 0.0 ; localB ->
e0zyukaonm = 0.0 ; localB -> pvyk213plh = 0.0 ; localB -> oe0jus4god = 0.0 ;
localB -> hhzo15do51 = 0.0 ; localB -> cg3yxlcnph = 0.0 ; localB ->
belfgokcfy = 0.0 ; localB -> damawwa4tl = 0.0 ; localB -> bylvuz1vtv = 0.0 ;
localB -> hcksgh5oai = 0.0 ; localB -> hzjr0ik2hm = 0.0 ; localB ->
jbpx4i1xkq = 0.0 ; localB -> eevaz32yfw = 0.0 ; localB -> o3wkgn5vb2 = 0.0 ;
localB -> ffriktbsym = 0.0 ; localB -> ifwowqeogx = 0.0 ; localB ->
ev3cht2oax = 0.0 ; localB -> mmasgazjgu = 0.0 ; localB -> ox2j5d5cxd = 0.0 ;
localB -> m0csgicmpb = 0.0 ; localB -> cqvsmkaral = 0.0 ; localB ->
aby1ez2fhi = 0.0 ; localB -> mzni2kpsns = 0.0 ; localB -> jtrtvaajns = 0.0 ;
localB -> mimmdu3yox = 0.0 ; localB -> eholklbdno = 0.0 ; localB ->
eh1bnxmco2 = 0.0 ; localB -> f2oit4mz1m [ 0 ] = 0.0 ; localB -> f2oit4mz1m [
1 ] = 0.0 ; localB -> f2oit4mz1m [ 2 ] = 0.0 ; localB -> bcuad4qgnk [ 0 ] =
0.0 ; localB -> bcuad4qgnk [ 1 ] = 0.0 ; localB -> bcuad4qgnk [ 2 ] = 0.0 ;
localB -> paxqjicrvd = 0.0 ; localB -> bnlxmyw0x2 = 0.0 ; localB ->
h505jhxdmz = 0.0 ; localB -> gmcr3j0cex = 0.0 ; localB -> fuoqxgs3gc = 0.0 ;
localB -> cfn2c1bhhp = 0.0 ; localB -> pknzmehues = 0.0 ; localB ->
jw4cbjklwg = 0.0 ; localB -> eiaffadlxg = 0.0 ; localB -> m0jx3pzpz3 = 0.0 ;
localB -> flqtpdddos = 0.0 ; localB -> ctdqrhk0wl = 0.0 ; localB ->
fkqww4lf3n = 0.0 ; localB -> at3nbptmo3 = 0.0 ; localB -> pisy4totyk = 0.0 ;
localB -> nybfkmk1v2 [ 0 ] = 0.0 ; localB -> nybfkmk1v2 [ 1 ] = 0.0 ; localB
-> nybfkmk1v2 [ 2 ] = 0.0 ; localB -> fe2jbk1ow2 [ 0 ] = 0.0 ; localB ->
fe2jbk1ow2 [ 1 ] = 0.0 ; localB -> fe2jbk1ow2 [ 2 ] = 0.0 ; localB ->
dz4cqcxuur = 0.0 ; localB -> aokkriuvci = 0.0 ; localB -> bex1os0zvb = 0.0 ;
localB -> n5cwbhrehw = 0.0 ; localB -> jgkqc5zrqf = 0.0 ; localB ->
mlmqh1u0g5 = 0.0 ; localB -> khtbqd2u0y = 0.0 ; localB -> gk3dmmmcgw = 0.0 ;
localB -> eowqx4z04r = 0.0 ; localB -> naaa2ruf15 = 0.0 ; localB ->
br2j2u1vjb = 0.0 ; localB -> htao0p45hs = 0.0 ; localB -> gcjllctxbs = 0.0 ;
localB -> fonl15lhi1 = 0.0 ; localB -> et0mptjuaw = 0.0 ; localB ->
hyazmlrepy = 0.0 ; localB -> p1lp0buo44 = 0.0 ; localB -> nhbd0blqhw = 0.0 ;
localB -> fzii3sxltg = 0.0 ; localB -> lpk13hnzik = 0.0 ; localB ->
oz43sbwtkf = 0.0 ; localB -> nzhkhzb0lt = 0.0 ; localB -> bwhx4u5ecx = 0.0 ;
localB -> afa0svr0rr = 0.0 ; localB -> e41wl2nsj3 = 0.0 ; localB ->
lzuculkkg0 = 0.0 ; localB -> heksh3fd4a = 0.0 ; localB -> ltxahmkvv0 = 0.0 ;
localB -> hhomyb0ut1 = 0.0 ; localB -> jq1bwwonwz = 0.0 ; localB ->
nvzel15wxv = 0.0 ; localB -> lvh5brlvcm = 0.0 ; localB -> mo0spoj2dp = 0.0 ;
localB -> ncq4vocfhq = 0.0 ; localB -> ck21n4sgox = 0.0 ; localB ->
nwft3snr2v = 0.0 ; localB -> f0vsgrygsi = 0.0 ; localB -> onmfhkxj2b = 0.0 ;
localB -> makwuduny0 = 0.0 ; localB -> jfmfqfxlpf = 0.0 ; localB ->
ka2g0q2dyz = 0.0 ; localB -> mcfsleb4vj = 0.0 ; localB -> p04qegtreq = 0.0 ;
localB -> btyc3uconk = 0.0 ; localB -> ppbyftquej = 0.0 ; localB ->
j0ssdpfz3p = 0.0 ; localB -> d4q4amkhq0 = 0.0 ; localB -> gtcgkc52ss = 0.0 ;
localB -> bdlwmagotg = 0.0 ; localB -> ds1pko0yhn = 0.0 ; localB ->
pnx5kql1jb = 0.0 ; localB -> oqpf5cus4o = 0.0 ; localB -> dkx50lv42s = 0.0 ;
localB -> jqd2leehy4 = 0.0 ; localB -> buqrhazl3d = 0.0 ; localB ->
kdkxsiypqx = 0.0 ; localB -> kvoytc2kx3 = 0.0 ; localB -> nmlatm1b13 = 0.0 ;
localB -> didrtgo00z = 0.0 ; localB -> b1umyxgfps = 0.0 ; localB ->
jar2j2zazo = 0.0 ; localB -> ezmnobsxzk = 0.0 ; localB -> nxgmc04elj = 0.0 ;
localB -> kltug5vlk2 = 0.0 ; localB -> lnk3wadcrw = 0.0 ; localB ->
b0g0d14xp0 = 0.0 ; localB -> ip2o31scew = 0.0 ; localB -> odpixqjulv = 0.0 ;
localB -> eucw5jdhgs = 0.0 ; localB -> kbdxbjmwcc = 0.0 ; localB ->
dmpgiccwmv = 0.0 ; localB -> ltguoy1kgf = 0.0 ; localB -> bg0ucefe4s = 0.0 ;
localB -> idnuvsq50z [ 0 ] = 0.0 ; localB -> idnuvsq50z [ 1 ] = 0.0 ; localB
-> idnuvsq50z [ 2 ] = 0.0 ; localB -> k2magdngkl [ 0 ] = 0.0 ; localB ->
k2magdngkl [ 1 ] = 0.0 ; localB -> k2magdngkl [ 2 ] = 0.0 ; localB ->
cus1r3btzm = 0.0 ; localB -> emtbde10ax = 0.0 ; localB -> is01xwy4pb = 0.0 ;
localB -> brtiijmgcl = 0.0 ; localB -> k3llj3imqx = 0.0 ; localB ->
b005u0x43d = 0.0 ; localB -> nqoelq42lv = 0.0 ; localB -> lb3nqak1lw = 0.0 ;
localB -> nxu33k25qi = 0.0 ; localB -> ab5e5rggav = 0.0 ; localB ->
o2sgb25vdi = 0.0 ; localB -> genmkrinba = 0.0 ; localB -> jxhdosell2 = 0.0 ;
localB -> grnndi1soi = 0.0 ; localB -> g4ebwhkl3a = 0.0 ; localB ->
k4ryvi4c1f [ 0 ] = 0.0 ; localB -> k4ryvi4c1f [ 1 ] = 0.0 ; localB ->
k4ryvi4c1f [ 2 ] = 0.0 ; localB -> awaqkahv5l [ 0 ] = 0.0 ; localB ->
awaqkahv5l [ 1 ] = 0.0 ; localB -> awaqkahv5l [ 2 ] = 0.0 ; localB ->
fn1rx2vpsu = 0.0 ; localB -> kecjsfbkos = 0.0 ; localB -> knpe41bj2w = 0.0 ;
localB -> jnl2jrcrq0 = 0.0 ; localB -> jnzfhnelbw = 0.0 ; localB ->
l5a1fuyb1v = 0.0 ; localB -> fku0o25hj3 = 0.0 ; localB -> g53szwlk03 = 0.0 ;
localB -> oxl2gdvlbd = 0.0 ; localB -> e5qabfmbvm = 0.0 ; localB ->
fhm2jfzjpv = 0.0 ; localB -> fmqhoucoxn = 0.0 ; localB -> gzmu3j35nf = 0.0 ;
localB -> akoimjrkbf = 0.0 ; localB -> d5djjqarit = 0.0 ; localB ->
i4itn0vlmx = 0.0 ; localB -> efpubwovgw = 0.0 ; localB -> a21u1bb14f = 0.0 ;
localB -> fmoybge41a = 0.0 ; localB -> nhhxa0cvfm = 0.0 ; localB ->
hlsow32b05 = 0.0 ; localB -> bjuqnpreia = 0.0 ; localB -> dqix5d3stt = 0.0 ;
localB -> nx2qtlsqdh = 0.0 ; localB -> j4bdy242sp = 0.0 ; localB ->
ex2ckz41n1 = 0.0 ; localB -> kabqz3ukzq = 0.0 ; localB -> ewn13goqxs = 0.0 ;
localB -> bwitvgjxxj = 0.0 ; localB -> es2aoshppl = 0.0 ; localB ->
h41sr5mq0f = 0.0 ; localB -> fsh4di2i1p = 0.0 ; localB -> mtju0hxa2v = 0.0 ;
localB -> lri4q5yxl4 = 0.0 ; localB -> dssenryajr = 0.0 ; localB ->
etg50mmxko = 0.0 ; localB -> lbyadjdncx = 0.0 ; localB -> lh2p35lc50 = 0.0 ;
localB -> d3l5c3efvv = 0.0 ; localB -> fgxgazmjuv = 0.0 ; localB ->
omlqqotem3 = 0.0 ; localB -> lle222r3j0 = 0.0 ; localB -> pchqhi1ge4 = 0.0 ;
localB -> jrkpmqxqzg = 0.0 ; localB -> k2m1bl3r20 = 0.0 ; localB ->
a4eu3vnrpy = 0.0 ; localB -> pkwfnpnafc = 0.0 ; localB -> bgdkdg01tl = 0.0 ;
localB -> mg3pmuefg4 = 0.0 ; localB -> ctmsdct5g1 = 0.0 ; localB ->
izptjpab53 = 0.0 ; localB -> nkapvnd2vd = 0.0 ; localB -> jcwcnjif1u = 0.0 ;
localB -> j4hs5qkqll = 0.0 ; localB -> ieqhfhksug = 0.0 ; localB ->
lb0yj1o1mb = 0.0 ; localB -> jflqep0teo = 0.0 ; localB -> nko50awlgb = 0.0 ;
localB -> fo0lbkinxi = 0.0 ; localB -> apyxj1livc = 0.0 ; localB ->
kch0r3cpm0 = 0.0 ; localB -> p2penhk4ls = 0.0 ; localB -> adeucydncx = 0.0 ;
localB -> c1vxxjdkmt = 0.0 ; localB -> n5uwu02nod = 0.0 ; localB ->
bcigtnratx = 0.0 ; localB -> nedy5ldyk4 = 0.0 ; localB -> kmai0par5q = 0.0 ;
localB -> ds51cr1pqj = 0.0 ; localB -> ek2gcvl551 = 0.0 ; localB ->
cdy3v0ud4e = 0.0 ; localB -> n2cirx1p0q = 0.0 ; localB -> f54jwwj4gx = 0.0 ;
localB -> fqxqkg1alg [ 0 ] = 0.0 ; localB -> fqxqkg1alg [ 1 ] = 0.0 ; localB
-> fqxqkg1alg [ 2 ] = 0.0 ; localB -> csf03krjk1 [ 0 ] = 0.0 ; localB ->
csf03krjk1 [ 1 ] = 0.0 ; localB -> csf03krjk1 [ 2 ] = 0.0 ; localB ->
buuub0grk3 = 0.0 ; localB -> ezev30mpgc = 0.0 ; localB -> c1jshz5jay = 0.0 ;
localB -> ddx2axounw = 0.0 ; localB -> i3rbkx4cxs = 0.0 ; localB ->
kctu0ahldd = 0.0 ; localB -> m2v5mweb4k = 0.0 ; localB -> knlurbsiqt = 0.0 ;
localB -> ipnvro5jnu = 0.0 ; localB -> f1pabfvtek = 0.0 ; localB ->
huqqwotobu = 0.0 ; localB -> d4ikkqecf4 = 0.0 ; localB -> fks0ntwklm = 0.0 ;
localB -> i5iluqyceo = 0.0 ; localB -> kjzjtihdtp = 0.0 ; localB ->
gv4e3mhryb [ 0 ] = 0.0 ; localB -> gv4e3mhryb [ 1 ] = 0.0 ; localB ->
gv4e3mhryb [ 2 ] = 0.0 ; localB -> mnmnycaifv [ 0 ] = 0.0 ; localB ->
mnmnycaifv [ 1 ] = 0.0 ; localB -> mnmnycaifv [ 2 ] = 0.0 ; localB ->
d4na1jxh2p = 0.0 ; localB -> hhl0nour2n = 0.0 ; localB -> h1a54ayhvb = 0.0 ;
localB -> oskikps4cd = 0.0 ; localB -> lfcxaxdqqa = 0.0 ; localB ->
gi4hvkrulw = 0.0 ; localB -> mxiwfmh0m2 = 0.0 ; localB -> hmm1nxv52h = 0.0 ;
localB -> b3iurqll4v = 0.0 ; localB -> by214ztw3x = 0.0 ; localB ->
djpzfwrqq0 = 0.0 ; localB -> p1h0l1qmrs = 0.0 ; localB -> l12eogpfa5 = 0.0 ;
localB -> n3gz0mz23s = 0.0 ; localB -> m1ysf5objc = 0.0 ; localB ->
daaxem51rl = 0.0 ; localB -> fpwy5z1ghs = 0.0 ; localB -> bcx3tf0im1 = 0.0 ;
localB -> ix4r0g0kd4 = 0.0 ; localB -> oidumovatz = 0.0 ; localB ->
hgenpusx24 = 0.0 ; localB -> dsumzfgjxq = 0.0 ; localB -> e2ezk3qkym = 0.0 ;
localB -> m4domxuial = 0.0 ; localB -> nc1rcr52pc = 0.0 ; localB ->
fjht5toahx = 0.0 ; localB -> eebgpz0vzg = 0.0 ; localB -> m1s5erfnwn = 0.0 ;
localB -> j31uqmhbxd = 0.0 ; localB -> dojjjby12g = 0.0 ; localB ->
enxc5x5lm4 = 0.0 ; localB -> cccdg3551e = 0.0 ; localB -> c3jn3ij4j1 = 0.0 ;
localB -> fircvrvyml = 0.0 ; localB -> l5cqbsnku1 = 0.0 ; localB ->
m4emkhvth1 = 0.0 ; localB -> gdpqix4jpq = 0.0 ; localB -> jyeb4frt10 = 0.0 ;
localB -> fz3fkamkk0 = 0.0 ; localB -> m0wl0gwcta = 0.0 ; localB ->
ef4fwgtsyg = 0.0 ; localB -> d3jtlyfeug = 0.0 ; localB -> jbvz1saibt [ 0 ] =
0.0 ; localB -> jbvz1saibt [ 1 ] = 0.0 ; localB -> cbkp5rxvm4 [ 0 ] = 0.0 ;
localB -> cbkp5rxvm4 [ 1 ] = 0.0 ; localB -> cbkp5rxvm4 [ 2 ] = 0.0 ; localB
-> mi5jvi15pi [ 0 ] = 0.0 ; localB -> mi5jvi15pi [ 1 ] = 0.0 ; localB ->
mi5jvi15pi [ 2 ] = 0.0 ; localB -> nllk5i4gzs = 0.0 ; localB -> ndkynghq1s =
0.0 ; localB -> namy5gwh0d = 0.0 ; localB -> i3bz4euitt [ 0 ] = 0.0 ; localB
-> i3bz4euitt [ 1 ] = 0.0 ; localB -> mvdxvswfk4 [ 0 ] = 0.0 ; localB ->
mvdxvswfk4 [ 1 ] = 0.0 ; localB -> dmat2ltg45 = 0.0 ; localB -> bhv2qsbrzq [
0 ] = 0.0 ; localB -> bhv2qsbrzq [ 1 ] = 0.0 ; localB -> bhv2qsbrzq [ 2 ] =
0.0 ; localB -> bhv2qsbrzq [ 3 ] = 0.0 ; localB -> eboal33xnr [ 0 ] = 0.0 ;
localB -> eboal33xnr [ 1 ] = 0.0 ; localB -> dmluove2os [ 0 ] = 0.0 ; localB
-> dmluove2os [ 1 ] = 0.0 ; localB -> dmluove2os [ 2 ] = 0.0 ; localB ->
dmluove2os [ 3 ] = 0.0 ; localB -> cxokykccmy [ 0 ] = 0.0 ; localB ->
cxokykccmy [ 1 ] = 0.0 ; localB -> fp0lz1z3pw [ 0 ] = 0.0 ; localB ->
fp0lz1z3pw [ 1 ] = 0.0 ; localB -> fp0lz1z3pw [ 2 ] = 0.0 ; localB ->
fp0lz1z3pw [ 3 ] = 0.0 ; localB -> my2ijmg4ja = 0.0 ; localB -> kyoliujx0j =
0.0 ; localB -> da10kctuqi = 0.0 ; localB -> hrvz4xdqsk = 0.0 ; localB ->
jb5oqg1xv1 . cbtyne50cb = 0.0 ; localB -> jb5oqg1xv1 . hauge3fqzq = 0.0 ;
localB -> jb5oqg1xv1 . ekcsb45f1m = 0.0 ; localB -> fbdb5pexuk . dbw42rwkve =
0.0 ; localB -> fbdb5pexuk . imuoerh5jm = 0.0 ; localB -> jbxcrsbwh4 .
cbtyne50cb = 0.0 ; localB -> jbxcrsbwh4 . hauge3fqzq = 0.0 ; localB ->
jbxcrsbwh4 . ekcsb45f1m = 0.0 ; localB -> i24h43uxd3 . dbw42rwkve = 0.0 ;
localB -> i24h43uxd3 . imuoerh5jm = 0.0 ; localB -> d1a5f5cvti . cbtyne50cb =
0.0 ; localB -> d1a5f5cvti . hauge3fqzq = 0.0 ; localB -> d1a5f5cvti .
ekcsb45f1m = 0.0 ; localB -> dycowragfc . dbw42rwkve = 0.0 ; localB ->
dycowragfc . imuoerh5jm = 0.0 ; localB -> fw4l3ijud5i . cbtyne50cb = 0.0 ;
localB -> fw4l3ijud5i . hauge3fqzq = 0.0 ; localB -> fw4l3ijud5i . ekcsb45f1m
= 0.0 ; localB -> f1abnn2ast . dbw42rwkve = 0.0 ; localB -> f1abnn2ast .
imuoerh5jm = 0.0 ; } ( void ) memset ( ( void * ) localDW , 0 , sizeof (
bpefjqedzq ) ) ; PassVeh7DOF_InitializeDataMapInfo ( hokadafud5 , localDW ,
localX , sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) && (
rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( hokadafud5 -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
hokadafud5 -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( hokadafud5 -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } hokadafud5 -> nonContDerivSignal [ 0 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig0 ; hokadafud5 ->
nonContDerivSignal [ 0 ] . sizeInBytes = ( 2 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 0 ] . pCurrVal = ( char_T * ) ( & localB
-> mvdxvswfk4 [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 1 ] . pPrevVal =
( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig1 ; hokadafud5
-> nonContDerivSignal [ 1 ] . sizeInBytes = ( 2 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 1 ] . pCurrVal = ( char_T * ) ( & localB
-> i3bz4euitt [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 2 ] . pPrevVal =
( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig2 ; hokadafud5
-> nonContDerivSignal [ 2 ] . sizeInBytes = ( 3 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 2 ] . pCurrVal = ( char_T * ) ( & localB
-> mi5jvi15pi [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 3 ] . pPrevVal =
( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig3 ; hokadafud5
-> nonContDerivSignal [ 3 ] . sizeInBytes = ( 2 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 3 ] . pCurrVal = ( char_T * ) ( & localB
-> jbvz1saibt [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 4 ] . pPrevVal =
( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig4 ; hokadafud5
-> nonContDerivSignal [ 4 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 4 ] . pCurrVal = ( char_T * ) ( & localB
-> h41sr5mq0f ) ; ; hokadafud5 -> nonContDerivSignal [ 5 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig5 ; hokadafud5 ->
nonContDerivSignal [ 5 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 5 ] . pCurrVal = ( char_T * ) ( & localB
-> kabqz3ukzq ) ; ; hokadafud5 -> nonContDerivSignal [ 6 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig6 ; hokadafud5 ->
nonContDerivSignal [ 6 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 6 ] . pCurrVal = ( char_T * ) ( & localB
-> nvzel15wxv ) ; ; hokadafud5 -> nonContDerivSignal [ 7 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig7 ; hokadafud5 ->
nonContDerivSignal [ 7 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 7 ] . pCurrVal = ( char_T * ) ( & localB
-> heksh3fd4a ) ; ; hokadafud5 -> nonContDerivSignal [ 8 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig8 ; hokadafud5 ->
nonContDerivSignal [ 8 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 8 ] . pCurrVal = ( char_T * ) ( & localB
-> heipunlrmg ) ; ; hokadafud5 -> nonContDerivSignal [ 9 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig9 ; hokadafud5 ->
nonContDerivSignal [ 9 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 9 ] . pCurrVal = ( char_T * ) ( & localB
-> fugevmefkb ) ; ; hokadafud5 -> nonContDerivSignal [ 10 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig10 ; hokadafud5 ->
nonContDerivSignal [ 10 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 10 ] . pCurrVal = ( char_T * ) ( & localB
-> kxepkmrspn ) ; ; hokadafud5 -> nonContDerivSignal [ 11 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig11 ; hokadafud5 ->
nonContDerivSignal [ 11 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 11 ] . pCurrVal = ( char_T * ) ( & localB
-> kqddg2sxi4 ) ; ; hokadafud5 -> nonContDerivSignal [ 12 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig12 ; hokadafud5 ->
nonContDerivSignal [ 12 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 12 ] . pCurrVal = ( char_T * ) ( & localB
-> mza4fnkd4w ) ; ; hokadafud5 -> nonContDerivSignal [ 13 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig13 ; hokadafud5 ->
nonContDerivSignal [ 13 ] . sizeInBytes = ( 1 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 13 ] . pCurrVal = ( char_T * ) ( & localB
-> fu0ssgbvmj ) ; ; hokadafud5 -> nonContDerivSignal [ 14 ] . pPrevVal = (
char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig14 ; hokadafud5 ->
nonContDerivSignal [ 14 ] . sizeInBytes = ( 3 * sizeof ( real_T ) ) ;
hokadafud5 -> nonContDerivSignal [ 14 ] . pCurrVal = ( char_T * ) ( & localB
-> esf1woxugv [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 15 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig15 ;
hokadafud5 -> nonContDerivSignal [ 15 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 15 ] . pCurrVal = ( char_T * ) ( &
localB -> lqmh0s1j05 ) ; ; hokadafud5 -> nonContDerivSignal [ 16 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig16 ;
hokadafud5 -> nonContDerivSignal [ 16 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 16 ] . pCurrVal = ( char_T * ) ( &
localB -> ctd0sgwtys ) ; ; hokadafud5 -> nonContDerivSignal [ 17 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig17 ;
hokadafud5 -> nonContDerivSignal [ 17 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 17 ] . pCurrVal = ( char_T * ) ( &
localB -> jvb0u51fhy ) ; ; hokadafud5 -> nonContDerivSignal [ 18 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig18 ;
hokadafud5 -> nonContDerivSignal [ 18 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 18 ] . pCurrVal = ( char_T * ) ( &
localB -> pr13gdcnok ) ; ; hokadafud5 -> nonContDerivSignal [ 19 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig19 ;
hokadafud5 -> nonContDerivSignal [ 19 ] . sizeInBytes = ( 3 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 19 ] . pCurrVal = ( char_T * ) ( &
localB -> fznsoivi2v [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 20 ] .
pPrevVal = ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig20 ;
hokadafud5 -> nonContDerivSignal [ 20 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 20 ] . pCurrVal = ( char_T * ) ( &
localB -> on0e1amc4b ) ; ; hokadafud5 -> nonContDerivSignal [ 21 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig21 ;
hokadafud5 -> nonContDerivSignal [ 21 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 21 ] . pCurrVal = ( char_T * ) ( &
localB -> fuiqq1g2y1 ) ; ; hokadafud5 -> nonContDerivSignal [ 22 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig22 ;
hokadafud5 -> nonContDerivSignal [ 22 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 22 ] . pCurrVal = ( char_T * ) ( &
localB -> jd5btdlbta ) ; ; hokadafud5 -> nonContDerivSignal [ 23 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig23 ;
hokadafud5 -> nonContDerivSignal [ 23 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 23 ] . pCurrVal = ( char_T * ) ( &
localB -> g3ck2kdoiu ) ; ; hokadafud5 -> nonContDerivSignal [ 24 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig24 ;
hokadafud5 -> nonContDerivSignal [ 24 ] . sizeInBytes = ( 3 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 24 ] . pCurrVal = ( char_T * ) ( &
localB -> d51wwqdsap [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 25 ] .
pPrevVal = ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig25 ;
hokadafud5 -> nonContDerivSignal [ 25 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 25 ] . pCurrVal = ( char_T * ) ( &
localB -> aqcplxkx2q ) ; ; hokadafud5 -> nonContDerivSignal [ 26 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig26 ;
hokadafud5 -> nonContDerivSignal [ 26 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 26 ] . pCurrVal = ( char_T * ) ( &
localB -> e4qnpneaf0 ) ; ; hokadafud5 -> nonContDerivSignal [ 27 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig27 ;
hokadafud5 -> nonContDerivSignal [ 27 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 27 ] . pCurrVal = ( char_T * ) ( &
localB -> jl0mb0sdt1 ) ; ; hokadafud5 -> nonContDerivSignal [ 28 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig28 ;
hokadafud5 -> nonContDerivSignal [ 28 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 28 ] . pCurrVal = ( char_T * ) ( &
localB -> jrtgn0jxaw ) ; ; hokadafud5 -> nonContDerivSignal [ 29 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig29 ;
hokadafud5 -> nonContDerivSignal [ 29 ] . sizeInBytes = ( 3 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 29 ] . pCurrVal = ( char_T * ) ( &
localB -> eknuy4xov4 [ 0 ] ) ; ; hokadafud5 -> nonContDerivSignal [ 30 ] .
pPrevVal = ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig30 ;
hokadafud5 -> nonContDerivSignal [ 30 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 30 ] . pCurrVal = ( char_T * ) ( &
localB -> a1iqcl35nc ) ; ; hokadafud5 -> nonContDerivSignal [ 31 ] . pPrevVal
= ( char_T * ) hokadafud5 -> NonContDerivMemory . mr_nonContSig31 ;
hokadafud5 -> nonContDerivSignal [ 31 ] . sizeInBytes = ( 1 * sizeof ( real_T
) ) ; hokadafud5 -> nonContDerivSignal [ 31 ] . pCurrVal = ( char_T * ) ( &
localB -> oxucuqlz4d ) ; ; if ( mr_nonContOutputArray [ 6 ] != ( NULL ) ) {
mr_nonContOutputArray [ 6 ] [ 0 ] . sizeInBytes = 1 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 6 ] [ 0 ] . currVal = ( char_T * ) & localB ->
kabqz3ukzq ; mr_nonContOutputArray [ 6 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 1 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 1 ] . currVal = ( char_T * ) &
localB -> heksh3fd4a ; mr_nonContOutputArray [ 6 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 2 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 2 ] . currVal = ( char_T * ) &
localB -> fugevmefkb ; mr_nonContOutputArray [ 6 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 3 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 3 ] . currVal = ( char_T * ) &
localB -> kxepkmrspn ; mr_nonContOutputArray [ 6 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 4 ] . currVal = ( char_T * ) &
localB -> kqddg2sxi4 ; mr_nonContOutputArray [ 6 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 5 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 5 ] . currVal = ( char_T * ) &
localB -> mza4fnkd4w ; mr_nonContOutputArray [ 6 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 6 ] . currVal = ( char_T * ) &
localB -> fu0ssgbvmj ; mr_nonContOutputArray [ 6 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 7 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 7 ] . currVal = ( char_T * ) &
localB -> esf1woxugv [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 8 ] . currVal = ( char_T * ) &
localB -> lqmh0s1j05 ; mr_nonContOutputArray [ 6 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 6 ] != (
NULL ) ) { mr_nonContOutputArray [ 6 ] [ 9 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 9 ] . currVal = ( char_T * ) &
localB -> ctd0sgwtys ; mr_nonContOutputArray [ 6 ] [ 9 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 10 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 10 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 10 ] . currVal = ( char_T * ) &
localB -> jvb0u51fhy ; mr_nonContOutputArray [ 6 ] [ 10 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 11 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 11 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 11 ] . currVal = ( char_T * ) &
localB -> pr13gdcnok ; mr_nonContOutputArray [ 6 ] [ 11 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 12 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 12 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 12 ] . currVal = ( char_T * ) &
localB -> fznsoivi2v [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 12 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 13 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 13 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 13 ] . currVal = ( char_T * ) &
localB -> on0e1amc4b ; mr_nonContOutputArray [ 6 ] [ 13 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 14 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 14 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 14 ] . currVal = ( char_T * ) &
localB -> fuiqq1g2y1 ; mr_nonContOutputArray [ 6 ] [ 14 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 15 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 15 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 15 ] . currVal = ( char_T * ) &
localB -> jd5btdlbta ; mr_nonContOutputArray [ 6 ] [ 15 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 16 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 16 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 16 ] . currVal = ( char_T * ) &
localB -> g3ck2kdoiu ; mr_nonContOutputArray [ 6 ] [ 16 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 17 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 17 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 17 ] . currVal = ( char_T * ) &
localB -> d51wwqdsap [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 17 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 18 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 18 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 18 ] . currVal = ( char_T * ) &
localB -> aqcplxkx2q ; mr_nonContOutputArray [ 6 ] [ 18 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 19 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 19 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 19 ] . currVal = ( char_T * ) &
localB -> e4qnpneaf0 ; mr_nonContOutputArray [ 6 ] [ 19 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 20 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 20 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 20 ] . currVal = ( char_T * ) &
localB -> jl0mb0sdt1 ; mr_nonContOutputArray [ 6 ] [ 20 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 21 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 21 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 21 ] . currVal = ( char_T * ) &
localB -> jrtgn0jxaw ; mr_nonContOutputArray [ 6 ] [ 21 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 22 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 22 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 22 ] . currVal = ( char_T * ) &
localB -> eknuy4xov4 [ 0 ] ; mr_nonContOutputArray [ 6 ] [ 22 ] . next = & (
mr_nonContOutputArray [ 6 ] [ 23 ] ) ; } if ( mr_nonContOutputArray [ 6 ] !=
( NULL ) ) { mr_nonContOutputArray [ 6 ] [ 23 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 6 ] [ 23 ] . currVal = ( char_T * ) &
localB -> oxucuqlz4d ; mr_nonContOutputArray [ 6 ] [ 23 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 8 ] != ( NULL ) ) { mr_nonContOutputArray [ 8
] [ 0 ] . sizeInBytes = 2 * sizeof ( real_T ) ; mr_nonContOutputArray [ 8 ] [
0 ] . currVal = ( char_T * ) & localB -> mvdxvswfk4 [ 0 ] ;
mr_nonContOutputArray [ 8 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 8 ] [
1 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != ( NULL ) ) {
mr_nonContOutputArray [ 8 ] [ 1 ] . sizeInBytes = 2 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 8 ] [ 1 ] . currVal = ( char_T * ) & localB ->
i3bz4euitt [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 2 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 2 ] . currVal = ( char_T * ) &
localB -> mi5jvi15pi [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 3 ] . sizeInBytes = 2 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 3 ] . currVal = ( char_T * ) &
localB -> jbvz1saibt [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 3 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 4 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 4 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 4 ] . currVal = ( char_T * ) &
localB -> kabqz3ukzq ; mr_nonContOutputArray [ 8 ] [ 4 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 5 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 5 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 5 ] . currVal = ( char_T * ) &
localB -> heksh3fd4a ; mr_nonContOutputArray [ 8 ] [ 5 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 6 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 6 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 6 ] . currVal = ( char_T * ) &
localB -> fugevmefkb ; mr_nonContOutputArray [ 8 ] [ 6 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 7 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 7 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 7 ] . currVal = ( char_T * ) &
localB -> kxepkmrspn ; mr_nonContOutputArray [ 8 ] [ 7 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 8 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 8 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 8 ] . currVal = ( char_T * ) &
localB -> kqddg2sxi4 ; mr_nonContOutputArray [ 8 ] [ 8 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 9 ] ) ; } if ( mr_nonContOutputArray [ 8 ] != (
NULL ) ) { mr_nonContOutputArray [ 8 ] [ 9 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 9 ] . currVal = ( char_T * ) &
localB -> mza4fnkd4w ; mr_nonContOutputArray [ 8 ] [ 9 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 10 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 10 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 10 ] . currVal = ( char_T * ) &
localB -> fu0ssgbvmj ; mr_nonContOutputArray [ 8 ] [ 10 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 11 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 11 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 11 ] . currVal = ( char_T * ) &
localB -> esf1woxugv [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 11 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 12 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 12 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 12 ] . currVal = ( char_T * ) &
localB -> lqmh0s1j05 ; mr_nonContOutputArray [ 8 ] [ 12 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 13 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 13 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 13 ] . currVal = ( char_T * ) &
localB -> ctd0sgwtys ; mr_nonContOutputArray [ 8 ] [ 13 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 14 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 14 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 14 ] . currVal = ( char_T * ) &
localB -> jvb0u51fhy ; mr_nonContOutputArray [ 8 ] [ 14 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 15 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 15 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 15 ] . currVal = ( char_T * ) &
localB -> pr13gdcnok ; mr_nonContOutputArray [ 8 ] [ 15 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 16 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 16 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 16 ] . currVal = ( char_T * ) &
localB -> fznsoivi2v [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 16 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 17 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 17 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 17 ] . currVal = ( char_T * ) &
localB -> on0e1amc4b ; mr_nonContOutputArray [ 8 ] [ 17 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 18 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 18 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 18 ] . currVal = ( char_T * ) &
localB -> fuiqq1g2y1 ; mr_nonContOutputArray [ 8 ] [ 18 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 19 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 19 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 19 ] . currVal = ( char_T * ) &
localB -> jd5btdlbta ; mr_nonContOutputArray [ 8 ] [ 19 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 20 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 20 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 20 ] . currVal = ( char_T * ) &
localB -> g3ck2kdoiu ; mr_nonContOutputArray [ 8 ] [ 20 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 21 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 21 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 21 ] . currVal = ( char_T * ) &
localB -> d51wwqdsap [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 21 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 22 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 22 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 22 ] . currVal = ( char_T * ) &
localB -> aqcplxkx2q ; mr_nonContOutputArray [ 8 ] [ 22 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 23 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 23 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 23 ] . currVal = ( char_T * ) &
localB -> e4qnpneaf0 ; mr_nonContOutputArray [ 8 ] [ 23 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 24 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 24 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 24 ] . currVal = ( char_T * ) &
localB -> jl0mb0sdt1 ; mr_nonContOutputArray [ 8 ] [ 24 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 25 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 25 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 25 ] . currVal = ( char_T * ) &
localB -> jrtgn0jxaw ; mr_nonContOutputArray [ 8 ] [ 25 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 26 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 26 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 26 ] . currVal = ( char_T * ) &
localB -> eknuy4xov4 [ 0 ] ; mr_nonContOutputArray [ 8 ] [ 26 ] . next = & (
mr_nonContOutputArray [ 8 ] [ 27 ] ) ; } if ( mr_nonContOutputArray [ 8 ] !=
( NULL ) ) { mr_nonContOutputArray [ 8 ] [ 27 ] . sizeInBytes = 1 * sizeof (
real_T ) ; mr_nonContOutputArray [ 8 ] [ 27 ] . currVal = ( char_T * ) &
localB -> oxucuqlz4d ; mr_nonContOutputArray [ 8 ] [ 27 ] . next = ( NULL ) ;
} if ( mr_nonContOutputArray [ 18 ] != ( NULL ) ) { mr_nonContOutputArray [
18 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ; mr_nonContOutputArray [ 18
] [ 0 ] . currVal = ( char_T * ) & localB -> esf1woxugv [ 0 ] ;
mr_nonContOutputArray [ 18 ] [ 0 ] . next = & ( mr_nonContOutputArray [ 18 ]
[ 1 ] ) ; } if ( mr_nonContOutputArray [ 18 ] != ( NULL ) ) {
mr_nonContOutputArray [ 18 ] [ 1 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 18 ] [ 1 ] . currVal = ( char_T * ) & localB ->
fznsoivi2v [ 0 ] ; mr_nonContOutputArray [ 18 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 18 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 18 ] !=
( NULL ) ) { mr_nonContOutputArray [ 18 ] [ 2 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 18 ] [ 2 ] . currVal = ( char_T * ) &
localB -> d51wwqdsap [ 0 ] ; mr_nonContOutputArray [ 18 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 18 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 18 ] !=
( NULL ) ) { mr_nonContOutputArray [ 18 ] [ 3 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 18 ] [ 3 ] . currVal = ( char_T * ) &
localB -> eknuy4xov4 [ 0 ] ; mr_nonContOutputArray [ 18 ] [ 3 ] . next = (
NULL ) ; } if ( mr_nonContOutputArray [ 19 ] != ( NULL ) ) {
mr_nonContOutputArray [ 19 ] [ 0 ] . sizeInBytes = 3 * sizeof ( real_T ) ;
mr_nonContOutputArray [ 19 ] [ 0 ] . currVal = ( char_T * ) & localB ->
esf1woxugv [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 0 ] . next = & (
mr_nonContOutputArray [ 19 ] [ 1 ] ) ; } if ( mr_nonContOutputArray [ 19 ] !=
( NULL ) ) { mr_nonContOutputArray [ 19 ] [ 1 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 19 ] [ 1 ] . currVal = ( char_T * ) &
localB -> fznsoivi2v [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 1 ] . next = & (
mr_nonContOutputArray [ 19 ] [ 2 ] ) ; } if ( mr_nonContOutputArray [ 19 ] !=
( NULL ) ) { mr_nonContOutputArray [ 19 ] [ 2 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 19 ] [ 2 ] . currVal = ( char_T * ) &
localB -> d51wwqdsap [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 2 ] . next = & (
mr_nonContOutputArray [ 19 ] [ 3 ] ) ; } if ( mr_nonContOutputArray [ 19 ] !=
( NULL ) ) { mr_nonContOutputArray [ 19 ] [ 3 ] . sizeInBytes = 3 * sizeof (
real_T ) ; mr_nonContOutputArray [ 19 ] [ 3 ] . currVal = ( char_T * ) &
localB -> eknuy4xov4 [ 0 ] ; mr_nonContOutputArray [ 19 ] [ 3 ] . next = (
NULL ) ; } localZCE -> kz0kfjign2 = UNINITIALIZED_ZCSIG ; localZCE ->
ga0zahod5b = UNINITIALIZED_ZCSIG ; localZCE -> jlsbehjebk =
UNINITIALIZED_ZCSIG ; localZCE -> l2ffm5hvos = UNINITIALIZED_ZCSIG ; } void
mr_PassVeh7DOF_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T * modelName ,
int_T * retVal ) { * retVal = 0 ; { boolean_T regSubmodelsMdlinfo = false ;
ssGetRegSubmodelsMdlinfo ( mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if (
regSubmodelsMdlinfo ) { } } * retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS
, modelName , rtMdlInfo_PassVeh7DOF , 110 ) ; * retVal = 1 ; } static void
mr_PassVeh7DOF_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) ; static void
mr_PassVeh7DOF_cacheDataAsMxArray ( mxArray * destArray , mwIndex i , int j ,
const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_PassVeh7DOF_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ; static
void mr_PassVeh7DOF_restoreDataFromMxArray ( void * destData , const mxArray
* srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( ( uint8_T * )
destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber ( srcArray , i
, j ) ) , numBytes ) ; } static void mr_PassVeh7DOF_cacheBitFieldToMxArray (
mxArray * destArray , mwIndex i , int j , uint_T bitVal ) ; static void
mr_PassVeh7DOF_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex i , int
j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_PassVeh7DOF_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_PassVeh7DOF_extractBitFieldFromMxArray ( const mxArray * srcArray ,
mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_PassVeh7DOF_cacheDataToMxArrayWithOffset ( mxArray * destArray , mwIndex i
, int j , mwIndex offset , const void * srcData , size_t numBytes ) ; static
void mr_PassVeh7DOF_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
{ uint8_T * varData = ( uint8_T * ) mxGetData ( mxGetFieldByNumber (
destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData [ offset * numBytes
] , ( const uint8_T * ) srcData , numBytes ) ; } static void
mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset ( void * destData , const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t numBytes ) ;
static void mr_PassVeh7DOF_restoreDataFromMxArrayWithOffset ( void * destData
, const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray
, mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static void
mr_PassVeh7DOF_cacheBitFieldToCellArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , uint_T fieldVal ) { mxSetCell (
mxGetFieldByNumber ( destArray , i , j ) , offset , mxCreateDoubleScalar ( (
double ) fieldVal ) ) ; } static uint_T
mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset ( const mxArray *
srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_PassVeh7DOF_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) { const
uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell ( mxGetFieldByNumber (
srcArray , i , j ) , offset ) ) ; return fieldVal & ( ( 1u << numBits ) - 1u
) ; } mxArray * mr_PassVeh7DOF_GetDWork ( const pqca3kvywqf * mdlrefDW ) {
static const char * ssDWFieldNames [ 3 ] = { "rtb" , "rtdw" , "rtzce" , } ;
mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 , ssDWFieldNames ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( ssDW , 0 , 0 , & ( mdlrefDW -> rtb ) ,
sizeof ( mdlrefDW -> rtb ) ) ; { static const char * rtdwDataFieldNames [ 39
] = { "mdlrefDW->rtdw.kvj4uckeqc" , "mdlrefDW->rtdw.bokb5rvw5x" ,
"mdlrefDW->rtdw.p30ktu555o" , "mdlrefDW->rtdw.hrozwqlazz" ,
"mdlrefDW->rtdw.ew15w55ihb" , "mdlrefDW->rtdw.cxn1gifobd" ,
"mdlrefDW->rtdw.c15gh1znkl" , "mdlrefDW->rtdw.d0v5i0l0p3" ,
"mdlrefDW->rtdw.jc2adk33a2" , "mdlrefDW->rtdw.izlbjsap24" ,
"mdlrefDW->rtdw.nhfu44frt0" , "mdlrefDW->rtdw.mu4qgi2zax" ,
"mdlrefDW->rtdw.d2q5lsapa3" , "mdlrefDW->rtdw.bzktqcr5po" ,
"mdlrefDW->rtdw.pbnr1alend" , "mdlrefDW->rtdw.py0qqcx0x3" ,
"mdlrefDW->rtdw.g1nszypg1o" , "mdlrefDW->rtdw.ksj4vofnxt" ,
"mdlrefDW->rtdw.fvd2istvuu" , "mdlrefDW->rtdw.cujexquuia" ,
"mdlrefDW->rtdw.etneh3gh5z" , "mdlrefDW->rtdw.ad5kqdj2zm" ,
"mdlrefDW->rtdw.ihlln100lm" , "mdlrefDW->rtdw.cwhzvq3g0k" ,
"mdlrefDW->rtdw.czmfx0f2q0" , "mdlrefDW->rtdw.clzbvhgwst" ,
"mdlrefDW->rtdw.letpwa1hho" , "mdlrefDW->rtdw.ok0qcfhc1h" ,
"mdlrefDW->rtdw.lbpmeols54" , "mdlrefDW->rtdw.m1ndv25sb4" ,
"mdlrefDW->rtdw.mjbxwgkncv" , "mdlrefDW->rtdw.guacixjgv3" ,
"mdlrefDW->rtdw.gihmnw5lcd" , "mdlrefDW->rtdw.nsc0idk5is" ,
"mdlrefDW->rtdw.ffcbqtf0x4" , "mdlrefDW->rtdw.jb5oqg1xv1.nizc43tvct" ,
"mdlrefDW->rtdw.jbxcrsbwh4.nizc43tvct" ,
"mdlrefDW->rtdw.d1a5f5cvti.nizc43tvct" ,
"mdlrefDW->rtdw.fw4l3ijud5i.nizc43tvct" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 39 , rtdwDataFieldNames ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 0 , & ( mdlrefDW -> rtdw .
kvj4uckeqc ) , sizeof ( mdlrefDW -> rtdw . kvj4uckeqc ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 1 , & ( mdlrefDW -> rtdw .
bokb5rvw5x ) , sizeof ( mdlrefDW -> rtdw . bokb5rvw5x ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 2 , & ( mdlrefDW -> rtdw .
p30ktu555o ) , sizeof ( mdlrefDW -> rtdw . p30ktu555o ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 3 , & ( mdlrefDW -> rtdw .
hrozwqlazz ) , sizeof ( mdlrefDW -> rtdw . hrozwqlazz ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 4 , & ( mdlrefDW -> rtdw .
ew15w55ihb ) , sizeof ( mdlrefDW -> rtdw . ew15w55ihb ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 5 , & ( mdlrefDW -> rtdw .
cxn1gifobd ) , sizeof ( mdlrefDW -> rtdw . cxn1gifobd ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 6 , & ( mdlrefDW -> rtdw .
c15gh1znkl ) , sizeof ( mdlrefDW -> rtdw . c15gh1znkl ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 7 , & ( mdlrefDW -> rtdw .
d0v5i0l0p3 ) , sizeof ( mdlrefDW -> rtdw . d0v5i0l0p3 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 8 , & ( mdlrefDW -> rtdw .
jc2adk33a2 ) , sizeof ( mdlrefDW -> rtdw . jc2adk33a2 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 9 , & ( mdlrefDW -> rtdw .
izlbjsap24 ) , sizeof ( mdlrefDW -> rtdw . izlbjsap24 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 10 , & ( mdlrefDW -> rtdw
. nhfu44frt0 ) , sizeof ( mdlrefDW -> rtdw . nhfu44frt0 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 11 , & ( mdlrefDW -> rtdw
. mu4qgi2zax ) , sizeof ( mdlrefDW -> rtdw . mu4qgi2zax ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 12 , & ( mdlrefDW -> rtdw
. d2q5lsapa3 ) , sizeof ( mdlrefDW -> rtdw . d2q5lsapa3 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 13 , & ( mdlrefDW -> rtdw
. bzktqcr5po ) , sizeof ( mdlrefDW -> rtdw . bzktqcr5po ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 14 , & ( mdlrefDW -> rtdw
. pbnr1alend ) , sizeof ( mdlrefDW -> rtdw . pbnr1alend ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 15 , & ( mdlrefDW -> rtdw
. py0qqcx0x3 ) , sizeof ( mdlrefDW -> rtdw . py0qqcx0x3 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 16 , & ( mdlrefDW -> rtdw
. g1nszypg1o ) , sizeof ( mdlrefDW -> rtdw . g1nszypg1o ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 17 , & ( mdlrefDW -> rtdw
. ksj4vofnxt ) , sizeof ( mdlrefDW -> rtdw . ksj4vofnxt ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 18 , & ( mdlrefDW -> rtdw
. fvd2istvuu ) , sizeof ( mdlrefDW -> rtdw . fvd2istvuu ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 19 , & ( mdlrefDW -> rtdw
. cujexquuia ) , sizeof ( mdlrefDW -> rtdw . cujexquuia ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 20 , & ( mdlrefDW -> rtdw
. etneh3gh5z ) , sizeof ( mdlrefDW -> rtdw . etneh3gh5z ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 21 , & ( mdlrefDW -> rtdw
. ad5kqdj2zm ) , sizeof ( mdlrefDW -> rtdw . ad5kqdj2zm ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 22 , & ( mdlrefDW -> rtdw
. ihlln100lm ) , sizeof ( mdlrefDW -> rtdw . ihlln100lm ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 23 , & ( mdlrefDW -> rtdw
. cwhzvq3g0k ) , sizeof ( mdlrefDW -> rtdw . cwhzvq3g0k ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 24 , & ( mdlrefDW -> rtdw
. czmfx0f2q0 ) , sizeof ( mdlrefDW -> rtdw . czmfx0f2q0 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 25 , & ( mdlrefDW -> rtdw
. clzbvhgwst ) , sizeof ( mdlrefDW -> rtdw . clzbvhgwst ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 26 , & ( mdlrefDW -> rtdw
. letpwa1hho ) , sizeof ( mdlrefDW -> rtdw . letpwa1hho ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 27 , & ( mdlrefDW -> rtdw
. ok0qcfhc1h ) , sizeof ( mdlrefDW -> rtdw . ok0qcfhc1h ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 28 , & ( mdlrefDW -> rtdw
. lbpmeols54 ) , sizeof ( mdlrefDW -> rtdw . lbpmeols54 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 29 , & ( mdlrefDW -> rtdw
. m1ndv25sb4 ) , sizeof ( mdlrefDW -> rtdw . m1ndv25sb4 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 30 , & ( mdlrefDW -> rtdw
. mjbxwgkncv ) , sizeof ( mdlrefDW -> rtdw . mjbxwgkncv ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 31 , & ( mdlrefDW -> rtdw
. guacixjgv3 ) , sizeof ( mdlrefDW -> rtdw . guacixjgv3 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 32 , & ( mdlrefDW -> rtdw
. gihmnw5lcd ) , sizeof ( mdlrefDW -> rtdw . gihmnw5lcd ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 33 , & ( mdlrefDW -> rtdw
. nsc0idk5is ) , sizeof ( mdlrefDW -> rtdw . nsc0idk5is ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 34 , & ( mdlrefDW -> rtdw
. ffcbqtf0x4 ) , sizeof ( mdlrefDW -> rtdw . ffcbqtf0x4 ) ) ;
mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 35 , & ( mdlrefDW -> rtdw
. jb5oqg1xv1 . nizc43tvct ) , sizeof ( mdlrefDW -> rtdw . jb5oqg1xv1 .
nizc43tvct ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData , 0 , 36 , & (
mdlrefDW -> rtdw . jbxcrsbwh4 . nizc43tvct ) , sizeof ( mdlrefDW -> rtdw .
jbxcrsbwh4 . nizc43tvct ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray ( rtdwData ,
0 , 37 , & ( mdlrefDW -> rtdw . d1a5f5cvti . nizc43tvct ) , sizeof ( mdlrefDW
-> rtdw . d1a5f5cvti . nizc43tvct ) ) ; mr_PassVeh7DOF_cacheDataAsMxArray (
rtdwData , 0 , 38 , & ( mdlrefDW -> rtdw . fw4l3ijud5i . nizc43tvct ) ,
sizeof ( mdlrefDW -> rtdw . fw4l3ijud5i . nizc43tvct ) ) ; mxSetFieldByNumber
( ssDW , 0 , 1 , rtdwData ) ; } mr_PassVeh7DOF_cacheDataAsMxArray ( ssDW , 0
, 2 , & ( mdlrefDW -> rtzce ) , sizeof ( mdlrefDW -> rtzce ) ) ; ( void )
mdlrefDW ; return ssDW ; } void mr_PassVeh7DOF_SetDWork ( pqca3kvywqf *
mdlrefDW , const mxArray * ssDW ) { ( void ) ssDW ; ( void ) mdlrefDW ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtb ) , ssDW , 0 , 0
, sizeof ( mdlrefDW -> rtb ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ; mr_PassVeh7DOF_restoreDataFromMxArray (
& ( mdlrefDW -> rtdw . kvj4uckeqc ) , rtdwData , 0 , 0 , sizeof ( mdlrefDW ->
rtdw . kvj4uckeqc ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW
-> rtdw . bokb5rvw5x ) , rtdwData , 0 , 1 , sizeof ( mdlrefDW -> rtdw .
bokb5rvw5x ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. p30ktu555o ) , rtdwData , 0 , 2 , sizeof ( mdlrefDW -> rtdw . p30ktu555o )
) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . hrozwqlazz
) , rtdwData , 0 , 3 , sizeof ( mdlrefDW -> rtdw . hrozwqlazz ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ew15w55ihb ) ,
rtdwData , 0 , 4 , sizeof ( mdlrefDW -> rtdw . ew15w55ihb ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . cxn1gifobd ) ,
rtdwData , 0 , 5 , sizeof ( mdlrefDW -> rtdw . cxn1gifobd ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . c15gh1znkl ) ,
rtdwData , 0 , 6 , sizeof ( mdlrefDW -> rtdw . c15gh1znkl ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . d0v5i0l0p3 ) ,
rtdwData , 0 , 7 , sizeof ( mdlrefDW -> rtdw . d0v5i0l0p3 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jc2adk33a2 ) ,
rtdwData , 0 , 8 , sizeof ( mdlrefDW -> rtdw . jc2adk33a2 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . izlbjsap24 ) ,
rtdwData , 0 , 9 , sizeof ( mdlrefDW -> rtdw . izlbjsap24 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . nhfu44frt0 ) ,
rtdwData , 0 , 10 , sizeof ( mdlrefDW -> rtdw . nhfu44frt0 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . mu4qgi2zax ) ,
rtdwData , 0 , 11 , sizeof ( mdlrefDW -> rtdw . mu4qgi2zax ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . d2q5lsapa3 ) ,
rtdwData , 0 , 12 , sizeof ( mdlrefDW -> rtdw . d2q5lsapa3 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . bzktqcr5po ) ,
rtdwData , 0 , 13 , sizeof ( mdlrefDW -> rtdw . bzktqcr5po ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . pbnr1alend ) ,
rtdwData , 0 , 14 , sizeof ( mdlrefDW -> rtdw . pbnr1alend ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . py0qqcx0x3 ) ,
rtdwData , 0 , 15 , sizeof ( mdlrefDW -> rtdw . py0qqcx0x3 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . g1nszypg1o ) ,
rtdwData , 0 , 16 , sizeof ( mdlrefDW -> rtdw . g1nszypg1o ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ksj4vofnxt ) ,
rtdwData , 0 , 17 , sizeof ( mdlrefDW -> rtdw . ksj4vofnxt ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . fvd2istvuu ) ,
rtdwData , 0 , 18 , sizeof ( mdlrefDW -> rtdw . fvd2istvuu ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . cujexquuia ) ,
rtdwData , 0 , 19 , sizeof ( mdlrefDW -> rtdw . cujexquuia ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . etneh3gh5z ) ,
rtdwData , 0 , 20 , sizeof ( mdlrefDW -> rtdw . etneh3gh5z ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ad5kqdj2zm ) ,
rtdwData , 0 , 21 , sizeof ( mdlrefDW -> rtdw . ad5kqdj2zm ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ihlln100lm ) ,
rtdwData , 0 , 22 , sizeof ( mdlrefDW -> rtdw . ihlln100lm ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . cwhzvq3g0k ) ,
rtdwData , 0 , 23 , sizeof ( mdlrefDW -> rtdw . cwhzvq3g0k ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . czmfx0f2q0 ) ,
rtdwData , 0 , 24 , sizeof ( mdlrefDW -> rtdw . czmfx0f2q0 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . clzbvhgwst ) ,
rtdwData , 0 , 25 , sizeof ( mdlrefDW -> rtdw . clzbvhgwst ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . letpwa1hho ) ,
rtdwData , 0 , 26 , sizeof ( mdlrefDW -> rtdw . letpwa1hho ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ok0qcfhc1h ) ,
rtdwData , 0 , 27 , sizeof ( mdlrefDW -> rtdw . ok0qcfhc1h ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . lbpmeols54 ) ,
rtdwData , 0 , 28 , sizeof ( mdlrefDW -> rtdw . lbpmeols54 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . m1ndv25sb4 ) ,
rtdwData , 0 , 29 , sizeof ( mdlrefDW -> rtdw . m1ndv25sb4 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . mjbxwgkncv ) ,
rtdwData , 0 , 30 , sizeof ( mdlrefDW -> rtdw . mjbxwgkncv ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . guacixjgv3 ) ,
rtdwData , 0 , 31 , sizeof ( mdlrefDW -> rtdw . guacixjgv3 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . gihmnw5lcd ) ,
rtdwData , 0 , 32 , sizeof ( mdlrefDW -> rtdw . gihmnw5lcd ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . nsc0idk5is ) ,
rtdwData , 0 , 33 , sizeof ( mdlrefDW -> rtdw . nsc0idk5is ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . ffcbqtf0x4 ) ,
rtdwData , 0 , 34 , sizeof ( mdlrefDW -> rtdw . ffcbqtf0x4 ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . jb5oqg1xv1 .
nizc43tvct ) , rtdwData , 0 , 35 , sizeof ( mdlrefDW -> rtdw . jb5oqg1xv1 .
nizc43tvct ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw
. jbxcrsbwh4 . nizc43tvct ) , rtdwData , 0 , 36 , sizeof ( mdlrefDW -> rtdw .
jbxcrsbwh4 . nizc43tvct ) ) ; mr_PassVeh7DOF_restoreDataFromMxArray ( & (
mdlrefDW -> rtdw . d1a5f5cvti . nizc43tvct ) , rtdwData , 0 , 37 , sizeof (
mdlrefDW -> rtdw . d1a5f5cvti . nizc43tvct ) ) ;
mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW -> rtdw . fw4l3ijud5i .
nizc43tvct ) , rtdwData , 0 , 38 , sizeof ( mdlrefDW -> rtdw . fw4l3ijud5i .
nizc43tvct ) ) ; } mr_PassVeh7DOF_restoreDataFromMxArray ( & ( mdlrefDW ->
rtzce ) , ssDW , 0 , 2 , sizeof ( mdlrefDW -> rtzce ) ) ; } void
mr_PassVeh7DOF_RegisterSimStateChecksum ( SimStruct * S ) { const uint32_T
chksum [ 4 ] = { 2167055924U , 3693543292U , 2055178862U , 1922524079U , } ;
slmrModelRefRegisterSimStateChecksum ( S , "PassVeh7DOF" , & chksum [ 0 ] ) ;
} mxArray * mr_PassVeh7DOF_GetSimStateDisallowedBlocks ( ) { return NULL ; }
