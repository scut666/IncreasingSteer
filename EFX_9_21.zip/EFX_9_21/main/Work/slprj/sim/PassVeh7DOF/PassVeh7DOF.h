#include "__cf_PassVeh7DOF.h"
#ifndef RTW_HEADER_PassVeh7DOF_h_
#define RTW_HEADER_PassVeh7DOF_h_
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef PassVeh7DOF_COMMON_INCLUDES_
#define PassVeh7DOF_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "sf_runtime/sfc_sdi.h"
#endif
#include "PassVeh7DOF_types.h"
#include "multiword_types.h"
#include "model_reference_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rt_zcfcn.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
typedef struct { real_T cngbrzew0c [ 5 ] ; real_T kvxvdkvc3b [ 34 ] ; real_T
j2px0ljv0m [ 16 ] ; real_T p4bflvewss [ 24 ] ; real_T dbw42rwkve ; real_T
imuoerh5jm ; } ikqrgkdcac ; typedef struct { real_T cbtyne50cb ; real_T
hauge3fqzq ; real_T ekcsb45f1m ; } i1lzbfmeqz ; typedef struct { int8_T
nizc43tvct ; } eqxdu1smfw ; typedef struct { real_T is5r5qizkw [ 4 ] ; real_T
oxucuqlz4d ; real_T dtdpfiz3ya ; real_T n2ifxcu5ka ; real_T fsmoaxrbwz ;
real_T a1iqcl35nc ; real_T guehcsrift ; real_T ncwalb4mpa ; real_T kk21lbu5b5
; real_T bbh5egeydw ; real_T bjtohmekdm ; real_T eknuy4xov4 [ 3 ] ; real_T
jrtgn0jxaw ; real_T klqtuuwl0t [ 4 ] ; real_T jl0mb0sdt1 ; real_T e4qnpneaf0
; real_T aqcplxkx2q ; real_T mvptpmngpx ; real_T d51wwqdsap [ 3 ] ; real_T
g3ck2kdoiu ; real_T jd5btdlbta ; real_T fuiqq1g2y1 ; real_T on0e1amc4b ;
real_T fznsoivi2v [ 3 ] ; real_T pr13gdcnok ; real_T jvb0u51fhy ; real_T
ctd0sgwtys ; real_T lqmh0s1j05 ; real_T esf1woxugv [ 3 ] ; real_T fu0ssgbvmj
; real_T mza4fnkd4w ; real_T kqddg2sxi4 ; real_T kxepkmrspn ; real_T
ggjfrkknel [ 4 ] ; real_T iw5zv3exm3 ; real_T iiwypnhwyh ; real_T egbusy3rcf
; real_T eyjqc3zg20 ; real_T eeh3yoxtqk ; real_T dptguhaesv ; real_T
di1y3sdj0d ; real_T caogvivler ; real_T bg3tax3rgv ; real_T kdyzo5shnm ;
real_T fw2njrswyb ; real_T codfhoiqk1 ; real_T erj50lr4lf ; real_T lbucqhslax
; real_T d1ao4nvb3r ; real_T gfjrkfs43t ; real_T pic3pyjewm ; real_T
f5xpwds5uf ; real_T i050wrra1b ; real_T cxsj5e3v3a ; real_T isedmshyce ;
real_T d4lcrcrqdn ; real_T g4rortd5gm ; real_T clz3iyr5qx ; real_T pyadsbtv4s
; real_T bdx2e3myiv ; real_T exronxah0g ; real_T ebzbgbgkgh ; real_T
bxd44k2unh ; real_T kzrkqtt0ra ; real_T lzinhif1jz ; real_T ka3b1xmz3e ;
real_T imvrqtjhmt ; real_T lrumv5m0rz ; real_T ibq2geeedj ; real_T ezjxcx5jjr
; real_T fhcy0rvapt ; real_T j0girqlod4 ; real_T f2xqgnxkqm [ 3 ] ; real_T
a1nh1kadu4 [ 3 ] ; real_T p21kvs5mbb [ 9 ] ; real_T gtjrxup1j4 ; real_T
ihms03kaqg ; real_T lwln0imtwr ; real_T fpll2uqxj0 ; real_T oo4mibkckw ;
real_T guz5uyqmni ; real_T jpbgvu3ysx ; real_T ivdv3kteoq ; real_T ilukdeejlg
; real_T fwvqhlsifq ; real_T n4gka4ggb3 ; real_T l4dk5thw4j ; real_T
e4tas2ftdh ; real_T npvsjubahx ; real_T ik2hq3tl51 ; real_T gbddmx5qus [ 3 ]
; real_T bswxr3glt4 [ 3 ] ; real_T crh3sglt3v [ 9 ] ; real_T n4rna1kebg ;
real_T gxpylv2kph ; real_T cu5djmnfyj ; real_T gf104bu43p ; real_T n5bbn5bt0q
; real_T kf5eha1owu ; real_T nilrmjc1gv ; real_T hgggja214h ; real_T
ocasm0fm15 ; real_T irwjnphqqw ; real_T pxftkur41v ; real_T hfvm1qgrw3 ;
real_T fhdp2eu5jt ; real_T canrgzivnr ; real_T cr5hpd151d ; real_T ar23uftlis
; real_T fsos5hphde ; real_T bunpahqovu ; real_T ocjwenstkc ; real_T
m0ysfew3rk ; real_T dbdgakxnow ; real_T gmcaz15cv4 ; real_T nlwwlu3lrx ;
real_T kfqbvv4uff ; real_T oetza3lke4 ; real_T l1cwkfgzdt ; real_T fugevmefkb
; real_T mldroewczt ; real_T bsoukwzr1y ; real_T fbezbyum3x ; real_T
heipunlrmg ; real_T epq3bk14ul ; real_T l3sezdykbm ; real_T dgxtzac1n0 ;
real_T d4ro5g30v1 ; real_T hhuwm0io3s ; real_T ogdgtyjzqi ; real_T axdicvi5m3
; real_T pj23yhglrw ; real_T fpcofdvmxq ; real_T otfnmfg3va ; real_T
dqctahwqe1 ; real_T cc0g0dr1oo ; real_T jm10hwmol3 ; real_T iff1evzlmg ;
real_T ffbjki2fot ; real_T bijvgsz5qh ; real_T e0zyukaonm ; real_T pvyk213plh
; real_T oe0jus4god ; real_T hhzo15do51 ; real_T cg3yxlcnph ; real_T
belfgokcfy ; real_T damawwa4tl ; real_T bylvuz1vtv ; real_T hcksgh5oai ;
real_T hzjr0ik2hm ; real_T jbpx4i1xkq ; real_T eevaz32yfw ; real_T o3wkgn5vb2
; real_T ffriktbsym ; real_T ifwowqeogx ; real_T ev3cht2oax ; real_T
mmasgazjgu ; real_T ox2j5d5cxd ; real_T m0csgicmpb ; real_T cqvsmkaral ;
real_T aby1ez2fhi ; real_T mzni2kpsns ; real_T jtrtvaajns ; real_T mimmdu3yox
; real_T eholklbdno ; real_T eh1bnxmco2 ; real_T f2oit4mz1m [ 3 ] ; real_T
bcuad4qgnk [ 3 ] ; real_T bc3tmfjmfl [ 9 ] ; real_T paxqjicrvd ; real_T
bnlxmyw0x2 ; real_T h505jhxdmz ; real_T gmcr3j0cex ; real_T fuoqxgs3gc ;
real_T cfn2c1bhhp ; real_T pknzmehues ; real_T jw4cbjklwg ; real_T eiaffadlxg
; real_T m0jx3pzpz3 ; real_T flqtpdddos ; real_T ctdqrhk0wl ; real_T
fkqww4lf3n ; real_T at3nbptmo3 ; real_T pisy4totyk ; real_T nybfkmk1v2 [ 3 ]
; real_T fe2jbk1ow2 [ 3 ] ; real_T ie4eubfmr2 [ 9 ] ; real_T dz4cqcxuur ;
real_T aokkriuvci ; real_T bex1os0zvb ; real_T n5cwbhrehw ; real_T jgkqc5zrqf
; real_T mlmqh1u0g5 ; real_T khtbqd2u0y ; real_T gk3dmmmcgw ; real_T
eowqx4z04r ; real_T naaa2ruf15 ; real_T br2j2u1vjb ; real_T htao0p45hs ;
real_T gcjllctxbs ; real_T fonl15lhi1 ; real_T et0mptjuaw ; real_T hyazmlrepy
; real_T p1lp0buo44 ; real_T nhbd0blqhw ; real_T fzii3sxltg ; real_T
lpk13hnzik ; real_T oz43sbwtkf ; real_T nzhkhzb0lt ; real_T bwhx4u5ecx ;
real_T afa0svr0rr ; real_T e41wl2nsj3 ; real_T lzuculkkg0 ; real_T heksh3fd4a
; real_T ltxahmkvv0 ; real_T hhomyb0ut1 ; real_T jq1bwwonwz ; real_T
nvzel15wxv ; real_T lvh5brlvcm ; real_T mo0spoj2dp ; real_T ncq4vocfhq ;
real_T ck21n4sgox ; real_T nwft3snr2v ; real_T f0vsgrygsi ; real_T onmfhkxj2b
; real_T makwuduny0 ; real_T jfmfqfxlpf ; real_T ka2g0q2dyz ; real_T
mcfsleb4vj ; real_T p04qegtreq ; real_T btyc3uconk ; real_T ppbyftquej ;
real_T j0ssdpfz3p ; real_T d4q4amkhq0 ; real_T gtcgkc52ss ; real_T bdlwmagotg
; real_T ds1pko0yhn ; real_T pnx5kql1jb ; real_T oqpf5cus4o ; real_T
dkx50lv42s ; real_T jqd2leehy4 ; real_T buqrhazl3d ; real_T kdkxsiypqx ;
real_T kvoytc2kx3 ; real_T nmlatm1b13 ; real_T didrtgo00z ; real_T b1umyxgfps
; real_T jar2j2zazo ; real_T ezmnobsxzk ; real_T nxgmc04elj ; real_T
kltug5vlk2 ; real_T lnk3wadcrw ; real_T b0g0d14xp0 ; real_T ip2o31scew ;
real_T odpixqjulv ; real_T eucw5jdhgs ; real_T kbdxbjmwcc ; real_T dmpgiccwmv
; real_T ltguoy1kgf ; real_T bg0ucefe4s ; real_T idnuvsq50z [ 3 ] ; real_T
k2magdngkl [ 3 ] ; real_T lfpjk1p50l [ 9 ] ; real_T cus1r3btzm ; real_T
emtbde10ax ; real_T is01xwy4pb ; real_T brtiijmgcl ; real_T k3llj3imqx ;
real_T b005u0x43d ; real_T nqoelq42lv ; real_T lb3nqak1lw ; real_T nxu33k25qi
; real_T ab5e5rggav ; real_T o2sgb25vdi ; real_T genmkrinba ; real_T
jxhdosell2 ; real_T grnndi1soi ; real_T g4ebwhkl3a ; real_T k4ryvi4c1f [ 3 ]
; real_T awaqkahv5l [ 3 ] ; real_T bhtsxyrihr [ 9 ] ; real_T fn1rx2vpsu ;
real_T kecjsfbkos ; real_T knpe41bj2w ; real_T jnl2jrcrq0 ; real_T jnzfhnelbw
; real_T l5a1fuyb1v ; real_T fku0o25hj3 ; real_T g53szwlk03 ; real_T
oxl2gdvlbd ; real_T e5qabfmbvm ; real_T fhm2jfzjpv ; real_T fmqhoucoxn ;
real_T gzmu3j35nf ; real_T akoimjrkbf ; real_T d5djjqarit ; real_T i4itn0vlmx
; real_T efpubwovgw ; real_T a21u1bb14f ; real_T fmoybge41a ; real_T
nhhxa0cvfm ; real_T hlsow32b05 ; real_T bjuqnpreia ; real_T dqix5d3stt ;
real_T nx2qtlsqdh ; real_T j4bdy242sp ; real_T ex2ckz41n1 ; real_T kabqz3ukzq
; real_T ewn13goqxs ; real_T bwitvgjxxj ; real_T es2aoshppl ; real_T
h41sr5mq0f ; real_T fsh4di2i1p ; real_T mtju0hxa2v ; real_T lri4q5yxl4 ;
real_T dssenryajr ; real_T etg50mmxko ; real_T lbyadjdncx ; real_T lh2p35lc50
; real_T d3l5c3efvv ; real_T fgxgazmjuv ; real_T omlqqotem3 ; real_T
lle222r3j0 ; real_T pchqhi1ge4 ; real_T jrkpmqxqzg ; real_T k2m1bl3r20 ;
real_T a4eu3vnrpy ; real_T pkwfnpnafc ; real_T bgdkdg01tl ; real_T mg3pmuefg4
; real_T ctmsdct5g1 ; real_T izptjpab53 ; real_T nkapvnd2vd ; real_T
jcwcnjif1u ; real_T j4hs5qkqll ; real_T ieqhfhksug ; real_T lb0yj1o1mb ;
real_T jflqep0teo ; real_T nko50awlgb ; real_T fo0lbkinxi ; real_T apyxj1livc
; real_T kch0r3cpm0 ; real_T p2penhk4ls ; real_T adeucydncx ; real_T
c1vxxjdkmt ; real_T n5uwu02nod ; real_T bcigtnratx ; real_T nedy5ldyk4 ;
real_T kmai0par5q ; real_T ds51cr1pqj ; real_T ek2gcvl551 ; real_T cdy3v0ud4e
; real_T n2cirx1p0q ; real_T f54jwwj4gx ; real_T fqxqkg1alg [ 3 ] ; real_T
csf03krjk1 [ 3 ] ; real_T f4nd4h3rdi [ 9 ] ; real_T buuub0grk3 ; real_T
ezev30mpgc ; real_T c1jshz5jay ; real_T ddx2axounw ; real_T i3rbkx4cxs ;
real_T kctu0ahldd ; real_T m2v5mweb4k ; real_T knlurbsiqt ; real_T ipnvro5jnu
; real_T f1pabfvtek ; real_T huqqwotobu ; real_T d4ikkqecf4 ; real_T
fks0ntwklm ; real_T i5iluqyceo ; real_T kjzjtihdtp ; real_T gv4e3mhryb [ 3 ]
; real_T mnmnycaifv [ 3 ] ; real_T cigblwahak [ 9 ] ; real_T d4na1jxh2p ;
real_T hhl0nour2n ; real_T h1a54ayhvb ; real_T oskikps4cd ; real_T lfcxaxdqqa
; real_T gi4hvkrulw ; real_T mxiwfmh0m2 ; real_T hmm1nxv52h ; real_T
b3iurqll4v ; real_T by214ztw3x ; real_T djpzfwrqq0 ; real_T p1h0l1qmrs ;
real_T l12eogpfa5 ; real_T n3gz0mz23s ; real_T m1ysf5objc ; real_T daaxem51rl
; real_T fpwy5z1ghs ; real_T bcx3tf0im1 ; real_T ix4r0g0kd4 ; real_T
oidumovatz ; real_T hgenpusx24 ; real_T dsumzfgjxq ; real_T e2ezk3qkym ;
real_T m4domxuial ; real_T nc1rcr52pc ; real_T fjht5toahx ; real_T eebgpz0vzg
; real_T m1s5erfnwn ; real_T j31uqmhbxd ; real_T dojjjby12g ; real_T
enxc5x5lm4 ; real_T cccdg3551e ; real_T c3jn3ij4j1 ; real_T fircvrvyml ;
real_T l5cqbsnku1 ; real_T m4emkhvth1 ; real_T gdpqix4jpq ; real_T jyeb4frt10
; real_T fz3fkamkk0 ; real_T m0wl0gwcta ; real_T ef4fwgtsyg ; real_T
d3jtlyfeug ; real_T jbvz1saibt [ 2 ] ; real_T cbkp5rxvm4 [ 3 ] ; real_T
mi5jvi15pi [ 3 ] ; real_T nllk5i4gzs ; real_T gtwgjfs43r [ 6 ] ; real_T
ndkynghq1s ; real_T namy5gwh0d ; real_T i3bz4euitt [ 2 ] ; real_T mvdxvswfk4
[ 2 ] ; real_T dmat2ltg45 ; real_T bhv2qsbrzq [ 4 ] ; real_T eboal33xnr [ 2 ]
; real_T dmluove2os [ 4 ] ; real_T cxokykccmy [ 2 ] ; real_T fp0lz1z3pw [ 4 ]
; real_T my2ijmg4ja ; real_T kyoliujx0j ; real_T da10kctuqi ; real_T
hrvz4xdqsk ; boolean_T gtxfpctd3l ; boolean_T dxu0itewb4 ; boolean_T
fkf4utoetv ; boolean_T cykabqkq24 ; boolean_T oisuxakp0k ; boolean_T
kaw4drkctd ; boolean_T jmccqq5v03 ; boolean_T p3xkkxvu2y ; boolean_T
knfdwxmyft ; boolean_T aix4vz50d4 ; boolean_T lkqtbfqism ; boolean_T
cjos3prroo ; i1lzbfmeqz jb5oqg1xv1 ; ikqrgkdcac fbdb5pexuk ; i1lzbfmeqz
jbxcrsbwh4 ; ikqrgkdcac i24h43uxd3 ; i1lzbfmeqz d1a5f5cvti ; ikqrgkdcac
dycowragfc ; i1lzbfmeqz fw4l3ijud5i ; ikqrgkdcac f1abnn2ast ; } id4lpjcjia ;
typedef struct { int_T kvj4uckeqc ; int_T bokb5rvw5x ; int_T p30ktu555o ;
int_T hrozwqlazz ; int_T ew15w55ihb ; int_T cxn1gifobd ; int_T c15gh1znkl ;
int_T d0v5i0l0p3 ; int_T jc2adk33a2 ; int_T izlbjsap24 ; int_T nhfu44frt0 ;
int_T mu4qgi2zax ; int_T d2q5lsapa3 ; int_T bzktqcr5po ; int8_T pbnr1alend ;
int8_T py0qqcx0x3 ; int8_T g1nszypg1o ; int8_T ksj4vofnxt ; int8_T fvd2istvuu
; int8_T cujexquuia ; int8_T etneh3gh5z ; int8_T ad5kqdj2zm ; int8_T
ihlln100lm ; boolean_T cwhzvq3g0k ; boolean_T czmfx0f2q0 ; boolean_T
clzbvhgwst ; boolean_T letpwa1hho ; boolean_T ok0qcfhc1h ; boolean_T
lbpmeols54 ; boolean_T m1ndv25sb4 ; boolean_T mjbxwgkncv ; boolean_T
guacixjgv3 ; boolean_T gihmnw5lcd ; boolean_T nsc0idk5is ; boolean_T
ffcbqtf0x4 ; eqxdu1smfw jb5oqg1xv1 ; eqxdu1smfw jbxcrsbwh4 ; eqxdu1smfw
d1a5f5cvti ; eqxdu1smfw fw4l3ijud5i ; } bpefjqedzq ; typedef struct { real_T
dgtbqd0og2 [ 4 ] ; real_T boq0sjomkz ; real_T n5tb00omor [ 4 ] ; real_T
g4fxozrdb2 ; real_T i12d3wngfk ; real_T betxkjviha ; real_T bmsz0qfwwr [ 2 ]
; real_T lqp2to1kjt ; real_T cxpr0gz2hj ; real_T ny5f4grmco ; real_T
kcyjzyu2vu ; } hcqlainyez ; typedef struct { real_T dgtbqd0og2 [ 4 ] ; real_T
boq0sjomkz ; real_T n5tb00omor [ 4 ] ; real_T g4fxozrdb2 ; real_T i12d3wngfk
; real_T betxkjviha ; real_T bmsz0qfwwr [ 2 ] ; real_T lqp2to1kjt ; real_T
cxpr0gz2hj ; real_T ny5f4grmco ; real_T kcyjzyu2vu ; } ha25zehowz ; typedef
struct { boolean_T dgtbqd0og2 [ 4 ] ; boolean_T boq0sjomkz ; boolean_T
n5tb00omor [ 4 ] ; boolean_T g4fxozrdb2 ; boolean_T i12d3wngfk ; boolean_T
betxkjviha ; boolean_T bmsz0qfwwr [ 2 ] ; boolean_T lqp2to1kjt ; boolean_T
cxpr0gz2hj ; boolean_T ny5f4grmco ; boolean_T kcyjzyu2vu ; } dn0l2t323g ;
typedef struct { real_T dgtbqd0og2 [ 4 ] ; real_T boq0sjomkz ; real_T
n5tb00omor [ 4 ] ; real_T g4fxozrdb2 ; real_T i12d3wngfk ; real_T betxkjviha
; real_T bmsz0qfwwr [ 2 ] ; real_T lqp2to1kjt ; real_T cxpr0gz2hj ; real_T
ny5f4grmco ; real_T kcyjzyu2vu ; } e3r11zdizr ; typedef struct { real_T
dstimmszbs ; real_T mlaiafwxlc ; real_T cyrkdznh4m ; real_T bf31hkrcwh ;
real_T ehnijspp1u ; real_T oll3oq0535 ; real_T pfd0b3wseg ; real_T arx2z3n41a
; real_T mwerxvw1j5 ; real_T d4tfegxqoz ; real_T pv0hy3pe3t ; real_T
gsf0fruyzy ; } kg2zcpxtlx ; typedef struct { ZCSigState kz0kfjign2 ;
ZCSigState ga0zahod5b ; ZCSigState jlsbehjebk ; ZCSigState l2ffm5hvos ; }
pcbmq2m11v ; struct hznwrkfhta_ { real_T P_0 ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; } ; struct becrktx0d0o_ { real_T P_0 ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; real_T P_4 [ 31 ] ; real_T P_5 ; real_T P_6 ; real_T P_7 [ 31 ]
; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T
P_13 ; real_T P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ;
real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 ; real_T P_23 ; real_T
P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T P_29 ;
real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ; real_T
P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T P_40 ;
real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ; real_T
P_46 ; real_T P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T P_51 ;
real_T P_52 ; real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 ; real_T
P_57 ; real_T P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T P_62 ;
real_T P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ; real_T
P_68 ; real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ;
real_T P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T
P_79 ; real_T P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ; real_T P_84 ;
real_T P_85 ; real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T P_89 ; real_T
P_90 ; real_T P_91 ; real_T P_92 ; real_T P_93 ; real_T P_94 ; real_T P_95 ;
real_T P_96 ; real_T P_97 ; real_T P_98 ; real_T P_99 ; real_T P_100 ; real_T
P_101 ; real_T P_102 ; real_T P_103 ; real_T P_104 ; real_T P_105 ; real_T
P_106 ; real_T P_107 ; real_T P_108 ; real_T P_109 ; real_T P_110 ; real_T
P_111 ; real_T P_112 ; real_T P_113 ; real_T P_114 ; real_T P_115 ; real_T
P_116 ; real_T P_117 ; real_T P_118 ; real_T P_119 ; real_T P_120 ; real_T
P_121 ; real_T P_122 ; real_T P_123 ; real_T P_124 ; real_T P_125 ; real_T
P_126 ; real_T P_127 ; real_T P_128 ; real_T P_129 ; real_T P_130 ; real_T
P_131 ; real_T P_132 ; real_T P_133 ; real_T P_134 ; real_T P_135 ; real_T
P_136 ; real_T P_137 ; real_T P_138 ; real_T P_139 ; real_T P_140 ; real_T
P_141 ; real_T P_142 ; real_T P_143 ; real_T P_144 ; real_T P_145 ; real_T
P_146 ; real_T P_147 ; real_T P_148 ; real_T P_149 ; real_T P_150 ; real_T
P_151 ; real_T P_152 ; real_T P_153 ; real_T P_154 ; real_T P_155 ; real_T
P_156 ; real_T P_157 ; real_T P_158 ; real_T P_159 ; real_T P_160 ; real_T
P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T P_165 ; real_T
P_166 ; real_T P_167 ; real_T P_168 ; real_T P_169 ; real_T P_170 ; real_T
P_171 [ 31 ] ; real_T P_172 ; real_T P_173 ; real_T P_174 ; real_T P_175 ;
real_T P_176 ; real_T P_177 ; real_T P_178 ; real_T P_179 ; real_T P_180 ;
real_T P_181 ; real_T P_182 ; real_T P_183 ; real_T P_184 ; real_T P_185 ;
real_T P_186 ; real_T P_187 ; real_T P_188 ; real_T P_189 ; real_T P_190 ;
real_T P_191 ; real_T P_192 ; real_T P_193 ; real_T P_194 ; real_T P_195 ;
real_T P_196 ; real_T P_197 ; real_T P_198 ; real_T P_199 ; real_T P_200 ;
real_T P_201 ; real_T P_202 ; real_T P_203 ; real_T P_204 ; real_T P_205 ;
real_T P_206 ; real_T P_207 ; real_T P_208 ; real_T P_209 ; real_T P_210 ;
real_T P_211 ; real_T P_212 ; real_T P_213 ; real_T P_214 ; real_T P_215 ;
real_T P_216 ; real_T P_217 ; real_T P_218 ; real_T P_219 ; real_T P_220 ;
real_T P_221 ; real_T P_222 ; real_T P_223 ; real_T P_224 ; real_T P_225 ;
real_T P_226 ; real_T P_227 ; real_T P_228 ; real_T P_229 ; real_T P_230 ;
real_T P_231 ; real_T P_232 ; real_T P_233 ; real_T P_234 ; real_T P_235 ;
real_T P_236 ; real_T P_237 ; real_T P_238 ; real_T P_239 ; real_T P_240 ;
real_T P_241 ; real_T P_242 ; real_T P_243 ; real_T P_244 ; real_T P_245 ;
real_T P_246 [ 2 ] ; real_T P_247 ; real_T P_248 ; real_T P_249 ; real_T
P_250 ; real_T P_251 ; real_T P_252 ; real_T P_253 ; real_T P_254 ; real_T
P_255 ; real_T P_256 ; real_T P_257 ; real_T P_258 ; real_T P_259 ; real_T
P_260 ; real_T P_261 ; real_T P_262 ; real_T P_263 ; real_T P_264 ; real_T
P_265 ; real_T P_266 ; real_T P_267 ; real_T P_268 ; real_T P_269 ; real_T
P_270 ; real_T P_271 ; real_T P_272 ; real_T P_273 ; real_T P_274 ; real_T
P_275 ; real_T P_276 ; real_T P_277 ; real_T P_278 ; real_T P_279 ; real_T
P_280 ; real_T P_281 ; real_T P_282 ; real_T P_283 [ 4 ] ; real_T P_284 ;
real_T P_285 ; real_T P_286 ; real_T P_287 ; real_T P_288 ; real_T P_289 ;
real_T P_290 ; real_T P_291 ; real_T P_292 [ 3 ] ; real_T P_293 [ 3 ] ;
real_T P_294 [ 9 ] ; real_T P_295 ; real_T P_296 ; real_T P_297 [ 3 ] ;
real_T P_298 [ 3 ] ; real_T P_299 [ 9 ] ; real_T P_300 ; real_T P_301 ;
real_T P_302 ; real_T P_303 ; real_T P_304 ; real_T P_305 ; real_T P_306 ;
real_T P_307 ; real_T P_308 ; real_T P_309 ; real_T P_310 ; real_T P_311 ;
real_T P_312 ; real_T P_313 ; real_T P_314 ; real_T P_315 ; real_T P_316 ;
real_T P_317 ; real_T P_318 ; real_T P_319 ; real_T P_320 ; real_T P_321 ;
real_T P_322 ; real_T P_323 ; real_T P_324 ; real_T P_325 ; real_T P_326 ;
real_T P_327 ; real_T P_328 ; real_T P_329 ; real_T P_330 ; real_T P_331 ;
real_T P_332 ; real_T P_333 ; real_T P_334 ; real_T P_335 ; real_T P_336 ;
real_T P_337 ; real_T P_338 ; real_T P_339 ; real_T P_340 ; real_T P_341 ;
real_T P_342 ; real_T P_343 ; real_T P_344 ; real_T P_345 ; real_T P_346 ;
real_T P_347 [ 3 ] ; real_T P_348 [ 3 ] ; real_T P_349 [ 9 ] ; real_T P_350 ;
real_T P_351 ; real_T P_352 [ 3 ] ; real_T P_353 [ 3 ] ; real_T P_354 [ 9 ] ;
real_T P_355 ; real_T P_356 ; real_T P_357 ; real_T P_358 ; real_T P_359 ;
real_T P_360 ; real_T P_361 ; real_T P_362 ; real_T P_363 ; real_T P_364 ;
real_T P_365 ; real_T P_366 ; real_T P_367 ; real_T P_368 ; real_T P_369 ;
real_T P_370 ; real_T P_371 ; real_T P_372 ; real_T P_373 ; real_T P_374 ;
real_T P_375 ; real_T P_376 ; real_T P_377 ; real_T P_378 ; real_T P_379 ;
real_T P_380 ; real_T P_381 ; real_T P_382 ; real_T P_383 ; real_T P_384 ;
real_T P_385 ; real_T P_386 ; real_T P_387 ; real_T P_388 ; real_T P_389 ;
real_T P_390 ; real_T P_391 ; real_T P_392 ; real_T P_393 ; real_T P_394 ;
real_T P_395 ; real_T P_396 ; real_T P_397 ; real_T P_398 ; real_T P_399 ;
real_T P_400 ; real_T P_401 ; real_T P_402 [ 3 ] ; real_T P_403 [ 3 ] ;
real_T P_404 [ 9 ] ; real_T P_405 ; real_T P_406 ; real_T P_407 [ 3 ] ;
real_T P_408 [ 3 ] ; real_T P_409 [ 9 ] ; real_T P_410 ; real_T P_411 ;
real_T P_412 ; real_T P_413 ; real_T P_414 ; real_T P_415 ; real_T P_416 ;
real_T P_417 ; real_T P_418 ; real_T P_419 ; real_T P_420 ; real_T P_421 ;
real_T P_422 ; real_T P_423 ; real_T P_424 ; real_T P_425 ; real_T P_426 ;
real_T P_427 ; real_T P_428 ; real_T P_429 ; real_T P_430 ; real_T P_431 ;
real_T P_432 ; real_T P_433 ; real_T P_434 ; real_T P_435 ; real_T P_436 ;
real_T P_437 ; real_T P_438 ; real_T P_439 ; real_T P_440 ; real_T P_441 ;
real_T P_442 ; real_T P_443 ; real_T P_444 ; real_T P_445 ; real_T P_446 ;
real_T P_447 ; real_T P_448 ; real_T P_449 ; real_T P_450 ; real_T P_451 ;
real_T P_452 ; real_T P_453 ; real_T P_454 ; real_T P_455 ; real_T P_456 ;
real_T P_457 [ 3 ] ; real_T P_458 [ 3 ] ; real_T P_459 [ 9 ] ; real_T P_460 ;
real_T P_461 ; real_T P_462 [ 3 ] ; real_T P_463 [ 3 ] ; real_T P_464 [ 9 ] ;
real_T P_465 ; real_T P_466 ; real_T P_467 ; real_T P_468 ; real_T P_469 ;
real_T P_470 ; real_T P_471 ; real_T P_472 ; real_T P_473 ; real_T P_474 ;
real_T P_475 ; real_T P_476 ; real_T P_477 ; real_T P_478 ; real_T P_479 ;
real_T P_480 ; real_T P_481 ; real_T P_482 ; real_T P_483 ; real_T P_484 ;
real_T P_485 ; real_T P_486 ; real_T P_487 ; real_T P_488 ; real_T P_489 ;
real_T P_490 ; real_T P_491 ; real_T P_492 ; real_T P_493 ; real_T P_494 [ 3
] ; real_T P_495 ; real_T P_496 [ 2 ] ; real_T P_497 [ 2 ] ; real_T P_498 ;
real_T P_499 ; real_T P_500 ; real_T P_501 ; real_T P_502 ; real_T P_503 [ 4
] ; boolean_T P_504 ; boolean_T P_505 [ 8 ] ; boolean_T P_506 ; boolean_T
P_507 [ 8 ] ; boolean_T P_508 ; boolean_T P_509 [ 8 ] ; boolean_T P_510 ;
boolean_T P_511 [ 8 ] ; hznwrkfhta jb5oqg1xv1 ; hznwrkfhta jbxcrsbwh4 ;
hznwrkfhta d1a5f5cvti ; hznwrkfhta fw4l3ijud5i ; } ; struct mkmp3c5j3y {
struct SimStruct_tag * _mdlRefSfcnS ; struct { real_T mr_nonContSig0 [ 2 ] ;
real_T mr_nonContSig1 [ 2 ] ; real_T mr_nonContSig2 [ 3 ] ; real_T
mr_nonContSig3 [ 2 ] ; real_T mr_nonContSig4 [ 1 ] ; real_T mr_nonContSig5 [
1 ] ; real_T mr_nonContSig6 [ 1 ] ; real_T mr_nonContSig7 [ 1 ] ; real_T
mr_nonContSig8 [ 1 ] ; real_T mr_nonContSig9 [ 1 ] ; real_T mr_nonContSig10 [
1 ] ; real_T mr_nonContSig11 [ 1 ] ; real_T mr_nonContSig12 [ 1 ] ; real_T
mr_nonContSig13 [ 1 ] ; real_T mr_nonContSig14 [ 3 ] ; real_T mr_nonContSig15
[ 1 ] ; real_T mr_nonContSig16 [ 1 ] ; real_T mr_nonContSig17 [ 1 ] ; real_T
mr_nonContSig18 [ 1 ] ; real_T mr_nonContSig19 [ 3 ] ; real_T mr_nonContSig20
[ 1 ] ; real_T mr_nonContSig21 [ 1 ] ; real_T mr_nonContSig22 [ 1 ] ; real_T
mr_nonContSig23 [ 1 ] ; real_T mr_nonContSig24 [ 3 ] ; real_T mr_nonContSig25
[ 1 ] ; real_T mr_nonContSig26 [ 1 ] ; real_T mr_nonContSig27 [ 1 ] ; real_T
mr_nonContSig28 [ 1 ] ; real_T mr_nonContSig29 [ 3 ] ; real_T mr_nonContSig30
[ 1 ] ; real_T mr_nonContSig31 [ 1 ] ; } NonContDerivMemory ;
ssNonContDerivSigInfo nonContDerivSignal [ 32 ] ; const rtTimingBridge *
timingBridge ; struct { rtwCAPI_ModelMappingInfo mmi ;
rtwCAPI_ModelMapLoggingInstanceInfo mmiLogInstanceInfo ; void * dataAddress [
11 ] ; int32_T * vardimsAddress [ 11 ] ; RTWLoggingFcnPtr loggingPtrs [ 11 ]
; sysRanDType * systemRan [ 18 ] ; int_T systemTid [ 18 ] ; } DataMapInfo ;
struct { int_T mdlref_GlobalTID [ 2 ] ; } Timing ; } ; typedef struct {
id4lpjcjia rtb ; bpefjqedzq rtdw ; pa50wxsaaa rtm ; pcbmq2m11v rtzce ; }
pqca3kvywqf ; extern void lahi4jyhaj ( SimStruct * _mdlRefSfcnS ,
ssNonContDerivSigFeedingOutports * * mr_nonContOutputArray , int_T
mdlref_TID0 , int_T mdlref_TID1 , pa50wxsaaa * const hokadafud5 , id4lpjcjia
* localB , bpefjqedzq * localDW , hcqlainyez * localX , pcbmq2m11v * localZCE
, void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI
, const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) ;
extern void mr_PassVeh7DOF_MdlInfoRegFcn ( SimStruct * mdlRefSfcnS , char_T *
modelName , int_T * retVal ) ; extern mxArray * mr_PassVeh7DOF_GetDWork (
const pqca3kvywqf * mdlrefDW ) ; extern void mr_PassVeh7DOF_SetDWork (
pqca3kvywqf * mdlrefDW , const mxArray * ssDW ) ; extern void
mr_PassVeh7DOF_RegisterSimStateChecksum ( SimStruct * S ) ; extern mxArray *
mr_PassVeh7DOF_GetSimStateDisallowedBlocks ( ) ; extern const
rtwCAPI_ModelMappingStaticInfo * PassVeh7DOF_GetCAPIStaticMap ( void ) ;
extern void ptwb5m53nr ( real_T cved3liee0 , real_T hr35hjpkhm , real_T
nr4nhitcji , real_T jrgdlfbz0l , real_T k2sxinhxgw , real_T hv2idhietl ,
real_T ashlevpkyl , real_T awiwrbj1ah , real_T inzpjy4lsf , real_T hlmrktqqxx
, real_T nskttisvdw , real_T gx2hm5rb2y , const real_T * j5fczfhdct , real_T
hogvqsfuar , real_T b044mnnsii , real_T gf4qpdl150 , real_T pu1ucopikz ,
real_T oast2q50w1 , real_T pcxjf2dejm , real_T ciupjj5jym , real_T ejxwq2ptzb
, real_T al51nl4udn , real_T dgtanepmh3 , real_T pzgccsn2wd , real_T
camr2op5y5 , real_T keqisnbd3f , real_T dhjbvde1ql , real_T itr0vkexlm ,
real_T fb1lsx4wru , real_T ch5mu4pvuj , real_T ffca2wfrbb , real_T gvisb41nzp
, real_T kzpuc5zaqp , real_T lxinzmxu4z , real_T b5rhrqe32p , real_T
apc4wkkzj0 , real_T aqcvmgvimo , const real_T * bn0g4xdsr2 , real_T
f1zwljlqis , real_T faetpfbe3t , real_T f2wrfj3ld4 , real_T pj0acbgno5 ,
real_T jdp0ygo3rk , const real_T m3cuefccje [ 3 ] , const real_T kktb55loxf [
3 ] , const real_T eonbpbm1ha [ 9 ] , real_T fk1k5ewp1k , real_T ptghaz5var ,
real_T oku1yjbub2 , real_T b4mwug2qvn , real_T kswf03qlmx , real_T ev0nmrvz3n
, real_T gmukh33j1x , real_T ogftb2kvic , real_T hovfcz1beb , real_T
cnhq453n1f , real_T pkzjbcphib , real_T msi2x0cy5n , real_T amqujbosc0 ,
real_T ewmdujvrwd , real_T mc1li10ian , const real_T i5qknzmimx [ 3 ] , const
real_T k2ajbqqlbw [ 3 ] , const real_T c1tj0ta223 [ 9 ] , real_T cghblzuxit ,
real_T nnclxiugbw , real_T k3l0t243jz , real_T j3afmcxwz5 , real_T a3e0qsj3au
, real_T mkagm5ibpa , real_T bi25pt2vjy , real_T lmhxu3lxab , real_T
envxrls2yl , real_T iz3vm40vgt , real_T baznp0pjy0 , real_T l1g1n0fail ,
real_T ldjsaiwmlj , real_T lvflwdxi5c , real_T fbu1d4l3xg , real_T lyrupr0dj4
, real_T gkf12fuftl , real_T ezcoorwedf , real_T phwbwigd5c , real_T
k3l0glmlg0 , real_T pnspslh2fe , real_T a3qmcmhclv , real_T hizlzr3fbv ,
real_T nabnbe0jtn , real_T kihhma0xf1 , real_T cf0v1zbgxi , real_T kiu1b33l4h
, real_T * fyn4ujdhcm , real_T * njhenvfe4e , ikqrgkdcac * localB , real_T
rtp_FZMAX , real_T rtp_FZMIN , real_T rtp_VXLOW , real_T rtp_kappamax ) ;
extern void gnhczwf3q0 ( pa50wxsaaa * const hokadafud5 ) ; extern void
nm4ubjqz2k ( pa50wxsaaa * const hokadafud5 ) ; extern void fw4l3ijud5 (
pa50wxsaaa * const hokadafud5 , real_T * mi0h4y2kzi , real_T * jx5augwlqz ,
real_T * n0geutqbnv , i1lzbfmeqz * localB , hznwrkfhta * localP ) ; extern
void hzczw4rimi ( pa50wxsaaa * const hokadafud5 , real_T * hnk0xxowmm ,
real_T * io1pn0hnwg , real_T * av1e2e2zlq , real_T * amgwfcyfmi , real_T *
hzkodf3i3c , real_T g2tnztcpzi [ 4 ] , bpefjqedzq * localDW , hcqlainyez *
localX ) ; extern void ps1ayp5pv5 ( pa50wxsaaa * const hokadafud5 , real_T *
hnk0xxowmm , real_T * io1pn0hnwg , real_T * av1e2e2zlq , real_T * amgwfcyfmi
, real_T * hzkodf3i3c , real_T g2tnztcpzi [ 4 ] , bpefjqedzq * localDW ,
hcqlainyez * localX ) ; extern void aoae4c423r ( real_T * hnk0xxowmm , real_T
* io1pn0hnwg , real_T * av1e2e2zlq , real_T * amgwfcyfmi , real_T *
hzkodf3i3c , real_T g2tnztcpzi [ 4 ] , id4lpjcjia * localB , bpefjqedzq *
localDW ) ; extern void iu231drtpw ( id4lpjcjia * localB , bpefjqedzq *
localDW , ha25zehowz * localXdot ) ; extern void pgy4d5vijx ( id4lpjcjia *
localB , kg2zcpxtlx * localZCSV ) ; extern void g3iefm0j4w ( pa50wxsaaa *
const hokadafud5 , bpefjqedzq * localDW , dn0l2t323g * localXdis ) ; extern
void ii3iorkudk ( pa50wxsaaa * const hokadafud5 , id4lpjcjia * localB ,
bpefjqedzq * localDW ) ; extern void PassVeh7DOF ( pa50wxsaaa * const
hokadafud5 , const real_T fo3cvtmfih [ 4 ] , const real_T dfx1ca0pmi [ 4 ] ,
const real_T pf4xf35zus [ 3 ] , const real_T gxlrb30ei4 [ 4 ] , const real_T
bv2zp3o4ji [ 4 ] , const real_T czlc2qmxmx [ 4 ] , real_T * lfffcfi0vv ,
real_T * o4a5winsib , real_T * c040sjjy2f , real_T * hnk0xxowmm , real_T *
io1pn0hnwg , real_T * hb0nga1cnl , real_T cyqteuatay [ 4 ] , real_T
av2ap4nkgj [ 4 ] , real_T * cqivd3kemx , real_T * n0fjwjtmw3 , real_T *
dfywnyxbtq , real_T * av1e2e2zlq , real_T * pu1mlebux4 , real_T * hxjzroc5ux
, real_T * amgwfcyfmi , real_T * hzkodf3i3c , real_T eueb01ol1w [ 4 ] ,
real_T g2tnztcpzi [ 4 ] , real_T ebhsrqq1o4 [ 4 ] , real_T eplypn1mx4 [ 4 ] ,
id4lpjcjia * localB , bpefjqedzq * localDW , hcqlainyez * localX , pcbmq2m11v
* localZCE , dn0l2t323g * localXdis ) ; extern void b51av3ulwn ( pa50wxsaaa *
const hokadafud5 ) ;
#endif
