#ifndef SHARE_look1_binlcpw
#define SHARE_look1_binlcpw
#include "rtwtypes.h"
#include "multiword_types.h"

extern real_T look1_binlcpw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif
